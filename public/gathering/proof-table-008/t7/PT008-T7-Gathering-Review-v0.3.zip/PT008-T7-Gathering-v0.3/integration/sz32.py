# Independent implementation of the Chair's message (2026-11-12 22:02): seven runners, ONE zero class 7u, three same-class
# speeds (group 3) and two same-class speeds of another class (group 2).  Four clauses; bases theta and 2theta; 7 rotations each.
from fractions import Fraction as F
from math import gcd, floor
from t7 import S7, frac, dist, sgn, inv
def Nf(D,u): return 0 if D==0 else D//gcd(D,u)
def modinv_theta(D,u):
    g=gcd(D,u); N=D//g; j=(inv(u//g,N)*(-(-N//7)))%N; return F(j,D),N
def sz32(V,log=None):
    log={} if log is None else log
    Z=[v for v in V if v%7==0]; W=[v for v in V if v%7]
    assert len(V)==6 and len(Z)==1 and len(W)==5
    s=[sgn(w) for w in W]; cl=[x%7 for x in s]
    c3=[k for k in set(cl) if cl.count(k)==3]; c2=[k for k in set(cl) if cl.count(k)==2]
    assert len(c3)==1 and len(c2)==1, 'not a 3+2 pattern'; c3,c2=c3[0],c2[0]
    G3=sorted(x for x in s if x%7==c3); G2=sorted(x for x in s if x%7==c2); u=Z[0]//7
    D3=(G3[-1]-G3[0])//7; D2=(G2[-1]-G2[0])//7
    step=min((c3*inv(c2,7))%7,(-c3*inv(c2,7))%7)
    log.update(u=u,G3=tuple(G3),G2=tuple(G2),D3=D3,D2=D2,N3=Nf(D3,u),N2=Nf(D2,u),step=step)
    rounds=(1,2)
    if Nf(D3,u)>=3:
        th,N=modinv_theta(D3,u); clause='1: group-3 end pair coincides, 2+2 two-round criterion'
        assert (G3[-1]*th-G3[0]*th)%7==0
    else:
        assert D3<=2*u
        if step==3:
            th=F(1,7*u); rounds=(1,); clause='2: step 3, D3<=2u, theta=1/(7u)'
        elif Nf(D2,u)>=3:
            th,N=modinv_theta(D2,u); clause='3: step 2, group-2 pair coincides, 3+1 step-2 two-round'
            assert (G2[-1]*th-G2[0]*th)%7==0
        else:
            assert D2<=2*u
            th=F(1,7*u); rounds=(1,); clause='4: step 2, D2<=2u, theta=1/(7u)'
    x=frac(u*th); assert F(1,7)<=x<=F(3,7) or x==F(1,7)
    log.update(clause=clause,theta=th)
    for k in rounds:
        assert dist(k*u*th)>=S7
        for al in range(7):
            t=frac((k*th+al)/7)
            if all(dist(v*t)>=S7 for v in V): log.update(round=k,alpha=al,t=t); return t
    raise AssertionError('no candidate: %s'%log)
