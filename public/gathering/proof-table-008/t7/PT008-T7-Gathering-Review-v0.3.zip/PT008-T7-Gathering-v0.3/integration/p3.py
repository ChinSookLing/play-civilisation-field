# Independent implementation of "三加一分支直接構造（P3）：作者稿 v0.1" (Fable), written only from the manuscript.
# Exact integers/Fractions; no safe-time search beyond the manuscript's fixed alpha in {0..5}; no fallback.
# Conventions (manuscript Section 5): modular inverse = least positive residue; X° = (X/gcd(X,n)) mod N(X);
# theta' = frac(.); T2 order kappa1, kappa2; reconstruction alpha = 0..5 in order.
from fractions import Fraction as F
from math import gcd, floor
H=F(1,2); T3RD=F(1,3)
def frac(x): return x-floor(x)
def dist(x): x=frac(x); return min(x,1-x)
def v3(x):
    c=0
    while x%3==0: x//=3; c+=1
    return c
class Cost:
    def __init__(s): s.gcd=0; s.inv=0; s.tight=0; s.verify=0; s.alpha=0
def G(a,b,cost): cost.gcd+=1; return gcd(a,b)
def INV(a,N,cost): cost.inv+=1; return pow(a%N,-1,N)
def tight(points,cost,verify=False):
    if verify: cost.verify+=1
    else: cost.tight+=1
    return any(all(frac(y-b)<=T3RD for y in points) for b in points)
def NX(X,n,cost):
    g=G(X,n,cost); N=n//g; return N,((X//g)%N if N>1 else 0)
def P3(u,e2,e3,log,cost):
    g=G(abs(e2),abs(e3),cost); h=G(u,g,cost)
    up=u//h; a,b=e2//h,e3//h
    log.update(g=g,h=h,u1=up,e1=(a,b))
    if a%2==0 and b%2==0:
        assert up%2==1
        log['case']='E'; thp=H
    else:
        s=v3(up); n=3**(s+1)
        (Na,ao),(Nb,bo)=NX(a,n,cost),NX(b,n,cost)
        log.update(s=s,n=n,N_a=Na,N_b=Nb)
        if Na==1 and Nb==1:
            log['case']='T0'; kap=1; thp=F(1,n)
        elif Na!=Nb:
            log['case']='T1'
            (NY,Yo,NXX,Xo,ylab)=(Na,ao,Nb,bo,'e2') if Na<Nb else (Nb,bo,Na,ao,'e3')
            if NY>=3:
                k0=INV(Yo,NY,cost); j=(k0*Xo)%NY; assert 1<=j<=NY-1
            else: k0=None; j=1
            kap=(j*INV(Xo,NXX,cost))%NXX
            log.update(Y=ylab,Nprime=NY,N=NXX,Yo=Yo,Xo=Xo,kappa0=k0,j=j,kappa=kap)
            assert kap%3
            thp=F(kap,n)
            assert tight([F(0),frac(F(kap*a,n)),frac(F(kap*b,n))],cost,True), 'T1 assertion violated'
        elif Na>=9:
            log['case']='T2'; N=Na
            k1=INV(ao,N,cost); lam=(k1*bo)%N; ell=lam if lam<=N//2 else lam-N
            log.update(kappa1=k1,lam=lam,ell=ell)
            thp=None
            for kap,tag in ((k1,'kappa1'),((2*k1)%N,'kappa2')):
                if tight([F(0),frac(F(kap*a,n)),frac(F(kap*b,n))],cost):
                    thp=F(kap,n); log.update(kappa=kap,choice=tag); break
            if thp is None: raise AssertionError('T2 violated')
        else:
            Nd,_=NX(b-a,n,cost); log['N_diff']=Nd
            if Nd==1: log['case']='T3'; thp=F(1,n)
            else:
                log['case']='T4'; thp=F(1,n)+H
                pts=[F(0),frac(a*thp),frac(b*thp)]
                assert tight(pts,cost,True), 'T4 assertion violated'
        thp=frac(thp)
    theta=thp/h
    log.update(theta1=thp,theta=theta,u_theta=frac(u*theta))
    assert dist(u*theta)>=F(1,6), '(i) fails'
    log['P_points']=tuple(sorted([F(0),frac(e2*theta),frac(e3*theta)]))
    assert tight([F(0),frac(e2*theta),frac(e3*theta)],cost,True), '(ii) fails'
    return theta
def branch(V,log=None):
    log={} if log is None else log; cost=Cost()
    v1=V[0]; w=list(V[1:4]); w5=V[4]
    assert v1%6==0 and all(x%6 in (1,5) for x in w) and w5%6 in (2,3,4)
    u=v1//6; s=[x if x%6==1 else -x for x in w]
    e2,e3=(s[1]-s[0])//6,(s[2]-s[0])//6
    sig=1 if w5%6 in (2,3) else -1; c=(sig*w5)%6
    log.update(u=u,signed=tuple(s),e=(e2,e3),w5_class=w5%6,c=c)
    theta=P3(u,e2,e3,log,cost)
    tau=theta/6; t=None
    for al in range(6):
        cost.alpha+=1
        cand=tau+F(al,6)
        if all(dist(x*cand)>=F(1,6) for x in V[1:]): t=cand; log['alpha']=al; break
    if t is None: raise AssertionError('Lemma R\' violated: no alpha in 0..5')
    d=[dist(x*t) for x in V]
    log.update(t=t,dists=tuple(d),den_t=t.denominator,bound36u=36*u,
               cost='procedure tight-checks=%d (verification checks=%d) alpha-checks=%d gcd=%d modinv=%d'%(cost.tight,cost.verify,cost.alpha,cost.gcd,cost.inv))
    assert all(x>=F(1,6) for x in d), 'final check failed'
    assert t.denominator<=36*u, 'denominator bound violated'
    return t,log
