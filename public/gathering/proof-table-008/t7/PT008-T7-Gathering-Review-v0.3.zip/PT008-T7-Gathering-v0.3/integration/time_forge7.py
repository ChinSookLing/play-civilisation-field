"""Return an exact safe time for six nonzero integer relative speeds."""
from fractions import Fraction
from math import gcd

from dz22 import dz22
from dz4 import dz4
from r1 import tf as time_forge6
from sz32 import sz32
from sz41 import sz41, sz5
from sz221_full import sz221_full
from sz311_full import sz311_full
from t7 import S7, dist, frac, sgn, t7_2211
from t7_31 import t7_31

SINGLE_ZERO = {
    (5,): sz5,
    (4, 1): sz41,
    (3, 2): sz32,
    (3, 1, 1): sz311_full,
    (2, 2, 1): sz221_full,
}
DOUBLE_ZERO = {
    (4,): dz4,
    (3, 1): t7_31,
    (2, 2): dz22,
    (2, 1, 1): t7_2211,
}


def time_forge7(speeds, log=None):
    """Accept signed integers and repetitions. Return a Fraction in (0, 1)."""
    speeds = tuple(speeds)
    if len(speeds) != 6 or any(type(v) is not int or v == 0 for v in speeds):
        raise ValueError("expected six nonzero integer relative speeds")

    g = gcd(*speeds)
    normalized = tuple(abs(v) // g for v in speeds)
    zero = tuple(v // 7 for v in normalized if v % 7 == 0)
    nonzero = tuple(v for v in normalized if v % 7 != 0)
    classes = tuple(sgn(v) % 7 for v in nonzero)
    pattern = tuple(sorted((classes.count(c) for c in set(classes)), reverse=True))
    detail = {}

    if not zero:
        branch, t = "Z0", S7
    elif len(zero) == 2 and pattern == (2, 2):
        branch, t = "Z2:2+2", dz22(normalized, detail)
    elif len(set(normalized)) < 6:
        branch = "T6:repeated absolute speeds"
        t = time_forge6(tuple(dict.fromkeys(normalized)))
    elif len(zero) == 1:
        branch = "Z1:" + "+".join(map(str, pattern))
        t = SINGLE_ZERO[pattern](normalized, detail)
    elif len(zero) == 2:
        branch = "Z2:" + "+".join(map(str, pattern))
        t = DOUBLE_ZERO[pattern](normalized, detail)
    else:
        branch = "Z" + str(len(zero))
        theta = time_forge6(zero)
        for alpha in range(7):
            candidate = frac((theta + alpha) / 7)
            if all(dist(v * candidate) >= S7 for v in nonzero):
                t = candidate
                detail.update(theta=theta, alpha=alpha)
                break
        else:
            raise AssertionError("Z3–Z5: rotation count was violated")

    t = Fraction(t) / g
    if not 0 < t < 1 or any(dist(v * t) < S7 for v in speeds):
        raise AssertionError(f"{branch}: invalid safe time")
    if log is not None:
        log.update(branch=branch, gcd=g, zero_count=len(zero), pattern=pattern,
                   detail=detail)
    return t
