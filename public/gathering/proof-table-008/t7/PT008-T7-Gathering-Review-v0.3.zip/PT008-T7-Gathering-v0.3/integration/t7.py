# Independent implementation of Fable T7 R1 (claude/PT008-T7-R1-FABLE.md: Theorem A rules small/W/M/E/B, Omega handling)
# plus the Chair's Omega* completion (2026-11-12 19:22).  Seven runners: six speeds, threshold 1/7.
# Branch: two speeds = 0 mod 7 (7u <= 7U) and four nonzero speeds whose classes (s = +-w = 1,2,3 mod 7) are 2+1+1.
# Exact Fractions, closed comparisons, fixed candidate counts, no fallback.
from fractions import Fraction as F
from math import gcd, floor, ceil
S7=F(1,7)
def frac(x): return x-floor(x)
def dist(x): x=frac(x); return min(x,1-x)
def inv(a,N): return pow(a%N,-1,N)
def FD(D,th):                                       # first point >= th with ||D th|| <= 1/7
    return th if dist(D*th)<=S7 else (ceil(D*th+S7)-S7)/D
def S_ok(u,U,D,th): return dist(u*th)>=S7 and dist(U*th)>=S7 and dist(D*th)<=S7
def in_Omega(u,U,D): return D==u and U%u==0 and (U//u)%7==0
def thmA(u,U,D,log):
    assert 1<=u<=U and D>=1 and not in_Omega(u,U,D)
    if D>=U:                                        # rule W
        g=gcd(u,U); p,q=u//g,U//g
        if p==q or q-p>=2:
            m=0 if p==q else (ceil(F(q-p,7))*inv(p,q))%q
            th=FD(D,(m+S7)/U); rule='W-a (m=%d)'%m
            assert m+S7<=U*th<=m+F(6,7)
        else:
            m=p; x1=F(6,7)-F(1,7*p); x2=F(8,7)+F(1,7*p)
            th1=FD(D,(m+S7)/U)
            if U*th1-m<=x1: th=th1; rule='W-b window J'
            else:
                th=FD(D,(m+x2)/U); rule='W-b window J2'
                assert x2<=U*th-m<=F(13,7), 'W-b: first good point after x2 not in J2'
    elif u%D:                                       # rule M
        g1=gcd(u,D); D1=D//g1; j=ceil(F(D1,3)); k=(j*inv(u//g1,D1))%D1
        thc=F(k,D); h=min(F(1,7*D),F(4,21*u)); thL=thc-h
        if dist(U*thL)>=S7: th=thL; rule='M (no jump)'
        else:
            y=U*thL-round(U*thL); th=thL+(S7-y)/U; rule='M (jump)'
            assert th<=thc+h
    elif D==u:                                      # rule E
        g=gcd(U,u); P,Q=U//g,u//g
        if Q==1: th=F(1,7*u); rule='E (Q=1)'
        else:
            c,r=divmod(P,7); ip=ceil(F(Q-r,7)); i=(ip-c)%Q; n=(i*inv(P,Q))%Q
            th=(n+S7)/u; rule='E (Q=%d)'%Q
    elif D<=F(u*U,U+2*u):                           # rule small (Chair)
        th=F(1,7*u)
        if dist(U*th)<S7: y=U*th-round(U*th); th=th+(S7-y)/U
        rule='small'
    else:
        assert 2*D==u and U<2*u, 'exhaustiveness violated'
        th=F(1,7*D); rule='B'
    log.update(rule=rule); assert S_ok(u,U,D,th), 'condition (S) violated by %s'%rule
    return th
def blocked(P,c):                                   # alphas blocked by a class-c point at position P (sevenths)
    return {a for a in range(7) if ((P+c*a)%7<1 or (P+c*a)%7>6)}
def three_consecutive(Bs,c):                        # pair's blocked set, in beta=c*alpha coordinate, inside 3 consecutive
    beta={(c*a)%7 for a in Bs}
    return any(beta<= {(r+i)%7 for i in range(3)} for r in range(7))
def sgn(w): return w if w%7 in (1,2,3) else -w
def t7_2211(V,log=None):
    log={} if log is None else log
    Z=sorted(v//7 for v in V if v%7==0); W=[v for v in V if v%7]
    assert len(V)==6 and len(Z)==2 and len(W)==4
    s=[sgn(w) for w in W]; cl=[x%7 for x in s]
    rep=[c for c in set(cl) if cl.count(c)==2]; assert len(rep)==1 and sorted(cl.count(c) for c in set(cl))==[1,1,2]
    c=rep[0]; pair=sorted(x for x in s if x%7==c); s1,s2=pair; D=(s2-s1)//7; u,U=Z
    log.update(u=u,U=U,pair=tuple(pair),cls=c,D=D)
    if D==0:
        g=gcd(u,U); N=(u+U)//g; r=-(-N//3); mm=(inv(u//g,N)*r)%N; th=F(mm,u+U); log['rule']='D=0: H(u,U)'
    elif not in_Omega(u,U,D):
        th=thmA(u,U,D,log)
    else:
        m=(U//u)//7; eta0=S7+F(1,49*m); eps=F(1,7*m)
        if (s1>0)==(s2>0):                          # same sign (section 5.2)
            flip=s1<0
            a1=-s2 if flip else s1                   # positive representative of the smaller
            th0=eta0/u; x0=frac(a1*th0)
            th=th0 if x0<1-eps else th0+(1-x0)/a1
            if flip: th=-th
            log['rule']='Omega same sign (%s)'%('first' if x0<1-eps else 'second, P1 -> integer')+(' flipped' if flip else '')
        else:
            a=min(abs(s1),abs(s2))
            if a*(U+u)>=7*u*u:                       # min >= 7u^2/(U+u): theta0
                th=eta0/u; log['rule']='Omega opposite sign, theta0'
            else:                                   # Omega*: Chair's completion
                g=gcd(a,u); q=u//g; k=(inv(a//g,q)*(q//2))%q; th=(k+eta0)/u
                f=frac(a*th); assert q>=2 and eps<f<F(1,2)+eps
                log['rule']='Omega* (Chair): k=%d, small speed %s, f=%s'%(k,'+' if (s1 if abs(s1)==a else s2)>0 else '-',f)
        assert dist(u*th)>=S7 and dist(U*th)>=S7
        P1,P2=s1*th,s2*th
        assert three_consecutive(blocked(P1,c)|blocked(P2,c),c), 'Lemma N7prime premise not met'
    log['theta']=th
    for al in range(7):
        t=frac((th+al)/7)
        if all(dist(v*t)>=S7 for v in V): log.update(alpha=al,t=t); return t
    raise AssertionError('no alpha: %s'%log)
