# Opus's reviewed single-zero 2+2+1 implementation.
# Integration uses arithmetic indices for the four-candidate rule and
# only the gcd/modular-inverse construction for Lemma G.
from fractions import Fraction as F
from math import gcd, floor, ceil
from functools import reduce
from t7 import S7, frac, dist, inv
from sz311 import sz311, in_Istar
class Open(Exception): pass
class NotThisBranch(Exception): pass
def cls(w): r=w%7; return min(r,7-r)
def lt(x): x%=7; return x if x<=3 else x-7
def safe(V,t): return all(dist(v*t)>=S7 for v in V)
def first_alpha(V,th):
    for al in range(7):
        t=frac((th+al)/7)
        if safe(V,t): return al,t
    return None
def bad(W): W%=7; return W<1 or W>6            # open bad arc (-1,1) mod 7
def parse(V):
    g=reduce(gcd,V); W=[v//g for v in V]
    Z=[w for w in W if w%7==0]; R=[w for w in W if w%7]
    if len(W)!=6 or len(Z)!=1: raise NotThisBranch('not single-zero')
    cl=[cls(w) for w in R]
    if sorted(cl.count(k) for k in (1,2,3))!=[1,2,2]: raise NotThisBranch('not 2+2+1')
    u=Z[0]//7; pairs=[]
    for k in (1,2,3):
        Pk=[w for w in R if cls(w)==k]
        if len(Pk)==2:
            c=Pk[0]%7; s=sorted(w if w%7==c else -w for w in Pk); pairs.append((s,(s[1]-s[0])//7))
        else: w1=Pk[0]
    pairs.sort(key=lambda p:p[1]); (B,DB),(A,DA)=pairs
    return g,W,u,A,DA,B,DB,w1
GROUPS={(F(3),F(1)),(F(3),F(2)),(F(3,2),F(1)),(F(3,2),F(1,2)),(F(2),F(1,2)),(F(2),F(1))}
def lemmaG(W,u,u0,X,DA,Y,DB,w,th0,log,ctx):
    """Chair's direct version with a modular inverse."""
    d1,d2=gcd(gcd(u0,Y),X),gcd(gcd(u0,Y),w)
    if d1>1: d,third,v=d1,[X,X+7*DA],w
    elif d2>1: d,third,v=d2,[w],X
    else: raise AssertionError('Lemma G called without a common factor (%s)'%ctx)
    keep=[7*u,Y,Y+7*DB]+third
    assert all(s%d==0 for s in keep) and gcd(d,v)==1
    assert (DA*th0).denominator==1                                   # A pair merged at the base
    r0=first_alpha(keep,th0); assert r0 is not None, 'Lemma G (Chair): no alpha keeps zero, B pair and the third position'
    al,t0=r0; r=ceil(d*(S7-frac(v*t0))); j=(r*inv(v,d))%d; t=frac(t0+F(j,d))
    assert S7<=frac(v*t)<S7+F(1,d) and all(frac(s*t)==frac(s*t0) for s in keep)
    assert safe(W,t), 'Lemma G (Chair): final t not safe'
    log.update(lemmaG='%s: d=%d, third=%s, v=%s, theta_base=%s, alpha=%d, r=%d, j=%d'%(ctx,d,'A pair' if len(third)==2 else 'w',v,th0,al,r,j))
    return t
def walk_ok(u):                     # Chair (16:21 table, adopting the R1-review observation): ceil(2u/5) <= ceil(u/2) - 1, i.e. u not in {1,2,3,4,6,8}
    return ceil(F(2*u,5))<=ceil(F(u,2))-1
# ---------- Fable SZ221 R2: u* = 1 and the phantom system K0/K2 ----------
G3={('K0','I'):5,('K0','II'):1,('K2','I'):6,('K2','II'):3}
def fable_r2(W,u,A,B,d,w,Kph,log):
    Y=B[0]; X=A[0] if ((A[0]-3*Y)%7==0 or (A[0]-2*Y)%7==0) else -A[1]
    assert A[1]-A[0]==21 and B[1]-B[0]==7*d and d in (1,2) and u in (1,2)
    role='I' if (X-3*Y)%7==0 else 'II'; lam,mu=(3,2) if role=='I' else (2,3)
    assert (X-lam*Y)%7==0
    wn=w if (w-mu*Y)%7==0 else -w; assert (wn-mu*Y)%7==0
    # K from Fable's section-1 table must agree with the phantom system's K (R2/R3 definition, computed by sz311)
    ytab={('K0',1):0,('K0',2):1,('K2',1):2,('K2',2):0}; xw={('K0','I'):(2,1),('K2','I'):(1,2),('K0','II'):(1,2),('K2','II'):(2,1)}
    Kt=[K for K in ('K0','K2') if Y%3==ytab[(K,d)] and (X%3,wn%3)==xw[(K,role)]]
    assert Kt==[Kph], 'Fable R2 K table disagrees with the phantom system: %s vs %s'%(Kt,Kph)
    log.update(role=role,K=Kph,d=d,Xn=X,wn=wn)
    if d==1 or Y%2==1 or wn%2==1:
        if d==1: gam=2 if Y%2==0 else 3; case='(i)'
        elif Y%2==1: gam=1; case='(ii)'
        else: gam=G3[(Kph,role)]; case='(iii)'
        l,sg=divmod(Y,6); al=(inv(Y%7,7)*(gam-l))%7; t=frac(F(1+6*al,42))
        assert safe(W,t), 'Theorem 2 %s: table gamma not safe'%case
        log.update(rule='Fable R2 Theorem 2 %s: theta=1/6, sigma=%d, l=%d, gamma=%d, alpha=%d'%(case,sg,l,gam,al),theta=F(1,6),alpha=al)
        return t
    if u==1:                                                          # (iv), u = 1: theta = 1/2
        r=first_alpha(W,F(1,2)); assert r is not None, '(iv) u=1: theta=1/2 blocked'
        log.update(rule='Fable R2 (iv), u=1: theta=1/2, alpha=%d'%r[0],theta=F(1,2),alpha=r[0]); return r[1]
    Xe,Xo=(A[0],A[1]) if A[0]%2==0 else (A[1],A[0])                   # (iv), u = 2: halving
    half=[7,abs(Y)//2,abs(Y+7*d)//2,abs(w)//2,abs(Xe)//2]
    assert all(v%2==0 for v in (14,Y,Y+7*d,w,Xe)) and Xo%2==1
    r=first_alpha(half,F(1,7)); assert r is not None, '(iv) u=2: N7\' violated for the halved system'
    phi=r[1]; tj=[(j,frac((phi+j)/2)) for j in (0,1)]
    j,t=next((j,t) for j,t in tj if safe(W,t))
    log.update(rule='Fable R2 (iv), u=2: halving, phi=%s (alpha=%d), j=%d'%(phi,r[0],j),theta=F(1,7),alpha=r[0]); return t
# ---------- Chair 16:21 / 16:43: (2,1), gcd(u,Y) = 1, resonance b' = 2Y + 7uL ----------
def a_of(W,Y):
    c=[v for v in W if (v-3*Y)%7==0 or (v+3*Y)%7==0]
    v=c[0]; return v if (v-3*Y)%7==0 else -v
def resonance(W,u,Y,L,log):
    def n_of(f):                                                       # n with frac(Y(1+2n)/(2u)) = f, by the modular inverse
        rho=f*2*u; assert rho.denominator==1; rho=int(rho)
        if Y%2: x=(rho*inv(Y,2*u))%(2*u)
        else:
            x=((rho//2)*inv(Y//2,u))%u
            if x%2==0: x+=u
        n=(x-1)//2; assert frac(F(Y*(1+2*n),2*u))==f; return n
    if L%2==0:                                                         # even resonance: W = 2f+3 or 2f+2, never in (-1,1); Lemma J, n = 0
        th=F(1,2*u); r=first_alpha(W,th); assert r is not None, 'even resonance: Lemma J violated'
        log.update(rule='(2,1) even resonance (L=%d): W never blocks G, n=0'%L,theta=th,alpha=r[0]); return r[1]
    if u%4==2:                                                         # odd resonance, f = 1/4 exactly: b blocks only G
        n=n_of(F(1,4)); th=F(1+2*n,2*u); r=first_alpha(W,th); assert r is not None, 'f=1/4 exit violated'
        log.update(rule='(2,1) odd resonance, u=2 mod 4: f=1/4, n=%d'%n,theta=th,alpha=r[0]); return r[1]
    # Chair 16:43: four-candidate rule.  Lattice f = (r + 2j)/(2u), r = Y mod 2; n = Y^-1 (j + (r - Y)/2) mod u.
    # Side 1/4: the three largest lattice f in (0,1/4) and the next one in (1/4,1/2); else side 3/4 likewise in (1/2,3/4), (3/4,1).
    r=Y%2
    def n_of_j(j):
        n=(inv(Y,u)*(j+(r-Y)//2))%u if u>1 else 0
        assert frac(F(Y*(1+2*n),2*u))==F(r+2*j,2*u); return n
    for lo,mid,hi in ((F(0),F(1,4),F(1,2)),(F(1,2),F(3,4),F(1))):
        split = u * mid - F(r, 2)
        if split.denominator == 1:
            continue
        last_left = floor(split)
        first_right = last_left + 1
        if lo < F(r + 2 * (last_left - 2), 2 * u) and F(r + 2 * first_right, 2 * u) < hi:
            four = range(last_left - 2, first_right + 1)
            assert all(four[i+1]==four[i]+1 for i in range(3)), 'four points not consecutive'
            res=[]
            for j in four:
                n=n_of_j(j); th=F(1+2*n,2*u); rr=first_alpha(W,th); res.append(rr)
                if rr is not None:
                    log.update(rule='(2,1) odd resonance, Chair four candidates (side %s): f=%s, n=%d'%(mid,F(r+2*j,2*u),n),theta=th,alpha=rr[0])
                    # the proof: if the three left rounds are all blocked, the right one is not
                    return rr[1]
            raise AssertionError('four-candidate rule: all four rounds blocked')
    # Chair 16:56 supplement (endpoints f = 0, 1/2 admitted): u = 9 (Y even: left three + right one from f = 0; Y odd: right three + left one
    # up to f = 1/2) and u = 8 (1/16, 3/16, 5/16, then the half-turn point 9/16).  u = 4 is handled separately below.
    SM={(9,0):[F(0),F(1,9),F(2,9),F(3,9)],(9,1):[F(3,18),F(5,18),F(7,18),F(9,18)],(8,1):[F(1,16),F(3,16),F(5,16),F(9,16)]}
    if (u,r) in SM:
        for f in SM[(u,r)]:
            j=(f*2*u-r)/2; assert j.denominator==1; n=n_of_j(int(j)); th=F(1+2*n,2*u); rr=first_alpha(W,th)
            if rr is not None:
                log.update(rule='(2,1) odd resonance, Chair small-u supplement u=%d: f=%s, n=%d'%(u,f,n),theta=th,alpha=rr[0]); return rr[1]
        raise AssertionError('small-u supplement: all candidates blocked')
    if u==4:                                                           # Chair 17:02: f = 1/8, 3/8; then N_a = -11 -> f = 5/8, N_a = 10 -> t = k/112
        an=a_of(W,Y); e=(an-3*Y)//7; Na=(7*e*inv(Y,4)+3)%28; Na=Na-28 if Na>14 else Na
        for f in (F(1,8),F(3,8)):
            j=(f*8-r)/2; n=n_of_j(int(j)); th=F(1+2*n,8); rr=first_alpha(W,th)
            if rr is not None:
                log.update(rule='(2,1) odd resonance u=4: f=%s, n=%d'%(f,n),theta=th,alpha=rr[0]); return rr[1]
        assert Na in (-11,10), 'u=4: both rounds blocked but N_a=%d'%Na
        if Na==-11:
            n=n_of_j(2); th=F(1+2*n,8); rr=first_alpha(W,th); assert rr is not None, 'u=4, N_a=-11: f=5/8 blocked'
            log.update(rule='(2,1) odd resonance u=4: N_a=-11, f=5/8, n=%d'%n,theta=th,alpha=rr[0]); return rr[1]
        assert (an-38*Y)%56==0, 'u=4, N_a=10: a not = 38Y mod 56'
        k=(51*inv(Y,112))%112; t=F(k,112); assert safe(W,t), 'u=4, N_a=10: t=k/112 not safe'
        log.update(rule='(2,1) odd resonance u=4: N_a=10, t=k/112, k=%d'%k,theta=None,alpha=None); return t
    if u==1:                                                           # Chair 17:13 (partial): Y even signing; theta = 1/2; then t = 1/4 or theta = 1/4
        Ye=Y if Y%2==0 else -Y-7; assert Ye%2==0
        cls3=[v for v in W if (v-3*Ye)%7==0 or (v+3*Ye)%7==0]; cls2=[v for v in W if (v-2*Ye)%7==0 or (v+2*Ye)%7==0]
        sg3=sorted(v if (v-3*Ye)%7==0 else -v for v in cls3); sg2=sorted(v if (v-2*Ye)%7==0 else -v for v in cls2)
        an,bn=sg3[0],sg2[0]                                            # representative of the A pair: the one whose partner is +14 (Chair 17:24)
        assert (len(sg3)==1 or sg3[1]-sg3[0]==14) and (len(sg2)==1 or sg2[1]-sg2[0]==14)
        e=(an-3*Ye)//7; Lb=(bn-2*Ye)//7; Arole='a' if len(cls3)==2 else 'b'; assert Lb%2==1
        rr=first_alpha(W,F(1,2))
        if rr is not None:
            log.update(rule='(2,1) odd resonance u=1: theta=1/2',theta=F(1,2),alpha=rr[0]); return rr[1]
        assert e%2==1, 'u=1: theta=1/2 all blocked but e even'
        if Ye%4==2:
            t=F(1,4); assert safe(W,t), 'u=1: t=1/4 not safe'
            log.update(rule='(2,1) odd resonance u=1: Y=2 mod 4, t=1/4',theta=None,alpha=None); return t
        gam=1 if Arole=='a' else 2
        al=(inv(Ye%7,7)*(gam-Ye//4))%7; t=frac(F(1+4*al,28))
        if safe(W,t):
            log.update(rule='(2,1) odd resonance u=1: 4|Y, theta=1/4, gamma=%d (A pair %s-class)'%(gam,Arole),theta=F(1,4),alpha=al); return t
        assert (Arole=='a' and Lb%4==3) or (Arole=='b' and e%4==1), 'u=1: theta=1/4 gamma failed outside the stated remaining classes'
        # Chair 17:24 (corrected): step 1 theta = 3/8 with the table gamma (smallest in the intersection); step 2 theta = r/16 from the table
        from u1tables import S1, step2_entry
        T=S1[Ye%8]; G=(T['a_pair'][e%8]&T['b_single'][Lb%8]) if Arole=='a' else (T['a_single'][e%8]&T['b_pair'][Lb%8])
        if G:
            r,q,gam=3,8,min(G)
        else:
            assert Ye%8==4 and (Arole,e%8,Lb%8) in (('a',5,7),('b',1,1),('b',1,7),('b',5,7)), 'empty intersection outside the four rows'
            (r,gam),q=step2_entry(Arole,Ye,e,Lb),16
        al=(inv(Ye%7,7)*(gam-(r*Ye)//q))%7; t=frac(F(r+q*al,7*q))
        assert safe(W,t), 'u=1 closing step: table time not safe'
        log.update(rule='(2,1) odd resonance u=1 closing (Chair 17:24): theta=%d/%d, gamma=%d, alpha=%d'%(r,q,gam,al),theta=F(r,q),alpha=al); return t
    if u==3:                                                           # Chair 17:11: Y even signing; f = 0, then f = 1/3 (crosses 1/4)
        Ye=Y if Y%2==0 else -Y-7*u; assert Ye%2==0
        for j in (0,1):
            n=(inv(Ye,u)*(j-Ye//2))%u; th=F(1+2*n,2*u); assert frac(Ye*th)==F(j,u)
            rr=first_alpha(W,th)
            if rr is not None:
                log.update(rule='(2,1) odd resonance u=3: Y even signing, f=%d/3, n=%d'%(j,n),theta=th,alpha=rr[0]); return rr[1]
        raise AssertionError('u=3 two-base rule: both rounds blocked')
    if u in (5,7):                                                     # Chair 17:06: re-sign the B pair so that Y is even; f = 0, 1/u, 2/u
        Ye=Y if Y%2==0 else -Y-7*u; assert Ye%2==0
        for j in (0,1,2):
            n=(inv(Ye,u)*(j-Ye//2))%u; th=F(1+2*n,2*u); assert frac(Ye*th)==F(j,u)
            rr=first_alpha(W,th)
            if rr is not None:
                log.update(rule='(2,1) odd resonance u=%d: Y even signing, f=%d/%d, n=%d'%(u,j,u,n),theta=th,alpha=rr[0]); return rr[1]
        raise AssertionError('u=5,7 three-base rule: all three rounds blocked')
    raise AssertionError(f'odd resonance: covered u={u} had no candidate set')
# ---------- Chair 17:17: (2,1), gcd(u,Y) = 1, non-resonant, u in {2,3,4,6,8} (u = 1 has no non-resonant input) ----------
def Wval(Yv,ebv,n,u):
    th=F(1+2*n,2*u); P=Yv*th; f=P-floor(P); g0=-2 if f<=F(1,2) else 1
    return th,f,7*ebv*th+2*(f+g0)
def small_nonres(W,u,Y,bp,N,log):
    assert u!=1, 'u=1: N = 2 forced, no non-resonant input'
    if u==3:                                                           # Y even signing; N in {-5, 9}; f = 0 and 1/3 (N = 9) or 2/3 (N = -5)
        Ye,be=(Y,bp) if Y%2==0 else (-Y-21,-bp); eb=(be-2*Ye)//7; assert (be-2*Ye)%7==0
        Ne=(7*((eb*inv(Ye,3))%3)+2)%21; Ne=Ne-21 if Ne>10 else Ne; assert Ne==N and N in (-5,9)
        fs=[F(0),F(1,3)] if N==9 else [F(0),F(2,3)]
        res=[]
        for f in fs:
            j=int(f*3); n=(inv(Ye,3)*(j-Ye//2))%3; th,ff,Wv=Wval(Ye,eb,n,3); assert ff==f; res.append(Wv)
        d=(res[1]-res[0])%7; assert min(d,7-d)>2, 'u=3: W difference not above 2'
        for f in fs:
            j=int(f*3); n=(inv(Ye,3)*(j-Ye//2))%3; th=F(1+2*n,6); rr=first_alpha(W,th)
            if rr is not None:
                log.update(rule='(2,1) non-resonant u=3 (N=%d): Y even signing, f=%s, n=%d'%(N,f,n),theta=th,alpha=rr[0]); return rr[1]
        raise AssertionError('u=3 non-resonant: both rounds blocked')
    assert u%2==0 and Y%2==1
    eb=(bp-2*Y)//7; k=(N-2)//7; assert N==2+7*k
    nj=lambda j:(inv(Y,u)*(j+(1-Y)//2))%u                              # f = (1+2j)/(2u)
    if k%2:                                                            # half-turn pair f = 1/(2u), 1/(2u) + 1/2
        js=[0,u//2]; Ws=[Wval(Y,eb,nj(j),u) for j in js]
        assert [w[1] for w in Ws]==[F(1,2*u),F(1,2*u)+F(1,2)]
        d=(Ws[1][2]-Ws[0][2])%7; assert d==F(7,2), 'half-turn increment'
        for j in js:
            th=F(1+2*nj(j),2*u); rr=first_alpha(W,th)
            if rr is not None:
                log.update(rule='(2,1) non-resonant u=%d (N=%d, k odd): half-turn pair, f=%s'%(u,N,Ws[js.index(j)][1]),theta=th,alpha=rr[0]); return rr[1]
        raise AssertionError('half-turn pair: both rounds blocked')
    assert k!=0 and abs(N)>=12 and u in (4,6,8), 'k even branch premise'
    dn=inv(Y,u); n0=nj(0); th0,f0,W0=Wval(Y,eb,n0,u)
    def badW(x): x%=7; return x<1 or x>6
    if not badW(W0): st=0
    elif abs(N)>=2*u: st=1
    else:
        w0=W0%7; w0=w0-7 if w0>3 else w0
        st=ceil((1-w0)*u/N) if N>0 else ceil((w0+1)*u/(-N))
    assert st<=ceil(F(2*u,12)) and st<=u//2-1, 'walk too long'
    n=(n0+st*dn)%u; th,f,Wv=Wval(Y,eb,n,u); assert f==F(1,2*u)+F(st,u) and not badW(Wv)
    rr=first_alpha(W,th); assert rr is not None, 'walk: Lemma J violated'
    log.update(rule='(2,1) non-resonant u=%d (N=%d, k even): walk %d step(s), f=%s'%(u,N,st,f),theta=th,alpha=rr[0]); return rr[1]
def sz221(V,log=None):
    log={} if log is None else log
    g,W,u,A,DA,B,DB,w=parse(V)
    grp=(F(DA,u),F(DB,u))
    if grp not in GROUPS: raise NotThisBranch('ratio pair %s not among the six'%(grp,))
    X,Y=A[0],B[0]
    log.update(g=g,u=u,A=tuple(A),B=tuple(B),w=w,group='(%s,%s)'%grp)
    def out(t): assert safe(W,t); T=t/g; assert safe(V,T); log['t']=T; return T
    # ---------- groups with 3 or 3/2: phantom system, Theorem 1 ----------
    if grp[0] in (F(3),F(3,2)):
        us=u if grp[0]==3 else u//2; assert DA==3*us
        if DB==us: S=[Y,Y+7*us,Y+21*us]; ph=Y+21*us
        else: assert DB==2*us; S=[Y-7*us,Y,Y+14*us]; ph=Y-7*us
        PV=(7*us,)+tuple(abs(s) for s in S)+(abs(X),abs(w))
        assert len(set(PV))==6 and ph%7!=0
        log.update(phantom=ph,phantom_system=PV,u_star=us)
        sub={}
        try: t=sz311(PV,sub)
        except Exception as e:
            if 'premise gcd' in str(e):
                return out(lemmaG(W,u,us,X,DA,Y,DB,w,F(1,3*us),log,'Theorem 1, phantom gcd premise fails'))
            raise
        log.update(sub_rule=sub.get('rule'))
        if us==1 and (sub.get('K0') or sub.get('K2')):
            return out(fable_r2(W,u,A,B,DB,w,'K0' if sub.get('K0') else 'K2',log))
        ph_zero=frac(us*sub['theta']); assert ph_zero in (F(1,3),F(2,3)), 'Theorem 1: zero phase %s not a third'%ph_zero
        assert (frac(7*us*t) in (F(1,3),F(2,3)))
        log.update(rule='Theorem 1 -> sz311: %s'%sub.get('rule'))
        return out(t)
    # ---------- (2, 1/2) ----------
    if grp==(F(2),F(1,2)):
        u0=u//2; lam=lambda s: lt((s%7)*inv(Y%7,7))
        cand=[(X,lam(X)),(w,lam(w))]; a,la=[c for c in cand if abs(c[1])==3][0]; ea=(a-la*Y)//7
        gg=gcd(u,abs(Y)); q=u//gg; Yp=Y//gg
        def at(m):
            th=F(m,2*u); P1=Y*th; l=floor(P1); f=P1-l; Z=7*ea*th+la*(1+f); return th,f,l,Z
        m=None
        if Yp%2==0: m=q if q%4==1 else 3*q; rule='H1 (Y\' even)'
        elif q%2==1 and q>=3:
            m=inv(Yp,2*q)
            if m%4!=1: m+=2*q
            rule='H1 (Y\' odd, q odd >= 3)'
        elif q%2==0 and Yp%4==1: m=inv(Yp,2*q); rule='H1 (Y\' = 1 mod 4, q even)'
        elif q%2==0 and Yp%4==3 and q>=6: m=(3*inv(Yp,2*q))%(2*q); rule='H1 (Y\' = 3 mod 4, q even >= 6)'
        if m is not None:
            th,f,l,Z=at(m); assert m%4==1 and f<=F(1,4)
            r=first_alpha(W,th); assert r is not None, 'H1: N7\' violated'
            log.update(rule=rule+', m=%d, f=%s'%(m,f),theta=th,alpha=r[0]); return out(r[1])
        u1=u//2 if q in (1,2) else u//4; s=4 if q in (1,2) else 8
        assert q in (1,2,4) and u1*q*(2 if q in (1,2) else 4)//q>=1
        if u1>=2:
            assert Y%u1==0
            if gcd(u1,abs(a))>1: return out(lemmaG(W,u,u0,X,DA,Y,DB,w,F(1,2*u),log,'H2, gcd(u1,a)>1'))
            ks=(inv(ea,u1)*(u1//2))%u1; ms=[1,1+s*ks]; rule='H2 (u1=%d, k*=%d)'%(u1,ks)
        elif u==4 and q==4: ms=[1,5]; rule='H2 (u=4, q=4)'
        else:                                                          # Fable R3 / Chair 17:08: u = 2, sigma = Y mod 4 in {2,3}: theta = 1/4,
            assert u==2 and Y%4 in (2,3)                               # gamma = first of 1, 2, 3 that is safe; alpha = c^-1 (gamma - l)
            l4,sg=divmod(Y,4)
            for gam in (1,2,3):
                al=(inv(Y%7,7)*(gam-l4))%7; t=frac(F(1+4*al,28))
                if safe(W,t):
                    log.update(rule='Fable R3 Theorem 3: u=2, sigma=%d, theta=1/4, gamma=%d, alpha=%d'%(sg,gam,al),theta=F(1,4),alpha=al); return t
            raise AssertionError('Theorem 3: gamma = 1, 2, 3 all blocked')
        Zs=[]
        for m in ms:
            th,f,l,Z=at(m); assert f>F(1,4); Zs.append(Z)
            if not in_Istar(Z,la):
                r=first_alpha(W,th); assert r is not None, 'H2: F(ii) violated'
                log.update(rule=rule+', m=%d, f=%s, Z=%s'%(m,f,Z%7),theta=th,alpha=r[0]); return out(r[1])
        raise AssertionError('H2: both candidates have Z in I*: %s'%Zs)
    # ---------- (2, 1) ----------
    assert grp==(F(2),F(1))
    lam=lambda s: lt((s%7)*inv(Y%7,7))
    cand=[(X,lam(X)),(w,lam(w))]; b,lb=[c for c in cand if abs(c[1])==2][0]
    def Wof(n,lb,eb):
        th=F(1+2*n,2*u); P1=Y*th; l=floor(P1); f=P1-l; g0=-2 if f<=F(1,2) else 1
        return th,f,7*eb*th+lb*(f+g0)
    gg=gcd(u,abs(Y))
    if gg>=2:
        if gcd(gg,abs(b))>1: return out(lemmaG(W,u,u,X,DA,Y,DB,w,F(1,2*u),log,'rule J, gcd(g,b)>1'))
        eb=(b-lb*Y)//7; q=u//gg; ks=(inv(eb,gg)*(gg//2))%gg
        for n in (0,q*ks):
            th,f,Wv=Wof(n,lb,eb)
            if not bad(Wv):
                r=first_alpha(W,th); assert r is not None, 'rule J: Lemma J violated'
                log.update(rule='J (g=%d, n=%d, f=%s)'%(gg,n,f),theta=th,alpha=r[0]); return out(r[1])
        raise AssertionError('rule J: both candidates have W in (-1,1)')
    # gcd(u,Y) = 1: the Chair's walk (b signed to coefficient +2)
    bp=b if (b-2*Y)%7==0 else -b; eb=(bp-2*Y)//7
    Yi=inv(Y,u) if u>1 else 0
    N=(7*((eb*Yi)%u)+2)%(7*u)
    if N>7*u//2: N-=7*u
    log.update(N=N)
    if abs(N)==2:                                                     # resonance: b' = 2Y + 7uL
        L=eb//u; assert eb==u*L
        log.update(L=L)
        return out(resonance(W,u,Y,L,log))
    if not walk_ok(u): return out(small_nonres(W,u,Y,bp,N,log))
    par=Y%2                                                            # residues rho = Y(1+2n) mod 2u have parity of Y
    cnt0=(u-par)//2+1  # rho in [0,u] with that parity
    cnt1=u-cnt0
    if cnt0>=cnt1: rho0=par; cnt=cnt0; half=0
    else: rho0=u+1 if (u+1)%2==par else u+2; cnt=cnt1; half=1
    if par==1: x=(rho0*inv(Y,2*u))%(2*u)
    else:
        x=((rho0//2)*inv(Y//2,u))%u
        if x%2==0: x+=u
    n0=(x-1)//2; dn=Yi
    th,f,W0=Wof(n0,2,eb); assert f==F(rho0,2*u)
    th1,f1,W1=Wof(n0+dn,2,eb)
    if cnt>=2 and (f1<=F(1,2))==(f<=F(1,2)): assert (W1-W0-F(N,u))%7==0, 'step N/u'
    if not bad(W0): k=0
    elif abs(N)>=2*u: k=1
    else:
        w0=W0%7; w0=w0-7 if w0>3 else w0                               # representative in (-1,1)
        k=ceil((1-w0)*u/N) if N>0 else ceil((w0+1)*u/(-N))
    assert k<=ceil(F(2*u,5)) and k<=cnt-1, 'walk leaves the half'
    n=n0+k*dn; th,fk,Wk=Wof(n,2,eb)
    assert fk==f+F(k,u) and not bad(Wk)
    r=first_alpha(W,th); assert r is not None, 'Chair walk: Lemma J violated'
    log.update(rule='Chair walk (u=%d, N=%d, half %d, %d points, k=%d)'%(u,N,half,cnt,k),theta=th,alpha=r[0]); return out(r[1])
