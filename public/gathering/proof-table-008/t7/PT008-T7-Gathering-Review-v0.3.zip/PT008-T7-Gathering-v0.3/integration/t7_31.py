# Independent implementation of the Chair's message (2026-11-12 19:58): seven runners, two zero classes (7u <= 7U), four
# nonzero speeds of class pattern 3+1.  ONLY the parts whose formulas are written in that message are implemented:
#   * the dispatch (small adjacent difference / end-pair tests / narrowing of the remaining cases),
#   * the z = u clause theta = 2/(7u),
#   * the arithmetic-progression case (adjacent differences both 7u, r = U/u even): 7 does not divide r, and 7 | r with the
#     modular-inverse placement (u does not divide s1) or the integer push (u | s1),
#   * the step-2 direction via the already reviewed near-pair criterion (Theorem A of T7 R1 on a pair not in Omega).
# The three formulas only NAMED in the message (small-difference doubling, exact coincidence, equally-spaced doubling) are not
# defined there; inputs routed to them raise NotSpecified.  Exact Fractions, closed comparisons, no fallback.
from fractions import Fraction as F
from math import gcd, floor
from t7 import thmA, in_Omega, S7, frac, dist, inv, sgn
class NotSpecified(Exception): pass
def blocked(P,c): return {a for a in range(7) if ((P+c*a)%7<1 or (P+c*a)%7>6)}
def red_den(D,a): return D//gcd(D,a)                     # reduced denominator of a/D
def in_three_cells(P):                                     # all positions in one closed [n, n+3]  ==> at most 4 digits blocked
    return any(all(0<=((x-n)%7)<=3 for x in P) for n in range(7))
def H(a,b):
    g=gcd(a,b); N=(a+b)//g; r=-(-N//3); m=(inv(a//g,N)*r)%N; return F(m,a+b)

I_LOW=(F(1,7),F(3,7)); I_HIGH=(F(4,7),F(6,7))
def inI(f): return I_LOW[0]<=f<=I_LOW[1] or I_HIGH[0]<=f<=I_HIGH[1]     # phase f and 2f both safe
def f_small(u,U,D):                                   # formula 1: small-difference doubling
    assert D<=F(u*U,U+2*u)
    th0=F(1,7*u); f=frac(U*th0)
    if inI(f): b=f
    elif f<F(1,7): b=F(1,7)
    elif F(3,7)<f<F(4,7): b=F(4,7)
    else: b=F(8,7)
    th=th0+(b-f)/U; assert 0<=b-f<F(2,7)
    assert F(1,7)<=u*th<=F(3,7) and D*th<=S7 and inI(frac(U*th)), 'formula 1 claims'
    return th
def alr(x,D): r=x%D; return min(r,D-r)
def f_coin(u,U,D):                                    # formula 2: exact coincidence (any pair)
    assert D>0 and u%D and U%D
    a,b=sorted((alr(u,D),alr(U,D))); assert 0<a<=b<=F(D,2)
    g=gcd(a,b); p,q=a//g,b//g
    if p==q: m=0
    elif q==p+1: m=p
    else: m=(-(-(q-p)//7)*inv(p,q))%q
    L=(m+S7)/b; th=F(-(-(D*L.numerator)//L.denominator),D)  # ceil(D L)/D
    win=F(5,7*b) if q!=p+1 else (5-F(1,p))/(7*b)
    assert L<=th<=L+win and win>=F(4,7*b)>F(1,D)
    assert dist(u*th)>=S7 and dist(U*th)>=S7 and (D*th).denominator==1, 'formula 2 claims'
    return th
def f_eq(u,U,D):                                      # formula 3: equally-spaced doubling (any pair)
    A,B=(u,U) if u%D==0 else (U,u); assert A%D==0
    g=gcd(D,B); q=D//g; assert q>=3
    if q==3:
        j=next(jj for jj in range(3) if inI(frac(B*(F(jj,D)+F(1,7*A)))))
    else:
        m=-(-(q*(F(1,7)-F(B,7*A))).numerator//(q*(F(1,7)-F(B,7*A))).denominator)
        j=(m*inv(B//g,q))%q
        assert F(1,7)<=frac(B*(F(j,D)+F(1,7*A)))<F(1,7)+F(1,q)
    th=F(j,D)+F(1,7*A)
    assert frac(A*th)==F(1,7) and dist(D*th)<=S7 and inI(frac(B*th)), 'formula 3 claims'
    return th
def blocks_of(P,c): return set().union(*[blocked(p,c) for p in P])
def t7_31(V,log=None):
    log={} if log is None else log
    Z=sorted(v//7 for v in V if v%7==0); W=[v for v in V if v%7]
    assert len(V)==6 and len(Z)==2 and len(W)==4
    s=[sgn(w) for w in W]; cl=[x%7 for x in s]
    c=[k for k in set(cl) if cl.count(k)==3]; assert len(c)==1, 'not a 3+1 pattern'; c=c[0]
    tri=sorted(x for x in s if x%7==c); c1=[x%7 for x in s if x%7!=c][0]
    step=min((c*inv(c1,7))%7,(-c*inv(c1,7))%7); u,U=Z
    d1,d2=(tri[1]-tri[0])//7,(tri[2]-tri[1])//7; x,y=min(d1,d2),max(d1,d2); z=x+y
    log.update(u=u,U=U,triple=tuple(tri),cls=c,single_cls=c1,step=step,d=(d1,d2),x=x,y=y,z=z)
    dbl=False; need4=False
    if step==2:
        for D in (d1,d2,z):
            if D==0: th=H(u,U); log['rule']='step 2: coincident pair, H(u,U)'; break
            if not in_Omega(u,U,D): l={}; th=thmA(u,U,D,l); log['rule']='step 2: near pair D=%d via Theorem A (%s)'%(D,l['rule']); break
    elif x<=F(u*U,U+2*u):
        th=f_small(u,U,x); dbl=True; log['rule']='step 3: formula 1 (small-difference doubling) on D=x=%d'%x
    else:
        assert 3*z>2*u
        if u%z and U%z:
            th=f_coin(u,U,z); need4=True; log['rule']='step 3: formula 2 (exact coincidence) on end pair z=%d'%z
        elif (u%z==0)!=(U%z==0) and red_den(z,(U if u%z==0 else u))>=3:
            th=f_eq(u,U,z); dbl=True; log['rule']='step 3: formula 3 (equally-spaced doubling) on end pair z=%d'%z
        else:                                         # remaining cases: the message's narrowing
            need4=True
            assert z>=u, 'narrowing claim violated (z<u)'
            if z==u:
                assert U<2*u and F(U,u) in (1,F(3,2)), 'narrowing claim violated (z=u)'
                th=F(2,7*u); log['rule']='step 3: z=u, U/u in {1,3/2}, theta=2/(7u)'
            else:
                assert z==2*u and U%(2*u)==0, 'narrowing claim violated (z>u)'
                if x!=y:
                    assert u<y<2*u
                    if U%y: th=f_coin(u,U,y); log['rule']='step 3: formula 2 (exact coincidence) on y-pair y=%d'%y
                    else:
                        assert red_den(y,u)>=3; th=f_eq(u,U,y); dbl=True; need4=False
                        log['rule']='step 3: formula 3 (equally-spaced doubling) on y-pair y=%d'%y
                else:
                    assert d1==d2==u; r=U//u; assert r%2==0
                    if r%7:
                        th=F(1,7*u); log['rule']='step 3: AP, 7 does not divide r=%d, u*theta=1/7'%r
                    else:
                        Xv=S7+F(1,7*r); th0=Xv/u
                        if tri[0]%u:
                            g=gcd(abs(tri[0]),u); q=u//g; P1=tri[0]*th0; i=floor(q*frac(P1))
                            j=(-i*inv(tri[0]//g,q))%q; th=th0+F(j,u)
                            assert frac(tri[0]*th)<F(1,q)<=F(1,2)
                            log['rule']='step 3: AP, 7|r=%d, u does not divide s1: +j/u with j=%d (q=%d)'%(r,j,q)
                        else:
                            k=tri[0]//u; flip=False
                            if k<-7: k=-tri[2]//u; flip=True
                            assert k>=-7 and k%7
                            f=frac(k*Xv)
                            if f<=1-F(2,r): X2=Xv; tag='first point fraction <= 1-2/r, theta as is'
                            else:
                                assert k>=3; dl=(1-f)/k; assert dl<F(2,3*r)<F(5,7*r); X2=Xv+dl
                                tag='k=%d, push kX to the next integer (delta=%s)'%(k,dl)
                            th=X2/u
                            log['rule']='step 3: AP, 7|r=%d, u|s1: %s%s'%(r,tag,' [triple re-signed]' if flip else '')
    if need4:
        P=[x_*th for x_ in tri]; assert len(blocks_of(P,c))<=4, 'triple blocks more than 4 digits'
    assert dist(u*th)>=S7 and dist(U*th)>=S7, 'zero class unsafe'
    log['theta']=th
    for rnd,tt in ((1,th),(2,2*th)):
        if rnd==2:
            if not dbl: break
            P=[x_*tt for x_ in tri]
            assert len(blocks_of(P,c))<=4, 'doubling criterion violated: triple blocks > 4 at 2*theta'
            assert dist(u*tt)>=S7 and dist(U*tt)>=S7, 'zero class unsafe at 2*theta'
            log['doubling']='triggered'
        for al in range(7):
            t=frac((tt+al)/7)
            if all(dist(v*t)>=S7 for v in V): log.update(alpha=al,t=t); return t
    raise AssertionError('no alpha: %s'%log)
