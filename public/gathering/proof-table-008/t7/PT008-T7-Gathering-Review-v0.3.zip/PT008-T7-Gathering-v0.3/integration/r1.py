# Independent implementation of Fable R1 (claude/PT008-TRIPLE3-AND-REMAINING-BRANCHES-R1-FABLE.md) sections 2-6,
# written only from the manuscript, plus the reduction program of section 6 wired to the already-reviewed branch codes.
# Exact Fractions; closed comparisons (>= 1/6 is safe); fixed candidate lists only; NO fallback: an uncovered input raises.
from fractions import Fraction as F
from math import gcd
from functools import reduce
from p3 import P3, Cost, frac, dist
S=F(1,6)
def safe(V,t): return all(dist(v*t)>=S for v in V)
def inv(a,N): return pow(a%N,-1,N)
class Open(Exception): pass             # an input type the manuscript declares open (no fallback)

# ---------- section 2 (+ Chair's u-odd clause): triple-3 branch  [0; 3,3,3; w], 3 does not divide w ----------
def triple3(V,log):
    z=[v for v in V if v%6==0]; C=sorted(v//3 for v in V if v%6==3); W=[v for v in V if v%3]
    assert len(z)==1 and len(C)==3 and len(W)==1; u=z[0]//6; w=W[0]
    if u%2:                                                   # Chair clause 1: theta=1/4, t = 1/4 + j/3
        log['rule']='T3-uodd'
        for j in range(3):
            t=frac(F(1,4)+F(j,3))
            if safe(V,t): log['j']=j; return t
        raise AssertionError('u-odd clause failed')
    log['rule']='T3-ueven (sec 2)'
    s=[c if c%4==1 else -c for c in C]; e2,e3=(s[1]-s[0])//4,(s[2]-s[0])//4
    pl={}; th=P3(u//2,e2,e3,pl,Cost()); log.update(s=tuple(s),e=(e2,e3),P3case=pl['case'],thetap=th)
    y=[si*th/4 for si in s]
    ks=[k for k in range(4) if all(dist(F(1,2)+yi+F(k,4))>=S for yi in y)]; log['k_ok']=tuple(ks)
    assert ks, 'step (c) violated: no quarter-turn k keeps the three 3-class speeds safe'
    for m in range(12):
        t=frac(F(1,2)+(th+m)/12)
        assert frac(6*u*t)==frac((u//2)*th)                                   # step (a)
        assert all(frac(3*si*t)==frac(F(1,2)+yi+F(m,4)) for si,yi in zip(s,y))  # step (b)
        if safe(V,t):
            log['m']=m; log['m_ok_in_class']=tuple(mm for mm in range(m%4,12,4) if safe(V,frac(F(1,2)+(th+mm)/12)))
            return t
    raise AssertionError('Theorem 2 violated')

# ---------- section 3: three +-2 classes  [0; 2,2,2; odd] ----------
def trip2(V,log):
    z=[v for v in V if v%6==0]; Bw=sorted(v for v in V if v%6 in (2,4)); X=[v for v in V if v%2]
    assert len(z)==1 and len(Bw)==3 and len(X)==1; u=z[0]//6
    B=[b if b%6==2 else -b for b in Bw]; e2,e3=(B[1]-B[0])//6,(B[2]-B[0])//6
    pl={}; th=P3(u,e2,e3,pl,Cost()); log.update(rule='TRIP2 (sec 3)',B=tuple(B),e=(e2,e3),P3case=pl['case'],theta=th)
    for al in range(6):
        t=frac((th+al)/6)
        if safe(V,t): log['alpha']=al; return t
    raise AssertionError('Theorem 3 violated')

# ---------- section 4: [0; +-1; +-2,+-2; 3] ----------
def sec4(V,log):
    z=[v for v in V if v%6==0]; C=[v for v in V if v%6==3]
    assert len(z)==1 and len(C)==1 and len([v for v in V if v%6 in (1,5)])==1 and len([v for v in V if v%6 in (2,4)])==2
    u=z[0]//6; c=C[0]//3; g=gcd(u,c); p=u//g; N=(u+c)//g; r=-(-N//3); m=(inv(p,N)*r)%N
    th=F(m,u+c); log.update(rule='SEC4',g=g,p=p,N=N,r=r,m=m,theta=th)
    assert dist(u*th)>=F(1,3) and dist(c*th)>=F(1,3), 'step (a) violated'
    assert all(dist(C[0]*(th+al)/6)>=S for al in range(6)), 'step (c) violated'
    for al in range(6):
        t=frac((th+al)/6)
        if safe(V,t): log['alpha']=al; return t
    raise AssertionError('Theorem 4 violated')

# ---------- (2,2,0) double +-2: Chair's proof (Fable-reviewed); implemented only as a dependency, not reviewed here ----------
def v3(x):
    c=0
    while x%3==0: x//=3; c+=1
    return c
def b2(V,log):
    z=[v for v in V if v%6==0]; A=sorted(v for v in V if v%6 in (1,5))
    assert len(z)==1 and len(A)==2 and len([v for v in V if v%6 in (2,4)])==2; u=z[0]//6
    s=[a if a%6==1 else -a for a in A]; d=(s[1]-s[0])//6
    h=gcd(u,abs(d)); up,dp=u//h,d//h
    if dp%2==0: thp=F(1,2); case='even'
    else:
        n=3**(v3(up)+1); gg=gcd(abs(dp),n); N=n//gg
        if N==1: thp=F(1,n); case='N=1'
        elif N>=9: k=inv((dp//gg)%N,N); thp=F(k,n); case='N>=9'
        else: thp=F(1,n)+F(1,2); case='N=3'
    th=frac(thp)/h; log.update(rule='B2 (Chair)',d=d,case=case,theta=th)
    assert dist(u*th)>=S and dist(d*th)<=S
    for al in range(6):
        t=frac((th+al)/6)
        if safe(V,t): log['alpha']=al; return t
    raise AssertionError('B2 violated')

# ---------- section 5: single-zero dispatch (k = 5) ----------
import a5direct, p3 as P3mod, mixed5b, dbl3 as D3
def typ(V):
    n1=sum(v%6 in (1,5) for v in V); n2=sum(v%6 in (2,4) for v in V); n3=sum(v%6==3 for v in V); return (n1,n2,n3)
def single_zero(V,log):
    z=[v for v in V if v%6==0][0]; T=typ(V); log['type']=T
    A=[v for v in V if v%6 in (1,5)]; R=[v for v in V if v%6 not in (0,1,5)]
    if T==(4,0,0): log['rule']='A5'; t,_=a5direct.a5((z,*A)); return t
    if T in ((3,1,0),(3,0,1)): log['rule']='P3'; t,_=P3mod.branch((z,*A,*R)); return t
    if T==(2,2,0): return b2(V,log)
    if T==(2,1,1): log['rule']='MIXED v1.1'; t,_=mixed5b.mixed_full(V); return t
    if T in ((2,0,2),(1,1,2),(0,2,2)): log['rule']='DBL3 (Chair)'; t,_=D3.dbl3(V); return t
    if T in ((1,0,3),(0,1,3)): return triple3(V,log)
    if T in ((1,3,0),(0,3,1)): return trip2(V,log)
    if T==(1,2,1): return sec4(V,log)
    raise AssertionError('type %s cannot occur after normalisation'%(T,))

# ---------- section 6: normalisation, R0, R1 (padding), R2 (Lemma Lambda), recursion ----------
def tf(V,trace=None,depth=0):
    trace=[] if trace is None else trace; V=tuple(V); ind='  '*depth
    g=reduce(gcd,V)
    if g>1:
        trace.append(ind+'normalise: divide by %d'%g); t=tf(tuple(v//g for v in V),trace,depth)/g; t=frac(t)
        assert safe(V,t); return t
    z=[v for v in V if v%6==0]
    if not z: trace.append(ind+'R0 %s: t=1/6'%(V,)); return F(1,6)
    if len(z)==1 and len(V)<=5:
        P=list(V); x=1
        while len(P)<5:                                   # R1: pad with the smallest unused +-1 speeds
            while x in P or x%6 not in (1,5): x+=1
            P.append(x); x+=1
        log={}; t=frac(single_zero(tuple(P),log))
        trace.append(ind+'%s %s: type %s -> %s, t=%s'%('R1 pad' if len(V)<5 else 'sec5',tuple(P) if len(V)<5 else V,log['type'],log['rule'],t))
        assert safe(V,t); return t
    for p in (3,2):                                       # R2 (Lemma Lambda); convention: p=3 tried before p=2
        Wp=[v for v in V if v%p]
        if len(Wp)<=p-1:
            M=tuple(v//p for v in V if v%p==0)
            trace.append(ind+'R2 Lambda p=%d on %s: reduce to %s, |W|=%d'%(p,V,M,len(Wp)))
            phi=tf(M,trace,depth+1)
            assert all(dist(m*phi)>=S for m in M)
            for j in range(p):
                t=frac((phi+j)/p)
                if safe(V,t): trace.append(ind+'  j=%d -> t=%s'%(j,t)); return t
            raise AssertionError('Lemma Lambda violated')
    T=','.join('0'*len(z))+';'+','.join('+-1' if v%6 in (1,5) else '+-2' if v%6 in (2,4) else '3' for v in V if v%6)
    import dz                                             # R2: the two former OPEN leaves (Fable R2)
    n1=sum(v%6 in (1,5) for v in V); n2=sum(v%6 in (2,4) for v in V)
    if len(V)==5 and len(z)==2 and (n1,n2)==(3,0): log={}; t=dz.type1(V,log)
    elif len(V)==5 and len(z)==2 and (n1,n2)==(2,1): log={}; t=dz.type2(V,log)
    else:
        trace.append(ind+'OPEN type [%s] for %s'%(T,V)); raise Open('[%s] %s'%(T,V))
    trace.append(ind+'R2-leaf [%s] %s: %s %s, theta=%s, t=%s'%(T,V,log['rule'],log.get('clause',log.get('path','')),log['theta'],t))
    assert safe(V,t); return t
