"""Exact directed checks for each dispatch route."""
from fractions import Fraction as F

from time_forge7 import time_forge7

CASES = (
    ((1, 2, 3, 4, 5, 6), "Z0", F(1, 7)),
    ((7, 1, 8, 15, 22, 29), "Z1:5", F(3, 14)),
    ((49, 1, 8, 15, 197, 198), "Z1:4+1", F(29, 196)),
    ((49, 86, 142, 282, 1, 85), "Z1:3+2", F(43, 98)),
    ((210, 109, 319, 739, 449, 796), "Z1:3+1+1", F(199, 630)),
    ((7, 4, 11, 19, 33, 29), "Z1:2+2+1", F(19, 56)),
    ((7, 4, 11, 29, 43, 19), "Z1:2+2+1", F(19, 56)),
    ((28, 35, 8, 64, 134, 190), "Z2:4", F(59, 196)),
    ((7, 98, 6, 13, 20, 2), "Z2:3+1", F(31, 42)),
    ((7, 21, 1, 29, 2, 3), "Z2:2+1+1", F(153, 196)),
    ((28, 35, 86, 142, 1, 85), "Z2:2+2", F(43, 98)),
    ((49, 7, 1, 8, 2, 9), "Z2:2+2", F(57, 343)),
    ((7, 7, 1, 8, 2, 9), "Z2:2+2", F(8, 49)),
    ((7, 49, 1, 1, 2, 2), "Z2:2+2", F(57, 343)),
    ((6, 36, 1, 7, 2, 2), "T6:repeated absolute speeds", F(43, 216)),
    ((7, 14, 21, 1, 2, 3), "Z3", F(1, 6)),
    ((7, 14, 21, 28, 1, 2), "Z4", F(1, 6)),
    ((7, 14, 21, 28, 35, 1), "Z5", F(1, 6)),
    ((21, 7, 1, 8, 2, 9), "Z2:2+2", F(8, 49)),
    ((28, 7, 1, 8, 2, 9), "Z2:2+2", None),
    ((42, 7, 1, 8, 2, 9), "Z2:2+2", None),
    ((14, 7, 1, 8, 2, 9), "Z2:2+2", None),
    ((35, 7, 1, 8, 2, 9), "Z2:2+2", None),
    ((2, 3, 6, 14, 16, 45), "Z1:2+2+1", F(2, 21)),
    ((1, 2, 4, 18, 28, 57), "Z1:2+2+1", F(17, 56)),
    ((1, 2, 4, 14, 16, 29), "Z1:2+2+1", F(5, 28)),
    ((91, 1, 92, 93, 275, 3), "Z1:2+2+1", F(27, 182)),
    ((77, 2, 79, 81, 235, 6), "Z1:2+2+1", F(141, 154)),
    ((154, 1, 155, 156, 464, 3), "Z1:2+2+1", F(5, 28)),
    ((105, 28, 1, 8, 2, 9), "Z2:2+2", None),
    ((343, 56, 1, 8, 2, 9), "Z2:2+2", None),
    ((54, 13, 2, 16, 5, 19), "Z0", F(1, 7)),
)


def check_distance(speeds, t):
    p, q = t.numerator, t.denominator
    residues = [(v * p) % q for v in speeds]
    assert all(7 * min(r, q - r) >= q for r in residues)


def main():
    for speeds, branch, expected in CASES:
        log = {}
        t = time_forge7(speeds, log)
        assert log["branch"] == branch
        assert expected is None or t == expected
        check_distance(speeds, t)
        signed_scaled = tuple((-3 if i % 2 else 3) * v for i, v in enumerate(speeds))
        assert time_forge7(signed_scaled) == t / 3
        check_distance(signed_scaled, t / 3)
        if branch == "Z2:2+2":
            detail = log["detail"]
            assert detail["u"] <= detail["U"]
            assert 0 <= detail["delta"] < F(2, 7 * detail["U"])
            if speeds[0] == 105:
                assert detail["delta"] == F(1, 420)
            if speeds[0] == 343:
                assert detail["delta"] == F(15, 2744)
            for k in (1, 2):
                check_distance((detail["u"], detail["U"]), k * detail["theta"])
            if speeds == (28, 35, 86, 142, 1, 85):
                assert detail["round"] == 2
                for alpha in range(7):
                    first_round_time = (detail["theta"] + alpha) / 7
                    p, q = first_round_time.as_integer_ratio()
                    residues = [(v * p) % q for v in speeds]
                    assert any(7 * min(r, q - r) < q for r in residues)
        print(f"{speeds} -> {branch}: {t}")

    u = 2**128 + 1
    speeds = (7*u, 1, 1+7*u, 2+7*u, 2+21*u, 3)
    log = {}
    t = time_forge7(speeds, log)
    assert "four candidates" in log["detail"]["leaf"]
    check_distance(speeds, t)
    print(f"Large odd-resonance input u={u}: {t}")

    for invalid in ((1, 2), (0, 1, 2, 3, 4, 5), (True, 1, 2, 3, 4, 5)):
        try:
            time_forge7(invalid)
        except ValueError:
            continue
        raise AssertionError(f"invalid input accepted: {invalid}")
    print(f"{2 * len(CASES)} directed inputs passed, including signed/scaled variants")


if __name__ == "__main__":
    main()
