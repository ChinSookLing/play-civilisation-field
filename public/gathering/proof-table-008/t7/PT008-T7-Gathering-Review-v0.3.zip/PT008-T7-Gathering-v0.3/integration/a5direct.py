# Independent implementation of "A5 分支直接構造：作者定稿 v1.0" (Fable), written ONLY from the manuscript.
# Exact integers / Fractions.  No safe-time search, no fallback.  Deterministic conventions (stated in the report):
#   * modular inverse: least positive residue in [1, N-1];  kappa2 = (2*kappa1) mod N;  kappa_j = (j*inv) mod N_C
#   * theta' := frac(candidate);  alpha := (ceil(1-6b)) mod 6 in {0..5};  start b = smallest index (i=2..5)
#   * candidate orders exactly as in Section 6.
from fractions import Fraction as F
from math import gcd, ceil, floor
H=F(1,2)
def frac(x): return x-floor(x)
def dist(x): x=frac(x); return min(x,1-x)
def v_p(x,p):
    if x==0: return float('inf')
    c=0
    while x%p==0: x//=p; c+=1
    return c
def inv(a,N): return pow(a%N,-1,N)
def start(points):
    """smallest index j with frac(y_i - y_j) <= 1/2 for all i (clustering test); None if not clustered"""
    for j,b in enumerate(points):
        if all(frac(y-b)<=H for y in points): return j
    return None
def clustered(points): return start(points) is not None

def lemmaA(T,k,log):
    t1=T[0]; d2,d3=T[1]-t1,T[2]-t1
    v=v_p(gcd(d2,d3),2) if (d2,d3)!=(0,0) else float('inf')
    kp=max(1,k-v) if v!=float('inf') else 1
    cands=[1]+([1+2**(kp-1)] if kp>=2 else [])
    log.update(lemmaA_v=v,lemmaA_kprime=kp,lemmaA_cands=cands)
    for a in cands:
        if clustered([F(a*ti,2**k) for ti in T]): log['a0']=a; return a
    raise AssertionError('Lemma A violated')

def P_star(u,D,log):
    assert D[0]==0 and u>=1
    g=gcd(gcd(abs(D[1]),abs(D[2])),abs(D[3])); h=gcd(u,g)
    up=u//h; Dp=[e//h for e in D]
    log.update(g=g,h=h,u1=up,D1=tuple(Dp))
    if up%2==1:
        log['type']='O'; thp=H
    else:
        m=sum(1 for e in Dp if e%2)
        if m in (1,3):
            log['type']='3+1 (m=%d)'%m
            if m==3:
                c=next(e for e in Dp if e%2); Dt=[e-c for e in Dp]; log['translate_by']=c
            else: Dt=list(Dp)
            ev=[e for e in Dt if e%2==0]; gam=[e for e in Dt if e%2][0]
            assert len(ev)==3
            tau=[e//2 for e in ev]; r=v_p(up,2)
            log.update(even_tau=tuple(tau),gamma=gam,r=r)
            a0=lemmaA(tau,r,log)
            base=F(a0,2**(r+1)); thp=None
            for cand,tag in ((base,'no half-shift'),(base+H,'half-shift')):
                if clustered([frac(e*cand) for e in Dp]): thp=frac(cand); log['shift']=tag; break
            if thp is None: raise AssertionError('Lemma B violated')
        else:
            log['type']='2+2'
            s=v_p(up,3); n=3**(s+1)
            ev=[e for e in Dp if e%2==0]; od=[e for e in Dp if e%2]
            p1,p2=ev; q1,q2=od
            A,B,C=p2-p1,q2-q1,q1-p1
            def NX(X): gg=gcd(X,n); return n//gg, (X//gg)%(n//gg)
            (NA,Ao),(NB,Bo),(NC,Co)=NX(A),NX(B),NX(C)
            log.update(s=s,n=n,p=(p1,p2),q=(q1,q2),A=A,B=B,C=C,N_A=NA,N_B=NB,N_C=NC)
            def nrm(x): return dist(x)
            if not (NA==3 and NB==3):
                if NA==1 and NB==1: kap=1; br='S(a)'
                elif NA!=NB:
                    NXx,Xo=(NA,Ao) if NA>NB else (NB,Bo); kap=inv(Xo,NXx); br='S(b)'
                else:
                    N=NA; k1=inv(Ao,N)
                    if nrm(F(k1*A,n))+nrm(F(k1*B,n))<=H: kap=k1; br='S(c) kappa1'
                    else: kap=(2*k1)%N; br='S(c) kappa2'
                assert kap%3 and nrm(F(kap*A,n))+nrm(F(kap*B,n))<=H, 'Lemma S violated'
                log.update(branch=br,kappa=kap,pair_sum=nrm(F(kap*A,n))+nrm(F(kap*B,n)))
            else:
                def eps_of(k,X):
                    y=frac(F(k*X,n)); assert y in (F(1,3),F(2,3)); return 1 if y==F(1,3) else -1
                sigma=eps_of(1,A)*eps_of(1,B)
                if NC==1: kap=1; br='exc N_C=1'
                elif NC==3: kap=1; br='exc N_C=3'
                elif sigma==1: kap=inv(Co,NC); br='exc N_C>=9 sigma=+1'
                else:
                    kap=None
                    for j in (1,2):
                        kj=(j*inv(Co,NC))%NC
                        if eps_of(kj,A)==-1: kap=kj; br='exc N_C>=9 sigma=-1 j=%d'%j; break
                    assert kap is not None
                log.update(branch=br,sigma=sigma,kappa=kap,eps=eps_of(kap,A),eta=eps_of(kap,B),z=frac(F(kap*C,n)))
            base=F(kap,n); thp=None
            for cand,tag in ((base,'flat'),(base+H,'flipped')):
                if clustered([frac(e*cand) for e in Dp]): thp=frac(cand); log['version']=tag; break
            if thp is None: raise AssertionError('Lemma C violated')
    theta=thp/h
    log.update(theta1=thp,theta=theta,u_theta=frac(u*theta))
    assert dist(u*theta)>=F(1,6), '(i) fails'
    assert clustered([frac(e*theta) for e in D]), '(ii) fails'
    return theta

def a5(V,log=None):
    log={} if log is None else log
    v1,W=V[0],list(V[1:]); assert v1%6==0 and all(w%6 in (1,5) for w in W)
    u=v1//6; s=[w if w%6==1 else -w for w in W]
    D=[(si-s[0])//6 for si in s]
    log.update(u=u,signed=tuple(s),D=tuple(D))
    theta=P_star(u,D,log)
    tau=theta/6
    y=[frac(si*tau) for si in s]
    j=start(y); assert j is not None, 'actual phases not clustered'
    b=y[j]; at=ceil(1-6*b); al=at%6
    assert F(1)<=6*b+at<F(2)
    t=(theta+al)/6
    log.update(tau=tau,y=tuple(y),b_index=j+2,b=b,alpha_tilde=at,alpha=al,t=t)
    d=[dist(x*t) for x in V]; log['dists']=tuple(d)
    ok=all(x>=F(1,6) for x in d); log['SAFE']=ok
    if not ok: raise AssertionError('final check failed: %s'%(d,))
    return t,log
