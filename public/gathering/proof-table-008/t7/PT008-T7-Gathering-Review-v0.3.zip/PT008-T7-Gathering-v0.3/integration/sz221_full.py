# Full single-zero 2+2+1 entry: the Chair's front dispatch (2026-11-13 16:43) wired to the reviewed six-group program sz221.py.
#   gcd reduction -> step 1 (repeated pair speed: theta = 1/(7u); a pair with N = D/gcd(D,u) >= 4: theta = j/D, four-point three-round)
#   -> step 2 (D_A, D_B <= u: theta = 1/(7u), double near-point) -> step 3 (theta = k/(7u): the six groups go to sz221; otherwise
#   q >= 4: k = k0 + 7 h l with l from one rounding and one modular inverse; q <= 3: the Chair's k table).
# Exact Fractions, closed comparisons, fixed candidate lists (first safe alpha, rounds in order), no fallback.
from fractions import Fraction as F
from math import gcd, ceil, floor
from functools import reduce
from t7 import S7, frac, dist, inv
from sz221 import sz221, Open
class NotThisBranch(Exception): pass
def cls(w): r=w%7; return min(r,7-r)
def safe(V,t): return all(dist(v*t)>=S7 for v in V)
def rounds(W,th,K,log):
    for k in range(1,K+1):
        for al in range(7):
            t=frac((k*th+al)/7)
            if safe(W,t): log.update(round=k,alpha=al); return t
    raise AssertionError('no safe candidate in %d round(s) at theta=%s'%(K,th))
SIX={(F(3),F(1)),(F(3),F(2)),(F(3,2),F(1)),(F(3,2),F(1,2)),(F(2),F(1,2)),(F(2),F(1))}
K0H={F(3,2):(4,2),F(2):(3,1),F(3):(2,1)}
KTAB={(F(3,2),F(1,3)):18,(F(3,2),F(2,3)):32,(F(3,2),F(1,4)):4,(F(3,2),F(3,4)):18,(F(3,2),F(1,6)):4,
      (F(2),F(1,3)):3,(F(2),F(2,3)):10,(F(3),F(1,2)):2,(F(3),F(1,3)):2,(F(3),F(2,3)):9,
      (F(3,2),F(3,2)):4,(F(2),F(2)):3,(F(3),F(3)):2,(F(2),F(3,2)):4,(F(3),F(3,2)):5}
def d7(x): x%=7; return min(x,7-x)
def sz221_full(V,log=None):
    log={} if log is None else log
    g=reduce(gcd,V); W=[v//g for v in V]
    Z=[w for w in W if w%7==0]; R=[w for w in W if w%7]
    if len(W)!=6 or len(Z)!=1: raise NotThisBranch('not single-zero')
    cl=[cls(w) for w in R]
    if sorted(cl.count(k) for k in (1,2,3))!=[1,2,2]: raise NotThisBranch('not 2+2+1')
    u=Z[0]//7; Ds=[]
    for k in (1,2,3):
        Pk=[w for w in R if cls(w)==k]
        if len(Pk)==2:
            c=Pk[0]%7; s=sorted(w if w%7==c else -w for w in Pk); Ds.append((s[1]-s[0])//7)
    DB,DA=sorted(Ds); log.update(g=g,u=u,DA=DA,DB=DB)
    def out(t): assert safe(W,t); T=t/g; assert safe(V,T); log['t']=T; return T
    # ---- step 1 ----
    if DB==0:
        th=F(1,7*u); log.update(leaf='1: repeated pair speed, theta=1/(7u)',theta=th); return out(rounds(W,th,3,log))
    for name,D in (('A',DA),('B',DB)):
        gD=gcd(D,u); N=D//gD
        if N>=4:
            j=(inv(u//gD,N)*ceil(F(N,7)))%N; th=F(j,D)
            assert S7<=frac(u*th)<=F(2,7) and (7*D*th).denominator==1
            log.update(leaf='1: four-point three-round, pair %s, D=%d, N=%d'%(name,D,N),theta=th); return out(rounds(W,th,3,log))
    # ---- step 2 ----
    if DA<=u:
        th=F(1,7*u); log.update(leaf='2: both differences <= u, theta=1/(7u), double near-point',theta=th); return out(rounds(W,th,1,log))
    # ---- step 3 ----
    RA,B=F(DA,u),F(DB,u)
    assert RA.numerator<=3 and B.numerator<=3 and RA in (F(3,2),F(2),F(3)), 'step 3 premise'
    if (RA,B) in SIX:
        sub={}; t=sz221(tuple(W),sub); log.update(leaf='3: six groups -> sz221: %s'%(sub.get('rule') or 'Lemma G'),theta=sub.get('theta'),alpha=sub.get('alpha'))
        return out(t)
    k0,h=K0H[RA]; n,d=B.numerator,B.denominator; q=d//gcd(d,h)
    if B<=1 and q>=4:
        m=(n*h//gcd(d,h))%q; x0=frac(B*k0/7)
        i=round(-x0*q)%q; l=(i*inv(m,q))%q; k=k0+7*h*l
        assert dist(B*k/7)<=F(1,2*q), 'rounding: distance above 1/(2q)'
        how='k=k0+7hl, q=%d, l=%d'%(q,l)
    else:
        k=KTAB[(RA,B)]; how='k from the Chair table'
    assert k%7!=0 and d7(RA*k)<=1 and d7(B*k)<=1, 'step 3: k does not give zero safe and both pairs within one cell'
    th=F(k,7*u); log.update(leaf='3: (%s,%s) %s, k=%d'%(RA,B,how,k),theta=th); return out(rounds(W,th,1,log))
