# Independent implementation of Fable R2 (claude/PT008-DOUBLE-ZERO-R2-FABLE.md): Lemma S, type 2 [0,0;+-1,+-1,+-2],
# type 1 [0,0;+-1,+-1,+-1] (R clause: base point + lift; L clause: grid lock).  Written only from the manuscript.
# Exact Fractions, closed comparisons, fixed step counts, no fallback.
from fractions import Fraction as F
from math import gcd, floor, ceil
from p3 import P3, Cost, frac, dist
S6=F(1,6); T3=F(1,3)
def phi(v,c,th): return frac(v*th-c)
def good(v,c,th): return phi(v,c,th)<=F(2,3)
def J(v,c,th):
    p=phi(v,c,th); return th if p<=F(2,3) else th+(1-p)/v
def lemmaS(cons,log):
    """cons: list of (name, v, c) in the manuscript order u1,u2,d; sorted stably by v (ties keep that order)."""
    cs=sorted(cons,key=lambda x:x[1]); log['order']=tuple(n for n,_,_ in cs)
    (na,a,ca)=cs[0]; th0=ca/a; ths=[th0]
    if len(cs)==2:
        (nb,b,cb)=cs[1]; th=J(b,cb,th0); ths.append(th)
    else:
        (nb,b,cb),(nc,c,cc)=cs[1],cs[2]
        th1=J(b,cb,th0); th2=J(c,cc,th1); th3=J(b,cb,th2); th4=J(c,cc,th3); ths+= [th1,th2,th3,th4]; th=th4
    jumps=tuple(ths[i+1]-ths[i] for i in range(len(ths)-1)); log.update(theta0=th0,jumps=jumps,nonzero_jumps=sum(1 for x in jumps if x))
    if len(cs)==3:
        d=jumps
        path='(1) b bad at theta0' if d[0] else ('(2a) none' if not d[1] else ('(2b) c only' if not d[2] else ('(2b) b again, delta4=0' if not d[3] else '(2b) FOURTH JUMP')))
        log['path']=path
        if d[3]: assert F(2,3)/c < F(1,3)/b, 'manuscript inequality 2/(3c)<1/(3b) fails'
    assert th-th0 < F(2,3)/a or th==th0
    for n,v,c in cs: assert good(v,c,th), 'Lemma S violated for %s'%n
    return th
def sgn(w): return w if w%6==1 else -w
def first_alpha(V,th,log):
    for al in range(6):
        t=frac((th+al)/6)
        if all(dist(v*t)>=S6 for v in V): log['alpha']=al; return t
    raise AssertionError('no alpha -- theorem violated: %s'%log)
def type2(V,log):
    Z=sorted(v//6 for v in V if v%6==0); A=sorted(v for v in V if v%6 in (1,5)); Bq=[v for v in V if v%6 in (2,4)]
    assert len(Z)==2 and len(A)==2 and len(Bq)==1
    s=[sgn(a) for a in A]; d=(s[1]-s[0])//6; u1,u2=Z
    log.update(rule='DZ type 2',u=(u1,u2),d=d)
    cons=[('u1',u1,S6),('u2',u2,S6)]+([('d',abs(d),F(2,3))] if d else [])
    th=lemmaS(cons,log); log['theta']=th
    assert dist(u1*th)>=S6 and dist(u2*th)>=S6 and dist(d*th)<=T3
    log['d_theta']=dist(d*th)
    return first_alpha(V,th,log)
def tri(u1,u2):
    g=gcd(u1,u2); N=(u1+u2)//g; r=-(-N//3); m=(pow((u1//g)%N,-1,N)*r)%N; return F(m,u1+u2)
def failcrit(P):   # Chair's criterion for three +-1 points (positions in sixths)
    fl={floor(x)%6 for x in P}; return all(x!=floor(x) for x in P) and fl in ({0,2,4},{1,3,5})
def type1(V,log):
    Z=sorted(v//6 for v in V if v%6==0); A=sorted(v for v in V if v%6 in (1,5))
    assert len(Z)==2 and len(A)==3 and len(V)==5
    s=[sgn(a) for a in A]; e2,e3=(s[1]-s[0])//6,(s[2]-s[0])//6; E=max(abs(e2),abs(e3),abs(e3-e2))
    u,U=Z; Smax=A[-1]; log.update(rule='DZ type 1',u=(u,U),s=tuple(s),e=(e2,e3),E=E,S=Smax)
    if E<=U:
        h=gcd(gcd(u,abs(e2)),abs(e3))
        if (u//h)%2: th1=F(1,2*h); log['clause']='R, u/h odd'
        else:
            pl={}; th1=P3(u,e2,e3,pl,Cost()); log['clause']='R, u/h even (P3 %s)'%pl['case']
            assert pl['case']!='E' and dist(u*th1)==T3
        y=U*th1-round(U*th1)
        if abs(y)>=S6: dl=F(0); lift='none'
        elif y>=0: dl=(S6-y)/U; lift='up'
        else: dl=-(S6+y)/U; lift='down'
        th=th1+dl; log.update(h=h,theta1=th1,y=y,lift=lift,delta=dl,theta=th)
        assert abs(dl)<=F(1,6*U)
        pts=[F(0),e2*th,e3*th]
        if log['clause'].startswith('R, u/h odd'):
            f=[x for x in (e2,e3,e3-e2) if (x//h)%2==0][0] if any((x//h)%2==0 for x in (e2,e3,e3-e2)) else None
            assert f is not None and (f*th1).denominator==1 and dist(f*th)<=S6; log['N2_pair_diff']=f
        else:
            # arc of the three relative points after the lift <= 1/3 + E|delta| <= 1/2   (N3)
            arc=min(max(frac(p-b) for p in pts) for b in pts); log['arc']=arc
            assert arc<=T3+E*abs(dl) and arc<=F(1,2)
    else:
        assert Smax>3*U
        ts=tri(*Z); th=F(ceil(Smax*(ts-F(1,6*U))),Smax); log.update(clause='L (grid lock)',theta_star=ts,theta=th)
        assert ts-F(1,6*U)<=th<=ts+F(1,6*U) and (Smax*th).denominator==1
    assert dist(u*th)>=S6 and dist(U*th)>=S6
    P=[(si*th)%6 for si in s]; log['P']=tuple(P); assert not failcrit(P)
    return first_alpha(V,th,log)
