# Independent implementation of the Chair's message (2026-11-12 20:15): seven runners, two zero classes 7u <= 7U, four
# nonzero speeds all of the same class.  theta from I3 (x, 2x, 3x all safe); bases theta, 2theta, 3theta; 7 rotations each.
from fractions import Fraction as F
from math import floor
from t7 import S7, frac, dist, sgn
I3=[(F(1,7),F(2,7)),(F(8,21),F(3,7)),(F(4,7),F(13,21)),(F(5,7),F(6,7))]
def inI3(f): return any(a<=f<=b for a,b in I3)
def entry_I3(f):                                   # first point >= f (mod 1) of I3, returned as a real >= f
    if inI3(f): return f
    for a,b in I3:
        if f<a: return a
    return 1+I3[0][0]
def dz4(V,log=None):
    log={} if log is None else log
    Z=sorted(v//7 for v in V if v%7==0); W=[v for v in V if v%7]
    assert len(V)==6 and len(Z)==2 and len(W)==4
    s=[sgn(w) for w in W]; assert len({x%7 for x in s})==1, 'not four of one class'
    u,U=Z; th0=F(1,7*u)
    if U<=2*u: th=th0; log['rule']='U<=2u: theta=1/(7u)'
    else:
        f=frac(U*th0); b=entry_I3(f); assert 0<=b-f<F(2,7)
        th=th0+(b-f)/U; log['rule']='U>2u: push U*theta0 into I3 by %s'%(b-f)
        assert F(1,7)<=u*th<F(2,7)
    assert inI3(frac(u*th)) and inI3(frac(U*th)), 'I3 claim'
    for k in (1,2,3):
        assert dist(k*u*th)>=S7 and dist(k*U*th)>=S7
        for al in range(7):
            t=frac((k*th+al)/7)
            if all(dist(v*t)>=S7 for v in V):
                log.update(u=u,U=U,theta=th,round=k,alpha=al,t=t); return t
    raise AssertionError('three rounds all blocked: %s'%log)
