# Independent implementation of the Chair's message (2026-11-12 21:38): seven runners, ONE zero class 7u, four same-class
# nonzero speeds plus one of another class (type 4+1).  Long span D > 3u: theta = j/D, three bases theta, 2theta, 3theta.
# The short-span clause (D <= 3u, "the two adjacent rotation cells of the previous round") is not written in the message and is
# therefore NOT implemented: such inputs raise NotSpecified.  Exact Fractions, closed comparisons, no fallback.
from fractions import Fraction as F
from math import gcd, floor
from t7 import S7, frac, dist, sgn, inv
class NotSpecified(Exception): pass
def sz41(V,log=None):
    log={} if log is None else log
    Z=[v for v in V if v%7==0]; W=[v for v in V if v%7]
    assert len(V)==6 and len(Z)==1 and len(W)==5
    s=[sgn(w) for w in W]; cl=[x%7 for x in s]
    c0=[k for k in set(cl) if cl.count(k)==4]; assert len(c0)==1, 'not a 4+1 pattern'; c0=c0[0]
    four=sorted(x for x in s if x%7==c0); u=Z[0]//7; D=(four[-1]-four[0])//7
    c1=[x%7 for x in s if x%7!=c0][0]; c=(c1*inv(c0,7))%7
    log.update(u=u,four=tuple(four),D=D,c=c)
    if D<=3*u: return short_span(V,u,four,c0,log)
    g=gcd(D,u); N=D//g; assert N>=4
    j=(inv(u//g,N)*(-(-N//7)))%N; th=F(j,D)
    x=frac(u*th); assert F(1,7)<=x<=F(2,7), 'u*theta not in [1/7,2/7]'
    assert (D*th).denominator==1 and (four[-1]*th-four[0]*th)%7==0, 'end pair does not coincide'
    log.update(g=g,N=N,j=j,theta=th,u_phase=x)
    for k in (1,2,3):
        assert dist(k*u*th)>=S7
        for al in range(7):
            t=frac((k*th+al)/7)
            if all(dist(v*t)>=S7 for v in V): log.update(round=k,alpha=al,t=t); return t
    raise AssertionError('three rounds all blocked: %s'%log)

def short_span(V,u,pts,c0,log):
    """Chair 2026-11-12 21:45: theta = 1/(7u), L = floor(s_min*theta); candidates beta = 1-L, 2-L (mod 7); alpha = c0^-1 beta."""
    th=F(1,7*u); L=floor(pts[0]*th)
    span=pts[-1]*th-pts[0]*th; assert span<=3
    blocked=set()
    for x in pts:
        P=x*th
        for b in range(7):
            y=(P+b)%7
            if y<1 or y>6: blocked.add(b)
    assert blocked <= {(-L-i)%7 for i in range(5)}, 'same-class blocking outside the five cells'
    log.update(rule='short span (D<=3u)',theta=th,L=L,same_class_blocked=tuple(sorted(blocked)))
    for idx,beta in enumerate(((1-L)%7,(2-L)%7)):
        al=(inv(c0,7)*beta)%7; t=frac((th+al)/7)
        assert all(dist(x*t)>=S7 for x in pts) and dist(7*u*t)==S7
        if all(dist(v*t)>=S7 for v in V): log.update(candidate=idx+1,beta=beta,alpha=al,t=t); return t
    raise AssertionError('both adjacent candidates blocked: %s'%log)
def sz5(V,log=None):
    """five same-class speeds and one zero class: long span -> end pair coincides + three rounds; short span -> beta = 1-L."""
    log={} if log is None else log
    Z=[v for v in V if v%7==0]; W=[v for v in V if v%7]
    assert len(V)==6 and len(Z)==1 and len(W)==5
    s=sorted(sgn(w) for w in W); assert len({x%7 for x in s})==1, 'not five of one class'
    c0=s[0]%7; u=Z[0]//7; D=(s[-1]-s[0])//7; log.update(u=u,five=tuple(s),D=D)
    if D<=3*u:
        t=short_span(V,u,s,c0,log); assert log['candidate']==1, 'five same-class: first cell should already be safe'; return t
    g=gcd(D,u); N=D//g; assert N>=4
    j=(inv(u//g,N)*(-(-N//7)))%N; th=F(j,D); x=frac(u*th); assert F(1,7)<=x<=F(2,7)
    assert (s[-1]*th-s[0]*th)%7==0
    log.update(rule='long span',N=N,j=j,theta=th)
    for k in (1,2,3):
        for al in range(7):
            t=frac((k*th+al)/7)
            if all(dist(v*t)>=S7 for v in V): log.update(round=k,alpha=al,t=t); return t
    raise AssertionError('three rounds all blocked: %s'%log)
