# End-to-end run of the full 2+2+1 entry over every single-zero 2+2+1 input with distinct speeds <= B (any common factor).
# All internal assertions run on every call; OPEN = the known gaps.  Implementation exercise; coverage rests on the proofs and checks.
import sys
from itertools import combinations
from collections import Counter
from sz221_full import sz221_full, NotThisBranch, cls
from sz221 import Open
B=int(sys.argv[1]) if len(sys.argv)>1 else 30
cnt=Counter(); n=0; op=0
nums={k:[w for w in range(1,B+1) if w%7 and cls(w)==k] for k in (1,2,3)}
for z in range(7,B+1,7):
    for single in (1,2,3):
        p1,p2=[k for k in (1,2,3) if k!=single]
        for A in combinations(nums[p1],2):
            for Bp in combinations(nums[p2],2):
                for w in nums[single]:
                    V=(z,)+A+Bp+(w,); log={}
                    try: sz221_full(V,log); n+=1
                    except Open as e:
                        op+=1; cnt[('OPEN',str(e).split(', u=')[0].replace('group (2,1), gcd(u,Y)=1, ','')[:60],'-')]+=1; continue
                    except NotThisBranch: continue
                    lf=log['leaf']
                    if lf.startswith('3: six'): key='3: six groups -> sz221 / '+lf.split('sz221: ')[1].split(' (')[0].split(':')[0].split(', m=')[0]
                    elif lf.startswith('3:'): key='3: '+('rounding (q>=4)' if 'q=' in lf else 'Chair k table')
                    else: key=lf.split(',')[0]
                    cnt[('leaf',key,log.get('round','-'))]+=1
for k in sorted(cnt,key=str): print('%-4s %-75s round %s %8d'%(k[0],k[1],k[2],cnt[k]))
print('B=%d: %d inputs with a safe time, OPEN %d'%(B,n,op))
