# Independent implementation of Fable MIXED-R4 §2.2/§2.4: the six direct formulas for clause 5b and their selection order,
# plugged into the R3 dispatch (clauses 1-5a from mixed.py).  Exact Fractions; every ratio condition is an exact '<='.
from fractions import Fraction as F
from math import floor
import mixed as R3
from mixed import frac, dist, classify, safe_all
def le(x,y): return F(x)<=F(y)                    # closed comparison everywhere
def push_right(V,T):                               # Chair's rule: push T right to v1's first safe position
    v1=V[0]; phi=frac(v1*T)
    if F(1,6)<=phi<=F(5,6): return T,phi,F(0)
    d=(F(1,6)-phi)/v1 if phi<F(1,6) else (F(7,6)-phi)/v1
    return T+d,phi,d
def formulas(u,a,ap,B,C):
    v1=6*u; af,as_=max(a,ap),min(a,ap); c=C//3; d=(a+ap)//6
    return dict(v1=v1,af=af,as_=as_,c=c,d=d)
def cond(name,p,B,C):
    v1,af,as_=p['v1'],p['af'],p['as_']
    if name=='N-E':  return p['d']%2==0
    if name=='H-1/2':return le(max(af,C),F(2*B*v1,v1+B))
    if name=='N-T':  return le(af,F(3*C*v1,v1+2*C)) and le(max(as_,B),F(C*v1,v1+2*C))
    if name=='N-G':  return le(B,F(2*af*v1,v1+2*af)) and le(C,F(7*af*v1,v1+2*af))
    if name=='N-Q':  return le(max(af,C),F(7*B*v1,2*(v1+B)))
    if name=='N-S':  return le(C,F(2*af*v1,2*v1+af)) and le(B,F(af*v1,2*v1+af))
def build(name,V,p,a,B,C,log):
    v1,af=p['v1'],p['af']
    if name=='N-E':
        k=(5*a)%12; log['k']=k; return F(k,12)+F(1,6*v1)
    if name=='H-1/2': return F(1,2)+F(1,6*B)+F(1,6*v1)
    if name=='N-T':
        T0=F(1,3) if af%3==1 else F(2,3); T=T0+F(1,6*C); t,phi,dd=push_right(V,T)
        log.update(T0=T0,T=T,phi=phi,push=dd); return t
    if name=='N-G':
        k=af%12; log['k']=k; return F(k,12)+F(1,12*af)+F(1,6*v1)
    if name=='N-Q':
        T0=F(1,4) if a%4==1 else F(3,4); log['T0']=T0; return T0+F(1,6*B)+F(1,6*v1)
    if name=='N-S':
        T0=F(1,6) if af%6==5 else F(5,6); log['T0']=T0; return T0+F(1,3*af)+F(1,6*v1)
def clause5b(V,u,a,ap,B,C,log):
    p=formulas(u,a,ap,B,C); log.update(af=p['af'],as_=p['as_'],c=p['c'],d=p['d'])
    if p['d']%2==0: order=['N-E']; log['subcase']='d even'
    elif (p['c']-a)%4==0: order=['N-G','H-1/2','N-T']; log['subcase']='d odd, c=a mod 4'
    else: order=['N-Q','N-S','N-T']; log['subcase']='d odd, c=-a mod 4'
    applicable=[n for n in order if cond(n,p,B,C)]; log['applicable']=tuple(applicable)
    if not applicable: raise AssertionError('Theorem 5b coverage violated: %s'%log)
    name=applicable[0]; log['formula']=name
    return build(name,V,p,a,B,C,log)
def normalize(V):                                   # put the unique 0-mod-6 speed first; others keep input order
    z=[w for w in V if w%6==0]; assert len(z)==1
    return tuple(z)+tuple(w for w in V if w%6)
def mixed_full(V):
    V=normalize(V); log={}; u,pm1,wB,wC=classify(V); log.update(u=u,pm1=tuple(pm1),wB=wB,wC=wC)
    if u%wB or any(u%x for x in pm1) or (pm1[0]%6)==(pm1[1]%6) or 5*wC>=6*u or wB%4:
        t,l2=R3.mixed(V,use_chair5b=False); l2.update(log); log=l2          # clauses 1-5a (R3)
    else:
        a,ap=(pm1[0],pm1[1]) if pm1[0]%6==1 else (pm1[1],pm1[0])
        log['clause']='5b'; t=clause5b(V,u,a,ap,wB,wC,log)               # clause 5b (R4)
    t=frac(t)                                    # v1.1: single common return point, every branch returns t in [0,1)
    d=[dist(v*t) for v in V]; log.update(t=t,dists=tuple(d),SAFE=all(x>=F(1,6) for x in d))
    assert log['SAFE'] and 0<=t<1, 'final check failed: %s'%log
    return t,log
