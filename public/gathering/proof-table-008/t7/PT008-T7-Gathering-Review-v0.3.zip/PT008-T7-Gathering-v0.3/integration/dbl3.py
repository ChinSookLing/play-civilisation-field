# Independent implementation of the Chair's double-3-class construction (2026-11-11 18:54), written only from the Chair's text.
#   V = (6u, 3c1, 3c2, w1, w2) in any order; c1,c2 odd; 3 does not divide w1*w2.
#   theta = P3(2u; c1, c2)  (reviewed P3 implementation, unchanged);  t_j = 1/2 + (theta+j)/3 mod 1, j = 0,1,2 in order;
#   output the first t_j at which w1 and w2 are both safe.  Exact Fractions, closed comparisons, no fallback.
from fractions import Fraction as F
from p3 import P3, Cost, frac, dist
S=F(1,6)
def split(V):
    z=[w for w in V if w%6==0]; th=[w for w in V if w%6==3]; r=[w for w in V if w%3]
    assert len(V)==5 and len(z)==1 and len(th)==2 and len(r)==2, 'not the double-3 branch: %s'%(V,)
    return z[0]//6, th[0]//3, th[1]//3, r
def dbl3(V):
    u,c1,c2,W=split(V); log=dict(u=u,c=(c1,c2),w=tuple(W),wclass=tuple(sorted(('+-1' if w%6 in (1,5) else '+-2') for w in W)))
    cost=Cost(); plog={}
    theta=P3(2*u,c1,c2,plog,cost)
    log.update(P3case=plog.get('case'),theta=theta)
    # the three guarantees the Chair uses (checked, not assumed)
    g1=dist(2*u*theta); g2=(dist(c1*theta),dist(c2*theta))
    log.update(d2utheta=g1,dc_theta=g2)
    assert g1>=S and max(g2)<=F(1,3), 'P3 interface violated'
    tried=[]
    for j in range(3):
        t=frac(F(1,2)+(theta+j)/3)
        okW=[dist(w*t)>=S for w in W]; tried.append((j,tuple(okW)))
        if all(okW): break
    else:
        raise AssertionError('no j works -- coverage claim violated: %s'%log)
    # per-speed phase identities the proof uses
    assert frac(6*u*t)==frac(2*u*theta)
    assert all(frac(3*c*t)==frac(F(1,2)+c*theta) for c in (c1,c2))
    d=[dist(v*t) for v in V]
    log.update(tried=tuple(tried),j=j,t=t,dists=tuple(d),SAFE=all(x>=S for x in d))
    assert log['SAFE'], 'final check failed %s'%log
    return t,log
