# Independent implementation of Fable SZ311 R1 (claude/PT008-T7-SZ311-R1-FABLE.md) plus the Chair's supplement (2026-11-12 22:38):
# seven runners, ONE zero class 7u, three same-class speeds in ratio type (1/2,1) or (1,2) (standard form S2=S1+7D, S3=S1+21D),
# two singles of the two other classes.  Rules A1, A2 (ratio (1/2,1)); first step + T1, T2 (ratio (1,2)) with the Chair's f* fix;
# Chair's second base phase (2+3n)/(3u) for u=4 and for u=2, S1 = 0,1 (mod 3).  R2: block 3, Props 4, 5.  R3: Lemma B, Props 6-8 (G1, G2).
# Exact Fractions, closed comparisons, fixed candidate lists, no fallback.
from fractions import Fraction as F
from math import gcd, floor, ceil
from functools import reduce
from t7 import S7, frac, dist, sgn, inv
class Open(Exception): pass
class NotThisBranch(Exception): pass
def lt(x): x%=7; return x if x<=3 else x-7          # least absolute residue mod 7
def tri_block(Ps):
    B=set()
    for P in Ps:
        for b in range(7):
            y=(P+b)%7
            if y<1 or y>6: B.add(b)
    return B
def in_Istar(Z,la):
    z=Z%7
    return (0<z<1) if la==3 else (6<z<7)
def setup(V):
    Z=[v for v in V if v%7==0]; W=[v for v in V if v%7]
    if not (len(V)==6 and len(Z)==1 and len(W)==5): raise NotThisBranch('shape')
    u=Z[0]//7; s=[sgn(w) for w in W]; cl=[x%7 for x in s]
    c=[k for k in set(cl) if cl.count(k)==3]
    if len(c)!=1 or len(set(cl))!=3: raise NotThisBranch('not 3+1+1')
    c=c[0]; S=sorted(x for x in s if x%7==c); sing=[x for x in s if x%7!=c]
    d1,d2=(S[1]-S[0])//7,(S[2]-S[1])//7; flip=False
    if 2*d1==d2: pass
    elif d1==2*d2: S=sorted(-x for x in S); sing=[-x for x in sing]; flip=True; d1,d2=d2,d1
    else: raise NotThisBranch('triple not in ratio (D,2D)')
    D=d1
    if D==u: kind='(1,2)'
    elif 2*D==u: kind='(1/2,1)'
    else: raise NotThisBranch('D not in {u, u/2}')
    c=S[0]%7; ci=inv(c,7)
    las=[lt(x%7*ci) for x in sing]; assert sorted(abs(l) for l in las)==[2,3], 'single steps not {2,3}'
    ia=[i for i in range(2) if abs(las[i])==3][0]; a=sing[ia]; la=las[ia]; b=sing[1-ia]; lb=las[1-ia]
    assert (a-la*S[0])%7==0; ea=(a-la*S[0])//7
    if reduce(gcd,[u]+[abs(x) for x in S]+[abs(a)])!=1: raise NotThisBranch('premise gcd(u,S,a)=1 violated (Chair reduction)')
    return dict(u=u,S=S,a=a,la=la,b=b,lb=lb,ea=ea,D=D,kind=kind,flip=flip,c=c)
def finish(V,th,info,log,need):
    S=info['S']; Ps=[x*th for x in S]; B=tri_block(Ps)
    if need[0]=='F(i)':
        assert any(B<={(r+i)%7 for i in range(3)} for r in range(7)), 'triple not inside 3 consecutive'
    else:
        r=need[1]
        assert {(r+i)%7 for i in range(3)}.isdisjoint(B) and any(B<={(q+i)%7 for i in range(4)} for q in range(7)), 'F(ii) premise'
        Zv=info['a']*th+info['la']*r; assert not in_Istar(Zv,info['la']), 'Z in I*'
    assert dist(info['u']*th)>=S7
    for al in range(7):
        t=frac((th+al)/7)
        if all(dist(v*t)>=S7 for v in V): log.update(theta=th,alpha=al,t=t); return t
    raise AssertionError('no rotation: %s'%log)
def sz311(V,log=None):
    log={} if log is None else log
    I=setup(V); u,S,D,a,la,ea=I['u'],I['S'],I['D'],I['a'],I['la'],I['ea']; S1=S[0]
    log.update(u=u,kind=I['kind'],D=D,S=tuple(S),flip=I['flip'],a=a,la=la,b=I['b'],lb=I['lb'],ea=ea)
    if I['kind']=='(1/2,1)':
        th=lambda n: F(1,14*D)+F(n,D)
        g=gcd(D,abs(S1)); q=D//g; b0=frac(F(S1,14*D))
        if q>=2:
            j=ceil((1-b0)*q)%q; n=(j*inv(S1//g,q))%q; log['rule']='A1 (q=%d)'%q
            assert frac(S1*th(n))<F(1,q); return finish(V,th(n),I,log,('F(i)',))
        if b0<=F(1,2): log['rule']='A2 (beta0<=1/2)'; return finish(V,th(0),I,log,('F(i)',))
        if D<2: return small_blocks(V,I,log,'block 1 (ratio (1/2,1), u=2, D=1)')
        l=floor(S1*th(0)); r=(1-l)%7; Z0=a*th(0)+la*r
        if not in_Istar(Z0,la): log['rule']='A2 (Z0 not in I*)'; return finish(V,th(0),I,log,('F(ii)',r))
        n=(inv(ea,D)*(D//2))%D; l=floor(S1*th(n)); r=(1-l)%7; log['rule']='A2 (shift n=%d)'%n
        return finish(V,th(n),I,log,('F(ii)',r))
    # ratio (1,2): D = u
    th1=lambda n: F(1+3*n,3*D); th2=lambda n: F(2+3*n,3*D)
    def cand(base,n):
        t=th1(n) if base==1 else th2(n); P1=S1*t; f=frac(P1); l=floor(P1)
        ok=(f<F(2,3)) if base==1 else (f>=F(1,3)); r=((1 if base==1 else 3)-l)%7
        return t,f,ok,r,a*t+la*r
    g=gcd(D,abs(S1)); q=D//g; b0=frac(F(S1,3*D))
    if q>=2: j0=ceil((1-b0)*q)%q; n1=(j0*inv(S1//g,q))%q; base=1
    else:
        if b0<F(2,3): n1=0; base=1
        else: n1=0; base=2
    if g>=2:                                                     # rule T1
        t,f,ok,r,Z=cand(base,n1); assert ok
        if not in_Istar(Z,la): log['rule']='T1 (n=n1, base %d)'%base; return finish(V,t,I,log,('F(ii)',r))
        k=(inv(ea,g)*(g//2))%g; n=n1+q*k; t,f,ok,r,Z=cand(base,n); assert ok
        log['rule']='T1 (n=n1+q*k*, k*=%d, base %d)'%(k,base); return finish(V,t,I,log,('F(ii)',r))
    # g = 1, q = D
    if D==3 or D>=5:                                             # rule T2 with the Chair's f* fix
        Si=inv(S1,D); fs=frac(b0+F(j0,D)); assert fs<F(1,D)
        rho=(ea*Si)%D; Nn=(7*rho+la)%(7*D)
        if Nn>7*D//2: Nn-=7*D
        Dl=F(Nn,D); assert abs(Nn)>=3
        t,f,ok,r,Z=cand(1,(j0*Si)%D)
        if not in_Istar(Z,la): i=0
        elif abs(Nn)>=D: i=1
        else:
            z=Z%7; z=z-7 if z>3 else z                           # representative inside I*
            lo,hi=(F(0),F(1)) if la==3 else (F(-1),F(0))
            delta=(hi-z) if Dl>0 else (z-lo); i=ceil(delta/abs(Dl))
        Imax=ceil((F(2,3)-fs)*D)-1; assert i<=Imax, 'T2: i beyond the usable range'
        t,f,ok,r,Z=cand(1,((j0+i)*Si)%D); assert ok and abs(f-(fs+F(i,D)))==0
        log['rule']='T2 (N=%d, i=%d, Imax=%d)'%(Nn,i,Imax); return finish(V,t,I,log,('F(ii)',r))
    # Chair's supplement: second base phase
    if D==4 or (D==2 and S1%3 in (0,1)):
        Si=inv(S1,D)
        if D==4: base=1 if S1%3 in (0,1) else 2
        else: base=1 if S1%3==0 else 2
        cs=[]
        for j in range(D):
            t,f,ok,r,Z=cand(base,(j*Si)%D)
            if ok: cs.append((f,t,r,Z))
        cs.sort(key=lambda x:x[0]); need=3 if D==4 else 2
        assert len(cs)>=need, 'second-base: fewer usable positions than claimed'
        fs=[x[0] for x in cs]
        for f,t,r,Z in cs[:need]:
            if not in_Istar(Z,la):
                log['rule']='Chair second base phase: u=%d, base %d, positions f=%s, chosen f=%s'%(D,base,[str(x) for x in fs[:need]],f)
                return finish(V,t,I,log,('F(ii)',r))
        raise AssertionError('all claimed positions have Z in I*')
    if D==2 and S1%3==2:                                         # Fable R2, block 3: theta = 2/3
        th=F(2,3); log['rule']='R2 block 3: theta=2/3 (R0=4)'
        P1=S1*th; l=floor(P1); r=(1-l)%7
        assert frac(P1)==F(1,3) and in_Istar(a*th+la*r,la)==False
        return finish(V,th,I,log,('F(ii)',r))
    if D==1: return small_blocks(V,I,log,'block 2 (ratio (1,2), u=1, D=1)')
    raise Open('unexpected remaining case u=%d S1 mod 3=%d'%(D,S1%3))

# ---- Fable R3 (G1, G2 closure): Lemma B at theta = 1/q with the table gamma, alpha = c^-1 (gamma - l) mod 7 ----
G6={0:{None:2},2:{None:2},3:{(5,1):4,(5,4):2,(2,1):1},5:{(1,5):1,(1,2):1,(4,5):4}}          # theta = 1/6, keys (a' mod 6, b' mod 6)
G4={1:{(0,0):3,(2,0):3,(0,2):4},3:{(0,0):2,(0,2):2,(2,0):3}}                                 # theta = 1/4
G12={3:1,9:1,5:1,11:2}                                                                      # theta = 1/12 (sigma only)
def lemmaB(V,I,q,log,rule):
    S1=I['S'][0]; an=I['a'] if I['la']==3 else -I['a']; bn=I['b'] if I['lb']==2 else -I['b']
    assert (an-3*S1)%7==0 and (bn-2*S1)%7==0, 'sign normalisation'
    l,sg=divmod(S1,q); c=S1%7
    if q==6: tab=G6[sg]; gam=tab[None] if None in tab else tab[(an%6,bn%6)]
    elif q==4: gam=G4[sg][(an%4,bn%4)]
    else: gam=G12[sg]
    al=(inv(c,7)*(gam-l))%7; th=F(1,q); t=frac((th+al)/7)
    for v in V: assert dist(v*t)>=S7, 'Lemma B table gamma not safe at %s'%v
    log.update(rule=rule,theta=th,sigma=sg,l=l,gamma=gam,alpha=al,t=t,an=an,bn=bn); return t
def small_blocks(V,I,log,name):
    """Blocks 1, 2 (D = 1): theta = 2/3 unless K0 or K2 (R2, Prop. 4); u = 1: theta = 1/2 if a or b even (R2, Prop. 5), else 1/6 (R3 Prop. 6);
    u = 2: theta = 1/6 unless (S1 odd, a, b even) (Prop. 6); then 1/4 unless a = b = 2 mod 4 (Prop. 7); else 1/12 (Prop. 8)."""
    S1,a,b,la,lb,u=I['S'][0],I['a'],I['b'],I['la'],I['lb'],I['u']
    ea,eb=la//3,lb//2
    K0= S1%3==0 and a%3==(-ea)%3 and b%3==eb%3
    K2= S1%3==2 and a%3==ea%3 and b%3==(-eb)%3
    def rot(th):
        for al in range(7):
            t=frac((th+al)/7)
            if all(dist(v*t)>=S7 for v in V): return al,t
        return None
    log.update(block=name,K0=K0,K2=K2)
    r=rot(F(2,3))
    if not (K0 or K2):
        assert r is not None, 'Proposition 4 (only-if) violated'
        log.update(rule='R2: theta=2/3 (not K0/K2)',theta=F(2,3),alpha=r[0],t=r[1]); return r[1]
    assert r is None, 'Proposition 4 (if) violated: theta=2/3 not all blocked under K'
    if u==1:
        if a%2==0 or b%2==0:
            r=rot(F(1,2)); assert r is not None, 'Proposition 5 violated'
            log.update(rule='R2: theta=1/2 (u=1, a or b even)',theta=F(1,2),alpha=r[0],t=r[1]); return r[1]
        return lemmaB(V,I,6,log,'R3 G2: theta=1/6 (u=1, K, a and b odd)')
    six_blocked = S1%2==1 and a%2==0 and b%2==0
    assert (rot(F(1,6)) is None)==six_blocked, 'Proposition 6 iff violated'
    if not six_blocked: return lemmaB(V,I,6,log,'R3 G1: theta=1/6 (u=2, K, not [S1 odd, a, b even])')
    four_blocked = a%4==2 and b%4==2
    assert (rot(F(1,4)) is None)==four_blocked, 'Proposition 7 iff violated'
    if not four_blocked: return lemmaB(V,I,4,log,'R3 G1: theta=1/4 (u=2, K, S1 odd, a, b even, not both 2 mod 4)')
    return lemmaB(V,I,12,log,'R3 G1: theta=1/12 (u=2, K, S1 odd, a = b = 2 mod 4)')
