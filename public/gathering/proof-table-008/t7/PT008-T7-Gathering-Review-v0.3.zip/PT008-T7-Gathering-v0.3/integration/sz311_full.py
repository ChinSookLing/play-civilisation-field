# Full single-zero 3+1+1 entry: the Chair's front dispatch (2026-11-13 14:42) wired to the reviewed ratio-type program sz311.py.
#   gcd reduction -> section 1 (repeated same-class speed, or a positive difference D in {x,y,z} with N = D/gcd(D,u) >= 4: four-point
#   three-round criterion) -> section 2 (z <= u: theta = 1/(7u); four ratio pairs: theta = h/(7u), consecutive-three, three rounds)
#   -> section 3 (ratio (1/2,1), (1,2): d = gcd(u,S1,S2,S3,a) = 1 -> sz311 (R1-R3); d > 1 -> theta = 1/(7D) then the j/d lift).
# Exact Fractions, closed comparisons, fixed candidate lists (first safe candidate in the stated order), no fallback.
from fractions import Fraction as F
from math import gcd, ceil
from functools import reduce
from t7 import S7, frac, dist, inv
from sz311 import sz311
class NotThisBranch(Exception): pass
def cls(w): r=w%7; return min(r,7-r)
def safe(V,t): return all(dist(v*t)>=S7 for v in V)
def rounds(W,th,K,log):
    for k in range(1,K+1):
        for al in range(7):
            t=frac((k*th+al)/7)
            if safe(W,t): log.update(round=k,alpha=al); return t
    raise AssertionError('no safe candidate in %d round(s) at theta=%s'%(K,th))
def h_cases():
    return {(F(3,4),F(3,4)):8,(F(1),F(1)):1,(F(1,2),F(3,2)):10,(F(3,2),F(3,2)):4}
def sz311_full(V,log=None):
    log={} if log is None else log
    g=reduce(gcd,V); W=[v//g for v in V]
    Z=[w for w in W if w%7==0]; R=[w for w in W if w%7]
    if len(W)!=6 or len(Z)!=1: raise NotThisBranch('not single-zero')
    cl=[cls(w) for w in R]; trip=[k for k in (1,2,3) if cl.count(k)==3]
    if len(trip)!=1 or sorted(cl.count(k) for k in (1,2,3))!=[1,1,3]: raise NotThisBranch('not 3+1+1')
    u=Z[0]//7; T=[w for w in R if cls(w)==trip[0]]; c=T[0]%7
    S=sorted(w if w%7==c else -w for w in T)
    P=[w if w%7==(2*c)%7 else -w for w in R if cls(w)!=trip[0] and (w%7 in ((2*c)%7,(-2*c)%7))][0]
    Q=[w if w%7==(3*c)%7 else -w for w in R if cls(w)!=trip[0] and (w%7 in ((3*c)%7,(-3*c)%7))][0]
    assert all((s-c)%7==0 for s in S) and (P-2*c)%7==0 and (Q-3*c)%7==0
    x,y=(S[1]-S[0])//7,(S[2]-S[1])//7; z=x+y
    log.update(g=g,u=u,S=tuple(S),P=P,Q=Q,x=x,y=y,z=z)
    def out(t): assert safe(W,t); T=t/g; assert safe(V,T); log['t']=T; return T
    # ---- section 1 ----
    if x==0 or y==0:
        th=F(1,7*u); log.update(leaf='1: repeated same-class speed, theta=1/(7u)',theta=th); return out(rounds(W,th,3,log))
    for name,D in (('x',x),('y',y),('z',z)):
        gD=gcd(D,u); N=D//gD
        if N>=4:
            j=(inv(u//gD,N)*ceil(F(N,7)))%N; th=F(j,D)
            assert S7<=frac(u*th)<=F(2,7), 'u theta not in [1/7,2/7]'
            assert (7*D*th).denominator==1                     # the pair at difference 7D coincides mod 7 in every round
            log.update(leaf='1: four-point three-round, D=%s=%d, N=%d, j=%d'%(name,D,N,j),theta=th); return out(rounds(W,th,3,log))
    # ---- section 2: every positive difference has N <= 3, i.e. divides 2u or 3u ----
    for D in (x,y,z): assert (2*u)%D==0 or (3*u)%D==0
    if z<=u:
        th=F(1,7*u); log.update(leaf='2: z<=u, theta=1/(7u), one round',theta=th); return out(rounds(W,th,1,log))
    pr=tuple(sorted((F(x,u),F(y,u))))
    assert pr in h_cases() or pr in ((F(1,2),F(1)),(F(1),F(2))), 'difference ratio pair outside the six: %s'%(pr,)
    if pr in h_cases():
        h=h_cases()[pr]; th=F(h,7*u)
        off=sorted({(s*th-S[0]*th)%7 for s in S}); assert any(sorted({k%7,(k+1)%7,(k+2)%7})==off for k in range(7)), 'not consecutive'
        assert all((k*u*th)%1!=0 and (7*k*u*th).denominator==1 for k in (1,2,3))
        log.update(leaf='2: ratio pair (%s,%s), h=%d, consecutive three'%(pr[0],pr[1],h),theta=th); return out(rounds(W,th,3,log))
    # ---- section 3: ratio (1/2,1) or (1,2); standard form S1, S1+7D, S1+21D ----
    if x>y: S=sorted(-s for s in S); P,Q=-P,-Q; x,y=y,x
    D=x; assert y==2*D and D in (u,F(u,2)) and S[1]==S[0]+7*D and S[2]==S[0]+21*D
    a,b=Q,P; assert (a-3*S[0])%7==0 and (b-2*S[0])%7==0
    d=reduce(gcd,[u]+[abs(s) for s in S]+[abs(a)])
    log.update(D=D,d=d)
    if d==1:
        sub={}; t=sz311(tuple(W),sub); log.update(leaf='3: d=1 -> sz311 (R1-R3): %s'%sub.get('rule'),theta=sub.get('theta'),alpha=sub.get('alpha'))
        return out(t)
    th=F(1,7*D); five=[7*u]+S+[a]
    for al in range(7):
        t0=frac((th+al)/7)
        if safe(five,t0): break
    else: raise AssertionError('d>1: no rotation keeps the first five speeds')
    gb=gcd(d,abs(b)); q=d//gb; assert q>=2
    r=ceil(q*(S7-frac(b*t0))); j=(r*inv(b//gb,q))%q; t=frac(t0+F(j,d))
    assert S7<=frac(b*t)<S7+F(1,q), 'lift: b phase not in [1/7, 1/7+1/q)'
    for v in five: assert frac(v*t)==frac(v*t0)
    log.update(leaf='3: d>1 lift (theta=1/(7D), alpha=%d, q=%d, r=%d, j=%d)'%(al,q,r,j),theta=th,alpha=al); return out(t)
