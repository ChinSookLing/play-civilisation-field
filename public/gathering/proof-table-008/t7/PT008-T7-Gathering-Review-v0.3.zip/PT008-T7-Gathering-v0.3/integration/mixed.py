# Independent implementation of the mixed ±2/3 branch dispatch (Fable MIXED-R3 §2.4) with the constructions it calls:
# M-B (R1), M-D strengthened (Chair, reviewed in R3 part 1), M-S(S1)+Lemma M1 (R2/R1), M-O + Lemma M-E (R3/R2), M-L (R3),
# and the Chair's new direct formula for part of 5b.  Exact Fractions.  No search beyond the fixed alpha lists; no F5.
# Branch: v1=6u; two speeds = +-1 (mod 6); one speed w_B = +-2 (mod 6); one speed w_C = 3 (mod 6).
from fractions import Fraction as F
from math import gcd, floor, ceil
def frac(x): return x-floor(x)
def dist(x): x=frac(x); return min(x,1-x)
def safe_all(V,t): return all(dist(v*t)>=F(1,6) for v in V)
def first_alpha(V,tau,alphas):
    for al in alphas:
        t=tau+F(al,6)
        if safe_all(V,t): return al,t
    return None,None
def classify(V):
    v1=V[0]; rest=list(V[1:])
    assert v1%6==0
    pm1=[w for w in rest if w%6 in (1,5)]; two=[w for w in rest if w%6 in (2,4)]; three=[w for w in rest if w%6==3]
    assert len(pm1)==2 and len(two)==1 and len(three)==1, 'not the mixed +-2/3 branch'
    return v1//6,pm1,two[0],three[0]
def M_B(V,u,wB,log):
    g=gcd(u,wB); p=u//g; q=wB//g; b=wB if wB%6==2 else -wB
    pinv=pow(p%q,-1,q) if q>1 else 0
    if q%2:
        r=(q-1)//2; m0=(r*pinv)%q; m=m0 if m0%2 else m0+q
    else:
        r=q//2 if (q//2)%2 else q//2-1; m=(r*pinv)%q
    assert m%2==1
    theta=F(m,b); log.update(g=g,p=p,q=q,r=r,m=m,b=b,theta=theta,u_theta_dist=dist(u*theta))
    assert dist(u*theta)>=F(1,4)
    return first_alpha(V,theta/6,range(6))
def M_D(V,u,a,wC,log):
    g=gcd(u,a); q=a//g; r=q//3; c=wC//3
    j=(pow((2*u//g)%q,-1,q)*r)%q
    J=j if dist(F(c*j,a))<=F(1,3) else 2*j
    t0=F(a+2*J,6*a); log.update(a=a,g=g,q=q,r=r,j=j,J=J,c=c,t0=t0)
    return first_alpha(V,t0,(0,2,4))
def M_S1(V,u,log):
    theta=F(1,6*u); log.update(theta=theta); return first_alpha(V,theta/6,range(6))
def M_O(V,u,wC,log):
    rho=F(wC,6*u)
    if rho<1: X=1/(6*rho); sub='rho<1'
    elif rho<=5: X=F(1,6); sub='1<=rho<=5'
    else: k=ceil(rho/6-F(1,6)); X=(k+F(1,6))/rho; sub='rho>5 (k=%d)'%k
    assert F(1,6)<=X<=F(5,6)
    theta=X/u; log.update(rho=rho,sub=sub,X=X,theta=theta)
    return first_alpha(V,theta/6,range(6))
def M_L(V,T,log):
    v1=V[0]; phi=frac(v1*T)
    if F(1,6)<=phi<=F(5,6): t=T
    elif phi<F(1,6): t=T+(F(1,6)-phi)/v1
    else: t=T-(phi-F(5,6))/v1
    log.update(T=T,phi=phi); return 'n/a',t
def chair5b(V,u,B,M,log):
    v1=6*u; bound=F(2*B*v1,v1+B); log.update(B=B,M=M,bound=bound)
    if u%B==0 and M<=bound: return 'n/a',F(1,2)+F(1,6*B)+F(1,6*v1)
    return None,None
def mixed(V,use_chair5b=True):
    log={}; u,pm1,wB,wC=classify(V); log.update(u=u,pm1=tuple(pm1),wB=wB,wC=wC)
    if u%wB: log['clause']='1 M-B'; al,t=M_B(V,u,wB,log)
    else:
        bad=[a for a in pm1 if u%a]
        if bad: log['clause']='2 M-D'; al,t=M_D(V,u,bad[0],wC,log)
        elif (pm1[0]%6)==(pm1[1]%6): log['clause']='3 M-S(S1)'; al,t=M_S1(V,u,log)
        else:
            a,ap=(pm1[0],pm1[1]) if pm1[0]%6==1 else (pm1[1],pm1[0])
            assert 5*(a+ap)<=6*u, '(F2) violated'
            if 5*wC>=6*u: log['clause']='4 M-O'; al,t=M_O(V,u,wC,log)
            elif wB%4: log['clause']='5a M-L, T=1/4'; al,t=M_L(V,F(1,4),log)
            else:
                M=max(a,ap,wC); al,t=(None,None)
                if use_chair5b: al,t=chair5b(V,u,wB,M,log)
                if t is not None: log['clause']='5b Chair direct formula'
                else:
                    log['clause']='5b residual: needs F5 (not implemented, by design)'; log.update(M=M)
                    return None,log
    log['alpha']=al
    if t is None: raise AssertionError('clause guarantee violated: %s'%log)
    d=[dist(v*t) for v in V]; log.update(t=t,dists=tuple(d),SAFE=all(x>=F(1,6) for x in d))
    assert log['SAFE'], 'final check failed'
    return t,log
