"""Fable's two-round construction for two zero classes and two pairs."""
from fractions import Fraction

from t7 import S7, dist, frac

DOUBLE_SAFE = ((S7, 3 * S7), (4 * S7, 6 * S7))


def dz22(speeds, log=None):
    u, U = sorted(v // 7 for v in speeds if v % 7 == 0)
    theta = Fraction(1, 7 * u)
    phase = frac(U * theta)
    entry = next(
        (max(phase, start) for start, end in DOUBLE_SAFE if phase <= end),
        1 + S7,
    )
    delta = (entry - phase) / U
    theta += delta
    for round_index in (1, 2):
        for alpha in range(7):
            t = frac((round_index * theta + alpha) / 7)
            if all(dist(v * t) >= S7 for v in speeds):
                if log is not None:
                    log.update(u=u, U=U, theta=theta, delta=delta,
                               round=round_index, alpha=alpha)
                return t
    raise AssertionError("DZ22: the two-round criterion was violated")
