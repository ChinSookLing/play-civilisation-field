# The integrated four-candidate index rule (arithmetic split) equals the reviewed enumeration rule, for every u <= 2000 not = 2 mod 4 and
# both parities r = Y mod 2 (r = 0 only for odd u): same side, same four lattice indices j (or both none).
from fractions import Fraction as F
from math import floor
def old(u,r):
    for lo,mid,hi in ((F(0),F(1,4),F(1,2)),(F(1,2),F(3,4),F(1))):
        js=[j for j in range(u) if lo<F(r+2*j,2*u)<hi]
        left=[j for j in js if F(r+2*j,2*u)<mid][-3:]; right=[j for j in js if F(r+2*j,2*u)>mid][:1]
        if len(left)==3 and len(right)==1 and all(F(r+2*j,2*u)!=mid for j in js): return mid,left+right
    return None
def new(u,r):
    for lo,mid,hi in ((F(0),F(1,4),F(1,2)),(F(1,2),F(3,4),F(1))):
        split=u*mid-F(r,2)
        if split.denominator==1: continue
        ll=floor(split); fr=ll+1
        if lo<F(r+2*(ll-2),2*u) and F(r+2*fr,2*u)<hi: return mid,list(range(ll-2,fr+1))
    return None
bad=n=0
for u in range(1,2001):
    if u%4==2: continue
    for r in ((0,1) if u%2 else (1,)):
        n+=1; bad+= old(u,r)!=new(u,r)
print('four-candidate index: %d (u, r) pairs, u <= 2000, u != 2 mod 4: mismatches %d (must be 0)'%(n,bad))
print('    note: when f = 1/4 is a lattice point (u = 2 mod 4) the f = 1/4 exit runs first in both versions')
