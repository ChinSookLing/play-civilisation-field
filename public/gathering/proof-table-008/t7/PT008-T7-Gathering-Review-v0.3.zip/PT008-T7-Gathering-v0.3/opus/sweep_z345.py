# Unified entry, three to five zero classes: zero quotients any multiset from 1..ZQ, the remaining 6-k speeds any multiset of non-multiples
# of 7 from 1..M.  Usage: python3 sweep_z345.py <pkg> ZQ M.  Independent distance check; tally of branches (repeats go to T6 by design).
import sys; sys.path.insert(0,sys.argv[1])
from itertools import combinations_with_replacement as cwr
from collections import Counter
from time_forge7 import time_forge7
ZQ,M=int(sys.argv[2]),int(sys.argv[3]); c=Counter(); n=0
nz=[w for w in range(1,M+1) if w%7]
for k in (3,4,5):
    for Z in cwr(range(1,ZQ+1),k):
        for W in cwr(nz,6-k):
            V=tuple(7*z for z in Z)+W; log={}; t=time_forge7(V,log); n+=1
            p,q=t.numerator,t.denominator
            assert 0<t<1 and all(7*min((v*p)%q,q-(v*p)%q)>=q for v in V), V
            c[log['branch']]+=1
print('zero quotients <= %d, other speeds <= %d: %d inputs, all safe; %s'%(ZQ,M,n,dict(sorted(c.items()))))
