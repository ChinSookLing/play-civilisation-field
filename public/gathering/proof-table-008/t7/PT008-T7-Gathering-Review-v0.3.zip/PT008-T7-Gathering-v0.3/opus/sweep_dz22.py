# Double-zero 2+2 through time_forge7: zero quotients u <= U <= UMAX (u = U allowed), two classes c1 != c2 (up to sign), each pair two speeds
# (repetition allowed) of its class from 1..M; every input, both orders of the zero classes.  Usage: python3 sweep_dz22.py <pkg> UMAX M
import sys; sys.path.insert(0,sys.argv[1])
from itertools import combinations_with_replacement
from collections import Counter
from fractions import Fraction as F
from time_forge7 import time_forge7
from t7 import dist, S7
UMAX,M=int(sys.argv[2]),int(sys.argv[3])
def cl(w): r=w%7; return min(r,7-r)
c=Counter(); n=0; maxk=0
for U in range(1,UMAX+1):
    for u in range(1,U+1):
        for c1,c2 in ((1,2),(1,3),(2,3)):
            P1=[w for w in range(1,M+1) if w%7 and cl(w)==c1]; P2=[w for w in range(1,M+1) if w%7 and cl(w)==c2]
            for A in combinations_with_replacement(P1,2):
                for B in combinations_with_replacement(P2,2):
                    for V in ((7*U,7*u)+A+B,(7*u,7*U)+B+A):
                        log={}; t=time_forge7(V,log); n+=1
                        if log['branch']!='Z2:2+2': c['other branch '+log['branch']]+=1; continue
                        d=log['detail']; k=7*(d['round']-1)+d['alpha']+1; maxk=max(maxk,k)
                        assert d['u']<=d['U'] and 0<=d['delta']<F(2,7*d['U'])
                        assert all(dist(z*kk*d['theta'])>=S7 for z in (d['u'],d['U']) for kk in (1,2))
                        c['round %d'%d['round']]+=1; c['delta>0' if d['delta'] else 'delta=0']+=1
print('U <= %d, pair speeds <= %d: %d inputs; %s; largest candidate index %d (bound 14)'%(UMAX,M,n,dict(sorted(c.items())),maxk))
