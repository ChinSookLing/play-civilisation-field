# EXACT checks for the double-zero 2+2 construction (Fable) as integrated (dz22.py).  Usage: python3 crit_dz22.py <package dir>
import sys; sys.path.insert(0,sys.argv[1])
from fractions import Fraction as F
from itertools import product
from t7 import S7, frac, dist
I=((S7,3*S7),(4*S7,6*S7))
def inI(x): return any(a<=x<=b for a,b in I)
# (1) I is exactly {phi : phi and 2 phi in [1/7, 6/7] mod 1}: checked on the complete grid of multiples of 1/84 (all breakpoints are in (1/14)Z)
bad=sum(inI(F(k,84))!=((S7<=F(k,84)<=6*S7) and (S7<=frac(2*F(k,84))<=6*S7)) for k in range(84))
print('(1) I = {phi, 2phi in [1/7,6/7]}: grid 1/84 (breakpoints in (1/14)Z), mismatches %d (must be 0)'%bad)
# (2) push: replicate the program's rule and check, for all 1 <= u <= U <= 400: entry as described (1/7, 4/7, 8/7 or stay), 0 <= delta < 2/(7U),
#     u theta in [1/7, 3/7), {U theta} in I, and both zero classes safe for k = 1, 2 (alpha does not matter); u = U gives delta = 0.
def push(u,U):
    th=F(1,7*u); x=frac(U*th)
    if x<S7: y=S7
    elif x<=3*S7: y=x
    elif x<4*S7: y=4*S7
    elif x<=6*S7: y=x
    else: y=1+S7
    return th+(y-x)/U,(y-x)/U,x
import dz22 as D
src=open(sys.argv[1]+'/dz22.py').read()
cnt={'stay':0,'gap1':0,'gap2':0,'gap3':0}; bad=0
for U in range(1,401):
    for u in range(1,U+1):
        th,dl,x=push(u,U)
        cnt['stay' if inI(x) else 'gap1' if x<S7 else 'gap2' if x<4*S7 else 'gap3']+=1
        bad+= not (0<=dl<F(2,7*U) and S7<=frac(u*th)<3*S7 and inI(frac(U*th)) and all(dist(k*z*th)>=S7 for k in (1,2) for z in (u,U)))
        if u==U: bad+= dl!=0
print('(2) push rule, 1 <= u <= U <= 400 (%d pairs, %s): failures %d (must be 0)'%(sum(cnt.values()),cnt,bad))
# (2b) the program's entry computation equals the description, same range
from fractions import Fraction
DS=D.DOUBLE_SAFE; bad=0
for U in range(1,201):
    for u in range(1,U+1):
        th=Fraction(1,7*u); ph=frac(U*th)
        entry=next((max(ph,s) for s,e in DS if ph<=e),1+S7)
        bad+= th+(entry-ph)/U!=push(u,U)[0]
print('(2b) program entry rule = described rule, 1 <= u <= U <= 200: mismatches %d (must be 0)'%bad)
# (3) two-round criterion, complete representatives: for k = 1, 2 a blocked set changes only where kX is an integer, i.e. X in (1/2)Z,
#     so multiples of 1/4 are complete.  First class: P blocks m iff ||kP - m||_7 < 1; second: ||kQ - c m||_7 < 1, c in {2,3,4,5}.
#     First point translated into [0,1) (translation by n moves the second class by c n in every round).  Coincident points included.
import numpy as np
R=28
def mask(coef):
    M=np.zeros(R,dtype=np.int64)
    for r in range(R):
        b=0
        for i,k in enumerate((1,2)):
            for m in range(7):
                d=(k*r-4*coef*m)%28
                if min(d,28-d)<4: b|=1<<(7*i+m)
        M[r]=b
    return M
X=mask(1); tot=0; r1=0; r12=0
for c in (2,3,4,5):
    Qm=mask(c)
    A=(X[:4,None]|X[None,:]).reshape(-1); T=(A[:,None]|Qm[None,:]).reshape(-1); S=(T[:,None]|Qm[None,:])
    tot+=S.size; r1+=int(((S&127)==127).sum()); r12+=int((((S&127)==127)&(((S>>7)&127)==127)).sum())
print('(3) two-round criterion: %d configurations, round 1 all-blocked %d, BOTH rounds all-blocked %d (must be 0)'%(tot,r1,r12))
