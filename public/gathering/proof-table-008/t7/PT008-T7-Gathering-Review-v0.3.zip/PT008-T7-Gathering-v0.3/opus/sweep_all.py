# End-to-end run of the unified entry time_forge7 over EVERY multiset of six speeds from 1..N (repetitions allowed).
# Usage: python3 sweep_all.py <package dir> N.  Each call asserts its own result; this script re-checks every distance independently,
# tallies the branch, and records the candidate count of the double-zero 2+2 branch (round, alpha).  Implementation exercise only.
import sys; sys.path.insert(0,sys.argv[1])
from itertools import combinations_with_replacement
from collections import Counter
from time_forge7 import time_forge7
N=int(sys.argv[2]); c=Counter(); n=0; dzc=Counter(); maxcand=0
for V in combinations_with_replacement(range(1,N+1),6):
    log={}; t=time_forge7(V,log); n+=1
    p,q=t.numerator,t.denominator
    assert 0<t<1 and all(7*min((v*p)%q,q-(v*p)%q)>=q for v in V), V
    c[log['branch']]+=1
    if log['branch']=='Z2:2+2':
        d=log['detail']; k=7*(d['round']-1)+d['alpha']+1; maxcand=max(maxcand,k); dzc['round %d'%d['round']]+=1
        assert d['u']<=d['U']
for k in sorted(c): print('%-32s %8d'%(k,c[k]))
print('N=%d: %d multisets, all safe (independent distance check); double-zero 2+2: %s, largest candidate index %d (bound 14)'%(N,n,dict(dzc),maxcand))
