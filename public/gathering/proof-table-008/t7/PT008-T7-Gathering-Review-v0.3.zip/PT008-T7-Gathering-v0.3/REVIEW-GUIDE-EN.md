# Seven Runners | Reviewer Guide

**PT-008 · Time Forge · Gathering v0.3 · 13 November 2026**

**Theorem.** Let six nonzero integers $v_1,\dots,v_6$ be the speeds relative to a designated runner. All seven runners start together on a circle of circumference one. The construction returns an exact rational $0<t<1$ such that $\min_i\|v_i t\|\ge 1/7$, where $\|x\|$ is the distance to the nearest integer. Signed inputs and repeated absolute speeds are allowed. A zero relative speed makes the requested separation impossible. For exact rational inputs, use a common denominator $D$ to obtain integer speeds, then multiply the output time by $D$.

The manuscript documents an explicit selection algorithm with bounded candidate checks and arithmetic that is polynomial in input bit length. The manuscript makes a constructive claim. Priority and novelty are pending a literature review. PT-008 completed its internal review of the integrated construction on 13 November 2026. External peer review is pending. The original proof files listed in proofs/README.md are still being assembled.

## Dispatch order

First replace each speed by its absolute value and divide by the common gcd. Divide the final time by that gcd. A **zero residue** is a normalized speed divisible by 7. Other speeds are grouped by residue up to sign, and the **pattern** records their class sizes.

| Priority | Condition | Route |
|---|---|---|
| 1 | No zero residues | $t=1/7$ in normalized units |
| 2 | Two zero residues and pattern $2+2$ | Fable's phase adjustment combined with the Chair's two-round criterion, manuscript §3 |
| 3 | Repeated absolute speeds | Deduplicate and use the bundled T6 construction |
| 4 | One zero residue | Patterns $5,4+1,3+2,3+1+1,2+2+1$ |
| 5 | Two zero residues, other patterns | Patterns $4,3+1,2+1+1$ |
| 6 | Three to five zero residues | Apply T6 to the zero-residue quotients and check seven rotations |

Section 6 of the main manuscript maps each branch to its proof and historical review in Chinese. The executable reference is in `integration/`. The bundled T6 proof and replay are required for priorities 3 and 6. Section 4 identifies two useful checks in the $2+2+1$ proof: the changed base phase for $u=4$ and the signed pair representative convention for $u=1$.

## Offline reproduction

From the extracted package root, use Bash and Python 3.10 or later. The last command also requires NumPy.

```bash
set -euo pipefail
sha256sum -c SHA256SUMS
(cd integration && sha256sum -c SHA256SUMS)
(cd opus && sha256sum -c SHA256SUMS)
awk '{print $1 "  integration/SHA256SUMS"}' opus/package_SHA256SUMS.sha256 | sha256sum -c -
(cd integration && python3 review_cases.py | diff -u review_cases.out -)
(cd integration && python3 sweep_full221.py 30 | diff -u sweep_full221.out -)
(cd opus && python3 crit_dz22.py ../integration | diff -u crit_dz22.out -)
```

In `integration/`, `time_forge7((2, 7, 13, 14, 15, 16))` returns `44/49`, the fourteenth candidate of the two-round branch. See manuscript §5 for an exact distance check and longer test runs. A review report can identify the branch, the first unsupported inference or counterexample, and the file hash needed to reproduce it.
