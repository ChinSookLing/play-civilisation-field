"""Exact witness checks for the integrated C45 reader."""

import ast
from collections import Counter
from fractions import Fraction
from pathlib import Path
from random import Random
import re
import sys

here = Path(__file__).resolve().parent
sys.path.insert(0, str(here.parent / "reader"))
from t7 import EQUAL_SPACING, grid_time, read


def check(v, route=None):
    result = read(v)
    if route is not None:
        assert result.route == route, (v, result)
    phases = [(x * result.time) % 1 for x in v]
    observed = min(min(y, 1-y) for y in phases)
    assert observed == result.minimum
    if result.route == "equal-spacing":
        assert observed == Fraction(1, 7)
    else:
        assert observed > Fraction(1, 7)
    return result


examples = [
    ((1, 2, 3, 4, 5, 6), "equal-spacing"),
    ((30, 5, 15, 10, 25, 20), "equal-spacing"),
    ((1, 2, 3, 4, 6, 7), "rank-3"),
    ((4, 5, 6, 1001, 1352, 14008), "grid-1183"),
    ((4, 5, 6, 1001, 1183, 2003), "grid-4459"),
    ((10, 11, 12, 2002, 8281, 9001), "grid-2197"),
    ((2, 3, 5, 20, 7007, 15379), "grid-343"),
    ((1802, 3446, 6376, 12370, 13013, 13632), "grid-1274"),
    ((1165, 5606, 11484, 12358, 13013, 13286), "grid-4459"),
    ((4, 5, 6, 637, 13013, 14008), "grid-2197"),
    ((4, 5, 6, 8281, 13013, 14008), "grid-343"),
    ((4, 5, 6, 13013, 14008, 15009), "grid-1274"),
]
for v, route in examples:
    out = check(v, route)
    print(v, out.time, out.minimum, out.route)
for v, _ in examples[7:9]:
    assert grid_time(v, 637) is None
assert read(examples[1][0]).time == Fraction(1, 35)
assert tuple(x // 13 for x in (14001, 15002)) == (1077, 1154)
assert all(x % 13 == 0 for x in (14001, 15002))
old = (4, 5, 6, 13013, 14001, 15002)
assert all(Fraction(1, 7) < (x*(Fraction(2, 7)+Fraction(234689, 9565830274))) % 1
           < Fraction(6, 7) for x in old)

named = 0
for line in (here / "hesper_named_misses.txt").read_text().splitlines():
    match = re.search(r"(\([0-9, ]+\)) strict ([0-9]+/[0-9]+)", line)
    if match is None:
        continue
    v = ast.literal_eval(match[1])
    before = Fraction(match[2])
    assert all(Fraction(1, 7) < (x*before) % 1 < Fraction(6, 7) for x in v)
    assert check(v).route.startswith("grid-")
    named += 1
assert named == 16
print("Hesper named misses, original and new times:", named)

rng = Random(45045)
routes = Counter()
for bound in (30, 500, 26065, 10**9):
    for _ in range(150):
        v = rng.sample(range(1, bound+1), 6)
        out = check(v)
        routes[out.route] += 1
print("random reads:", sum(routes.values()), sorted(routes.items()))
