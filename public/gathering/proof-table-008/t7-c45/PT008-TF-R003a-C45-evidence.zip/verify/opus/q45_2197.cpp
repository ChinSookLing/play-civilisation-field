// Opus Q45: q = 2197 = 13^3 for the split branch with 13-valuation of P exactly 1 and of Q exactly 2 (13 does not divide b, c).
// P = 13 r (r = 77 b mod 169, a unit mod 169) -> 13 by u = r^{-1} mod 169; Q = 169 s (s = c mod 13) is unchanged by the
// remaining units 1 + 169 h, folded to s = 1..6; these units move a chosen further speed c1 through its 13 lifts mod 169,
// so c1 is normalised to 1..84 (prime to 13) after folding.  Other three speeds: units mod 2197 folded to 1..1098, multiset.
#include <bitset>
#include <cstdint>
#include <iostream>
#include <vector>
#include <cassert>
const int Q = 2197, H = Q / 2;
bool strict(int k, int r) { int z = 7 * ((k * r) % Q); return Q < z && z < 6 * Q; }
int main() {
    std::vector<int> pool, firsts;
    for (int x = 1; x <= H; ++x) if (x % 13) pool.push_back(x);
    for (int x = 1; x <= 84; ++x) if (x % 13) firsts.push_back(x);
    std::uint64_t checked = 0, missing = 0;
    for (int s = 1; s <= 6; ++s) {
        std::vector<int> pos;
        for (int k = 1; k <= H; ++k) if (strict(k, 13) && strict(k, 169 * s)) pos.push_back(k);
        const int W = 704; assert((int)pos.size() <= W);
        std::vector<std::bitset<W>> mask(H + 1);
        for (int x = 1; x <= H; ++x) for (size_t i = 0; i < pos.size(); ++i) if (strict(pos[i], x)) mask[x].set(i);
        std::uint64_t ms = 0;
        for (int c1 : firsts)
            for (size_t i = 0; i < pool.size(); ++i) {
                auto a = mask[c1] & mask[pool[i]];
                for (size_t j = i; j < pool.size(); ++j) {
                    auto b = a & mask[pool[j]];
                    if (b.none()) { size_t n = pool.size() - j; checked += n; ms += n;
                        if (missing + ms <= 20 + n) std::cout << "pair-empty: 13 " << 169 * s << " " << c1 << " " << pool[i] << " " << pool[j] << "\n";
                        continue; }
                    for (size_t l = j; l < pool.size(); ++l) {
                        ++checked;
                        if ((b & mask[pool[l]]).none()) { ++ms;
                            if (missing + ms <= 20) std::cout << "miss: 13 " << 169 * s << " " << c1 << " " << pool[i] << " " << pool[j] << " " << pool[l] << "\n"; }
                    }
                }
            }
        missing += ms;
        std::cout << "s = " << s << ": anchor numerators " << pos.size() << ", misses " << ms << "\n" << std::flush;
    }
    std::cout << "q = 2197: pool " << pool.size() << "; normalised words " << checked << "; misses " << missing << "\n";
}
