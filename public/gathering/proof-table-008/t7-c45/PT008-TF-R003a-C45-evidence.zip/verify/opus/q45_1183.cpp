// Opus Q45: fixed-denominator certificate q = 1183 = 7 * 13^2 for the split branch
//   P = 1001 b (13 does not divide b), Q = 169 c with 7 not dividing c, four further speeds prime to 13.
// Normalisation (strict grid test: invariant under permutation, per-coordinate sign flips, common unit factor mod q):
//   P = 91 r (r = 11 b mod 13 nonzero) -> 91 and Q = 169 s (s = c mod 7 nonzero) -> 169 by a unit u with
//   u = r^{-1} mod 13, u = s^{-1} mod 7; the remaining units are 1 + 91 h (h mod 13); they move a chosen speed c1 that is
//   prime to 7 and 13 through all 13 lifts of c1 mod 91, so c1 is normalised to 1..45 (prime to 7, 13) after its sign flip.
//   The other three speeds are arbitrary residues prime to 13, folded to 1..591, chosen as a multiset.
// Grid: numerator k (1 <= k <= 591) is strict for residue r iff q < 7 (k r mod q) < 6 q.
#include <bitset>
#include <cstdint>
#include <iostream>
#include <vector>
#include <cassert>
const int Q = 1183, H = Q / 2;
bool strict(int k, int r) { int z = 7 * ((k * r) % Q); return Q < z && z < 6 * Q; }
int main() {
    std::vector<int> pos;
    for (int k = 1; k <= H; ++k) if (strict(k, 91) && strict(k, 169)) pos.push_back(k);
    const int W = 320; assert((int)pos.size() <= W);
    std::vector<std::bitset<W>> mask(H + 1);
    for (int x = 1; x <= H; ++x) for (size_t i = 0; i < pos.size(); ++i) if (strict(pos[i], x)) mask[x].set(i);
    std::vector<int> pool, firsts;
    for (int x = 1; x <= H; ++x) if (x % 13) pool.push_back(x);
    for (int x = 1; x <= 45; ++x) if (x % 13 && x % 7) firsts.push_back(x);
    std::uint64_t checked = 0, missing = 0;
    std::vector<std::vector<int>> misses;
    for (int c1 : firsts) {
        for (size_t i = 0; i < pool.size(); ++i) {
            auto a = mask[c1] & mask[pool[i]];
            for (size_t j = i; j < pool.size(); ++j) {
                auto b = a & mask[pool[j]];
                for (size_t l = j; l < pool.size(); ++l) {
                    ++checked;
                    if ((b & mask[pool[l]]).none()) {
                        ++missing;
                        if (misses.size() < 20) misses.push_back({91, 169, c1, pool[i], pool[j], pool[l]});
                    }
                }
            }
        }
    }
    std::cout << "q = 1183: anchor numerators (P = 91, Q = 169 strict) " << pos.size() << "; first-speed representatives "
              << firsts.size() << "; pool " << pool.size() << "; normalised words " << checked << "; misses " << missing << "\n";
    for (auto& m : misses) { for (int x : m) std::cout << x << " "; std::cout << "\n"; }
}
