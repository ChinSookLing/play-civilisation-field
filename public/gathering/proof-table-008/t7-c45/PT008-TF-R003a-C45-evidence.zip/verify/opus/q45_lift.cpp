// Opus Q45: lift words mod m to mod q*m (all w_i + m e_i), drop words whose coordinates all share a prime of q*m,
// optional constraint "coordinate 0 divisible by d0" (the 1001-multiple P is divisible by 11), test the strict grid
// k/(q m), 1 <= k <= q m / 2.  Reads "m" then words (6 ints per line) on stdin; writes surviving words.
#include <cstdio>
#include <cstdint>
#include <vector>
#include <array>
#include <cstdlib>
using W = std::array<long long, 6>;
static bool strict_any(const W& w, long long M) {
    for (long long k = 1; k <= M / 2; ++k) {
        bool ok = true;
        for (int i = 0; i < 6 && ok; ++i) { long long z = 7 * ((k * w[i]) % M); ok = (M < z && z < 6 * M); }
        if (ok) return true;
    }
    return false;
}
int main(int argc, char** argv) {
    long long q = atoll(argv[1]); long long d0 = argc > 2 ? atoll(argv[2]) : 1;
    long long m; if (scanf("%lld", &m) != 1) return 1;
    std::vector<W> in; W w;
    while (scanf("%lld %lld %lld %lld %lld %lld", &w[0], &w[1], &w[2], &w[3], &w[4], &w[5]) == 6) in.push_back(w);
    long long M = q * m; std::vector<long long> primes;
    for (long long p : {2, 3, 5, 7, 11, 13, 17, 19}) if (M % p == 0) primes.push_back(p);
    std::uint64_t tested = 0, miss = 0; std::vector<W> out;
    for (auto& w0 : in) {
        long long total = 1; for (int i = 0; i < 6; ++i) total *= q;
        for (long long code = 0; code < total; ++code) {
            W u; long long c = code;
            for (int i = 0; i < 6; ++i) { u[i] = w0[i] + m * (c % q); c /= q; }
            if (u[0] % d0) continue;
            bool shared = false;
            for (long long p : primes) { bool all = true; for (int i = 0; i < 6; ++i) if (u[i] % p) { all = false; break; } if (all) { shared = true; break; } }
            if (shared) continue;
            ++tested;
            if (!strict_any(u, M)) { ++miss; out.push_back(u); }
        }
    }
    fprintf(stderr, "lift %lld -> %lld (coordinate 0 divisible by %lld): tested %llu, misses %llu\n", m, M, d0,
            (unsigned long long)tested, (unsigned long long)miss);
    printf("%lld\n", M);
    for (auto& u : out) printf("%lld %lld %lld %lld %lld %lld\n", u[0], u[1], u[2], u[3], u[4], u[5]);
}
