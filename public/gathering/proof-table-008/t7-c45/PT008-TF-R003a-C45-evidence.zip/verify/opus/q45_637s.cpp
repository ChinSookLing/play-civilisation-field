// Opus Q45: q = 637 = 7^2 * 13 for the split branch with Q also a multiple of 7 (Q = 1183 c'), restricted to
//   7 not dividing b and 7 not dividing c'  (so P = 1001 b and Q = 1183 c' are 91 times units mod 7).
// Residues mod 637: P = 91 r, Q = 91 s (r, s nonzero mod 7).  A unit u = r^{-1} mod 7 sends P to 91; folding signs,
// Q becomes 91 s' with s' in {1, 2, 3}.  Units u = 1 mod 7 (84 of them) move a chosen further speed c1 (a unit mod 637:
// the four further speeds are prime to 7 and 13 here) through all residues = c1 mod 7, so c1 -> 1, 2, 3 after folding.
// The other three speeds: units mod 637 folded to 1..318, multiset.
#include <bitset>
#include <cstdint>
#include <iostream>
#include <vector>
#include <cassert>
const int Q = 637, H = Q / 2;
bool strict(int k, int r) { int z = 7 * ((k * r) % Q); return Q < z && z < 6 * Q; }
int main() {
    std::vector<int> pool;
    for (int x = 1; x <= H; ++x) if (x % 7 && x % 13) pool.push_back(x);
    std::uint64_t checked = 0, missing = 0;
    for (int s = 1; s <= 3; ++s) {
        std::vector<int> pos;
        for (int k = 1; k <= H; ++k) if (strict(k, 91) && strict(k, 91 * s)) pos.push_back(k);
        const int W = 320; assert((int)pos.size() <= W);
        std::vector<std::bitset<W>> mask(H + 1);
        for (int x = 1; x <= H; ++x) for (size_t i = 0; i < pos.size(); ++i) if (strict(pos[i], x)) mask[x].set(i);
        for (int c1 = 1; c1 <= 3; ++c1)
            for (size_t i = 0; i < pool.size(); ++i) {
                auto a = mask[c1] & mask[pool[i]];
                for (size_t j = i; j < pool.size(); ++j) {
                    auto b = a & mask[pool[j]];
                    for (size_t l = j; l < pool.size(); ++l) {
                        ++checked;
                        if ((b & mask[pool[l]]).none()) {
                            ++missing;
                            std::cout << "miss: 91 " << 91 * s << " " << c1 << " " << pool[i] << " " << pool[j] << " " << pool[l] << "\n";
                        }
                    }
                }
            }
        std::cout << "s' = " << s << ": anchor numerators " << pos.size() << "\n";
    }
    std::cout << "q = 637 (P, Q both 91 x unit): pool " << pool.size() << "; normalised words " << checked << "; misses " << missing << "\n";
}
