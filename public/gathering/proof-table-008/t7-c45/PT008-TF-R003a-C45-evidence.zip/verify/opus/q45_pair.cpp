// Opus Q45: fixed-pair certificate.  For fixed residues P, Q mod q (q given), every choice of four further speeds that are
// units mod q (folded to 1..q/2, multiset) is tested on the strict grid k/q.  No normalisation beyond folding and order.
#include <bitset>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <vector>
#include <numeric>
#include <cassert>
int Q;
bool strict(long long k, long long r) { long long z = 7 * ((k * r) % Q); return Q < z && z < 6 * Q; }
int main(int argc, char** argv) {
    Q = atoi(argv[1]); long long P = atoll(argv[2]) % Q, R = atoll(argv[3]) % Q; int H = Q / 2;
    std::vector<int> pos;
    for (int k = 1; k <= H; ++k) if (strict(k, P) && strict(k, R)) pos.push_back(k);
    const int W = 256; assert((int)pos.size() <= W);
    std::vector<std::bitset<W>> mask(H + 1);
    std::vector<int> pool;
    for (int x = 1; x <= H; ++x) if (std::gcd(x, Q) == 1) { pool.push_back(x); for (size_t i = 0; i < pos.size(); ++i) if (strict(pos[i], x)) mask[x].set(i); }
    std::uint64_t checked = 0, missing = 0;
    for (size_t a = 0; a < pool.size(); ++a) for (size_t b = a; b < pool.size(); ++b) {
        auto m2 = mask[pool[a]] & mask[pool[b]];
        for (size_t c = b; c < pool.size(); ++c) { auto m3 = m2 & mask[pool[c]];
            for (size_t d = c; d < pool.size(); ++d) { ++checked; if ((m3 & mask[pool[d]]).none()) ++missing; } } }
    std::cout << "q = " << Q << ", P = " << argv[2] << ", Q = " << argv[3] << ": anchor numerators " << pos.size()
              << "; words " << checked << "; misses " << missing << "\n";
}
