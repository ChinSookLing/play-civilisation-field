# Opus Q45: explicit reader for the split branch P = 1001 b (13 does not divide b), Q = 169 c, exactly two multiples of 13,
# at most two multiples of 7 (C43), speeds <= 26,065 (C41).  Denominator by case (certificates q45_1183 / 637+lift / 2197 / 343):
#   7 does not divide c                                   -> q = 1183
#   7 | c, 7 does not divide b, 49 does not divide c      -> q = 4459
#   7 | c, (7 | b or 49 | c), 13 does not divide c        -> q = 2197
#   7 | c, 7 | b, 13 | c  (Q = 15379, P in 7007*{1,2,3})  -> q = 343
# The time is k/q for the least k <= q/2 at which all six phases are strictly inside (1/7, 6/7).
from fractions import Fraction as F
from math import gcd
import random
def denominator(v):
    m13 = [x for x in v if x % 13 == 0]; assert len(m13) == 2
    P = [x for x in m13 if x % 1001 == 0]; Qs = [x for x in m13 if x % 169 == 0 and x % 1001]
    assert len(P) == 1 and len(Qs) == 1
    b, c = P[0] // 1001, Qs[0] // 169; assert b % 13
    if c % 7: return 1183
    if b % 7 and (c // 7) % 7: return 4459
    if c % 13: return 2197
    return 343
def read(v):
    q = denominator(v)
    for k in range(1, q // 2 + 1):
        if all(q < 7 * ((k * x) % q) < 6 * q for x in v): return q, F(k, q)
    return q, None
if __name__ == "__main__":
    rng = random.Random(4501); from collections import Counter
    cnt = Counter(); fail = []
    cases = [lambda: (1001 * rng.choice([b for b in range(1, 27) if b % 13]), 169 * rng.choice([c for c in range(1, 155) if c % 7])),
             lambda: (1001 * rng.choice([b for b in range(1, 27) if b % 13 and b % 7]), 169 * 7 * rng.choice([c for c in range(1, 23) if c % 7])),
             lambda: (1001 * rng.choice([7, 14, 21]), 169 * 7 * rng.choice([c for c in range(1, 23) if c % 13])),
             lambda: (1001 * rng.choice([b for b in range(1, 27) if b % 13]), 169 * 49 * rng.choice([1, 2, 3])),
             lambda: (1001 * rng.choice([7, 14, 21]), 15379)]
    for _ in range(20000):
        P, Q = rng.choice(cases)()
        if P == Q or Q % 1001 == 0: continue        # Q = 13013 k belongs to the same-speed branch (Neon)
        others = set()
        while len(others) < 4:
            x = rng.randint(1, int(10 ** rng.uniform(1, 4.416)))
            if x % 13 == 0 or x in (P, Q) or x < 1: continue
            n7 = sum(1 for y in (P, Q) if y % 7 == 0) + sum(1 for y in others if y % 7 == 0)
            if x % 7 == 0 and n7 >= 2: continue
            others.add(x)
        v = tuple(sorted([P, Q] + list(others)))
        if gcd(*v) != 1: continue
        q, t = read(v); cnt[q] += 1
        if t is None or not all(F(1, 7) < (t * x) % 1 < F(6, 7) for x in v): fail.append(v)
    print("20000 random split-branch inputs by denominator:", dict(sorted(cnt.items())), "; failures:", fail[:5], len(fail))
    for v in ((4, 5, 6, 1001, 1183, 2003), (10, 11, 12, 2002, 8281, 9001), (2, 3, 5, 7007, 15379, 20), (1, 2, 3, 1001, 2366, 4)):
        try:
            print("  example", v, "->", read(tuple(sorted(v))))
        except AssertionError:
            print("  example", v, "not in the split branch")
