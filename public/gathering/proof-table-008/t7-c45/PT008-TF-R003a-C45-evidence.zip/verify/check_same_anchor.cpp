#include <algorithm>
#include <array>
#include <bitset>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <vector>

using Word = std::array<int, 6>;

bool strict(int q, int k, int x) {
    const int z = 7 * ((k * x) % q);
    return q < z && z < 6 * q;
}

template <int Q>
class Grid {
    using Mask = std::bitset<Q / 2>;
    std::vector<Mask> masks;

public:
    Grid() : masks(Q) {
        for (int x = 1; x < Q; ++x) {
            for (int k = 1; k <= Q / 2; ++k) {
                if (strict(Q, k, x)) masks[x].set(k - 1);
            }
        }
    }

    std::uint64_t check_lifts(const std::vector<Word>& words, int factor,
                              bool odd_anchor) const {
        assert(Q == 637 * factor);
        int lift_count = 1;
        for (int i = 0; i < 6; ++i) lift_count *= factor;
        std::uint64_t total = 0;
        for (const auto& word : words) {
            for (int n = 0; n < lift_count; ++n) {
                Word lifted{};
                int digits = n;
                for (int i = 0; i < 6; ++i) {
                    lifted[i] = word[i] + 637 * (digits % factor);
                    digits /= factor;
                }
                if (odd_anchor && lifted[0] % 2 == 0) continue;
                ++total;
                bool hit = false;
                for (int k = 1; k <= Q / 2; ++k) {
                    if (std::all_of(lifted.begin(), lifted.end(),
                                    [&](int r) { return masks[r][k - 1]; })) {
                        hit = true;
                        break;
                    }
                }
                assert(hit);
            }
        }
        return total;
    }
};

void check_mixed_343() {
    constexpr int q = 343;
    for (int other : {49, 98, 147}) {
        std::vector<int> numerators;
        for (int k = 1; k <= q / 2; ++k) {
            if (strict(q, k, 7) && strict(q, k, other)) numerators.push_back(k);
        }
        std::vector<std::bitset<128>> pool;
        for (int x = 1; x <= q / 2; ++x) {
            if (x % 7 == 0) continue;
            std::bitset<128> mask;
            for (std::size_t i = 0; i < numerators.size(); ++i) {
                if (strict(q, numerators[i], x)) mask.set(i);
            }
            pool.push_back(mask);
        }
        std::uint64_t tested = 0;
        for (std::size_t i = 0; i < pool.size(); ++i) {
            for (std::size_t j = i; j < pool.size(); ++j) {
                const auto first = pool[i] & pool[j];
                for (std::size_t k = j; k < pool.size(); ++k) {
                    const auto prefix = first & pool[k];
                    for (std::size_t l = k; l < pool.size(); ++l) {
                        ++tested;
                        assert((prefix & pool[l]).any());
                    }
                }
            }
        }
        assert(tested == 20260275 && numerators.size() == 70);
        std::cout << "q=343 anchors 7," << other << ": " << tested
                  << " normalized words, 0 misses\n";
    }
}

int main() {
    constexpr int q = 637;
    std::vector<int> numerators;
    for (int k = 1; k <= q / 2; ++k) {
        if (strict(q, k, 91)) numerators.push_back(k);
    }
    assert(numerators.size() == 182);
    std::array<std::vector<int>, 4> pools;
    std::array<std::bitset<192>, q / 2 + 1> masks;
    for (int x = 1; x <= q / 2; ++x) {
        // 0: unit, 1: 7 only, 2: 13 only, 3: both.
        const int kind = (x % 7 == 0) + 2 * (x % 13 == 0);
        pools[kind].push_back(x);
        for (std::size_t i = 0; i < numerators.size(); ++i) {
            if (strict(q, numerators[i], x)) masks[x].set(i);
        }
    }
    const std::array<std::array<int, 4>, 5> shapes{{
        {0,0,0,0}, {1,0,0,0}, {2,0,0,0}, {3,0,0,0}, {1,2,0,0}
    }};
    const std::array<std::uint64_t, 5> expected_words{
        516184515, 340074504, 170037252, 24291036, 84349188
    };
    const std::array<std::size_t, 5> expected_misses{45, 0, 0, 72, 0};
    std::array<std::vector<Word>, 5> misses;
    for (std::size_t s = 0; s < shapes.size(); ++s) {
        const auto& kind = shapes[s];
        const auto& a = pools[kind[0]];
        const auto& b = pools[kind[1]];
        const auto& c = pools[kind[2]];
        const auto& d = pools[kind[3]];
        std::uint64_t tested = 0;
        for (int first = 1; first <= 3; ++first) {
            for (std::size_t i = 0; i < a.size(); ++i) {
                const auto pair = masks[first] & masks[a[i]];
                for (std::size_t j = kind[0] == kind[1] ? i : 0; j < b.size(); ++j) {
                    const auto triple = pair & masks[b[j]];
                    for (std::size_t k = kind[1] == kind[2] ? j : 0; k < c.size(); ++k) {
                        const auto four = triple & masks[c[k]];
                        for (std::size_t l = kind[2] == kind[3] ? k : 0; l < d.size(); ++l) {
                            ++tested;
                            if ((four & masks[d[l]]).none()) {
                                misses[s].push_back({91, first, a[i], b[j], c[k], d[l]});
                            }
                        }
                    }
                }
            }
        }
        assert(tested == expected_words[s] && misses[s].size() == expected_misses[s]);
        std::cout << "q=637 shape " << s << ": " << tested << " words, "
                  << misses[s].size() << " misses\n";
    }
    const auto odd_lifts = Grid<1274>().check_lifts(misses[0], 2, true);
    const auto seven_lifts = Grid<4459>().check_lifts(misses[3], 7, false);
    assert(odd_lifts == 1440 && seven_lifts == 8470728);
    std::cout << "q=1274: " << odd_lifts << " odd-anchor lifts, 0 misses\n";
    std::cout << "q=4459: " << seven_lifts << " lifts, 0 misses\n";
    check_mixed_343();
}
