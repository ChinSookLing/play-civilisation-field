#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT

g++ -O3 -std=c++17 check_same_anchor.cpp -o "$tmp/same"
"$tmp/same" >"$tmp/same.out"
diff -u same_anchor.out "$tmp/same.out"

for src in q45_1183 q45_637s q45_pair q45_lift q45_2197; do
    g++ -O3 -std=c++17 "opus/$src.cpp" -o "$tmp/$src"
done
for cert in q45_1183 q45_637s q45_2197; do
    "$tmp/$cert" >"$tmp/$cert.out"
    diff -u "opus/$cert.out" "$tmp/$cert.out"
done
(printf '637\n'; sed -n 's/^miss: //p' "$tmp/q45_637s.out") |
    "$tmp/q45_lift" 7 >"$tmp/lift.out" 2>"$tmp/lift.log"
diff -u opus/q45_lift_7.out "$tmp/lift.out"
diff -u opus/q45_lift_7.log "$tmp/lift.log"
for p in 7007 14014 21021; do
    "$tmp/q45_pair" 343 "$p" 15379
done >"$tmp/pair.out"
diff -u opus/q45_pair343.out "$tmp/pair.out"
python3 opus/q45_read.py >"$tmp/opus_reader.out"
diff -u opus/q45_read.out "$tmp/opus_reader.out"
python3 check_reader.py >"$tmp/reader.out"
diff -u reader.out "$tmp/reader.out"
printf '%s\n' 'C45: exact certificates and reader replay matched.'
