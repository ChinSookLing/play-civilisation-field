"""Exact six-runner selector from the constructive C36 descent."""
from dataclasses import dataclass
from fractions import Fraction as F
from itertools import product
from math import ceil, floor, gcd
from pathlib import Path

import q4
import rank3
import sub

dot = q4.dot
COVER = {4: F(53, 36), 3: F(11, 12), 2: F(1, 2), 1: F(1, 4)}
LOWER = F(1, 6)
UPPER = F(5, 6)
LIMIT = 51_046
DIM = 5


@dataclass(frozen=True)
class Selection:
    time: F
    route: str
    relations: tuple[tuple[int, ...], ...] = ()


def combination(coefficients, basis):
    return [sum(c * u[i] for c, u in zip(coefficients, basis)) for i in range(len(basis[0]))]


def safe(t, speeds, strict=False):
    phases = [(t * speed) % 1 for speed in speeds]
    if strict:
        return all(LOWER < x < UPPER for x in phases)
    return all(LOWER <= x <= UPPER for x in phases)


def small_table():
    table = {}
    for line in Path(__file__).with_name("c36_scan.out").read_text().splitlines():
        fields = line.split()
        if fields[0] == "B":
            continue
        v = tuple(map(int, fields[:5]))
        table[v] = F(fields[-1]) if fields[5] == "strict" else LOWER
    assert len(table) == 16
    assert all(safe(t, v) for v, t in table.items())
    return table


EXCEPTIONS = small_table()
FIXED_TIMES = tuple(F(k, q) for q in range(2, 31) for k in range(1, q // 2 + 1) if gcd(k, q) == 1)
assert len(FIXED_TIMES) == 139


def safe_center(relations, dropped):
    """Return a rational lift in ker(A) and its exact clearance."""
    center = [F(1, 2)] * DIM
    r = len(relations)
    if r == 0:
        return center, F(1, 3)
    if r == 1:
        row = relations[0]
        if sum(row) % 2:
            radius = F(1, 2 * sum(map(abs, row)))
            center = [x - radius * ((a > 0) - (a < 0)) for x, a in zip(center, row)]
        else:
            radius = F(0)
    else:
        radius_cap = F(1, 4) if r == 2 else F(3, 10)
        offsets = [dot(row, center) for row in relations]
        ranges = []
        for row, offset in zip(relations, offsets):
            width = radius_cap * sum(map(abs, row))
            ranges.append(range(ceil(offset - width), floor(offset + width) + 1))
        columns = list(zip(*relations))
        facets = [(u, sum(abs(dot(u, p)) for p in columns)) for u in sub.normals(relations)]
        best = None
        for layer in product(*ranges):
            shift = [m - offset for m, offset in zip(layer, offsets)]
            distance = max(abs(dot(u, shift)) / support for u, support in facets)
            if best is None or distance < best[0]:
                best = (distance, shift)
        assert best is not None and best[0] <= radius_cap
        radius, shift = best
        displacement = sub.feasible_point(relations, shift, radius)
        center = [x + u for x, u in zip(center, displacement)]

    layer = [dot(row, center) for row in relations]
    assert all(x.denominator == 1 for x in layer)
    coordinates = rank3.solve([[dot(a, u) for u in dropped] for a in relations], layer)
    assert coordinates is not None and all(q.denominator == 1 for q in coordinates)
    lift = combination(coordinates, dropped)
    point = [x - y for x, y in zip(center, lift)]
    assert all(dot(row, point) == 0 for row in relations)
    return point, F(1, 3) - radius


def nearby_lattice_preimage(target, projected, lifts, orthogonal):
    """Round the upper layers; solve the last planar cell by its four corners."""
    count = len(lifts)
    coordinates = [0] * count
    residual = list(target)
    first = 2 if count >= 2 else 0
    for i in range(count - 1, first - 1, -1):
        b = orthogonal[i]
        q = round(dot(residual, b) / dot(b, b))
        coordinates[i] = q
        residual = [x - q * y for x, y in zip(residual, projected[i])]
    if first:
        axes = projected[:2]
        system = [[dot(a, b) for b in axes] for a in axes]
        real = rank3.solve(system, [dot(a, residual) for a in axes])
        assert real is not None
        def error_squared(corners):
            error = [x - corners[0] * a - corners[1] * b for x, a, b in zip(residual, *axes)]
            return dot(error, error)
        coordinates[:2] = min(product(*(range(floor(q), floor(q) + 2) for q in real)), key=error_squared)
    return combination(coordinates, lifts)


def extend_relations(v, relations, lifts, dropped):
    """Lift a primitive last dual functional and size-reduce its integer row."""
    basis = [v, *lifts, *dropped]
    target = [0] * len(v)
    target[len(lifts)] = 1
    row = rank3.solve(basis, target)
    assert row is not None and all(x.denominator == 1 for x in row)
    old_orthogonal, _ = rank3.gso(relations)
    for a, star in reversed(list(zip(relations, old_orthogonal))):
        q = round(dot(row, star) / dot(star, star))
        row = [x - q * y for x, y in zip(row, a)]
    relations.append([int(x) for x in row])
    dropped.append(lifts.pop())
    assert dot(relations[-1], dropped[-1]) == 1


def select_large(v):
    norm_squared = dot(v, v)
    assert norm_squared > LIMIT
    lifts = q4.complete_basis(v)
    relations = []
    dropped = []

    for r in range(4):
        # With Lovasz parameter 1, consecutive squared GS lengths obey
        # the exact 4/3 ratio; the first two projected vectors are Gauss-reduced.
        projected, lifts = q4.lll_pairs([q4.proj(u, v) for u in lifts], lifts, F(1))
        orthogonal, _ = q4.gso(projected)
        center, clearance = safe_center(relations, dropped)
        z = nearby_lattice_preimage(q4.proj(center, v), projected, lifts, orthogonal)
        h_squared = dot(orthogonal[-1], orthogonal[-1])
        error_bound = COVER[len(lifts)] * h_squared
        relative = [x - y for x, y in zip(center, z)]
        error = q4.proj(relative, v)
        assert dot(error, error) <= error_bound
        t = (dot(relative, v) / norm_squared) % 1
        if safe(t, v, strict=True):
            return Selection(t, f"lattice-rank-{r}", tuple(map(tuple, relations)))

        assert error_bound >= clearance**2
        extend_relations(v, relations, lifts, dropped)

    raise ArithmeticError("C36 contradicts four misses above its squared-norm bound")


def select(speeds):
    """Return a safe time for five pairwise distinct, positive integer relative speeds."""
    speeds = tuple(speeds)
    if len(speeds) != DIM or any(type(x) is not int or x <= 0 for x in speeds) or len(set(speeds)) != DIM:
        raise ValueError("expected five pairwise distinct positive integers")
    scale = gcd(*speeds)
    v = tuple(x // scale for x in sorted(speeds))
    if dot(v, v) > LIMIT:
        result = select_large(v)
    elif v in EXCEPTIONS:
        result = Selection(EXCEPTIONS[v], "C36-table")
    else:
        t = next((t for t in FIXED_TIMES if safe(t, v, strict=True)), None)
        if t is None:
            raise ArithmeticError("C36 finite certificate is incomplete")
        result = Selection(t, "fixed-fractions")
    result = Selection(result.time / scale, result.route, result.relations)
    assert safe(result.time, speeds)
    return result


if __name__ == "__main__":
    import sys
    for line in sys.stdin:
        if line.strip():
            result = select(tuple(map(int, line.split())))
            print(result.time, result.route, result.relations)
