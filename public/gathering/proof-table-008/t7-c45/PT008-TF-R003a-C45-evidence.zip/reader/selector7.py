"""Q38 seven-runner selector, with explicit finite-core outcome."""

from dataclasses import dataclass
from fractions import Fraction as F
from itertools import combinations
from math import floor, gcd, isqrt, lcm

import q4
import rank3
import selector

N = 7
DIM = N - 1
TAU = F(1, 2) - F(1, N)
COVER = {**selector.COVER, 5: F(239, 108)}
dot = q4.dot


def next_bound(determinant, dimension, margin):
    return floor(determinant * COVER[dimension] / margin**2)


def determinant_bounds():
    first = next_bound(1, 5, TAU)
    second = max(next_bound(first - first % 2, 4, TAU),
                 next_bound(5, 4, TAU - F(1, 6)),
                 next_bound(first, 4, TAU - F(1, 10)))
    bounds = [1, first, second]
    for r in range(2, DIM - 1):
        bounds.append(next_bound(bounds[-1], DIM - 1 - r, F(1, r + 2) - F(1, N)))
    return tuple(bounds)


BOUNDS = determinant_bounds()
LIMIT = BOUNDS[-1]


@dataclass(frozen=True)
class Selection:
    time: F | None
    route: str
    relations: tuple[tuple[int, ...], ...]


def primitive_direction(rows):
    """One vertex of A u = 0, u >= 1, scaled to primitive integers."""
    rhs = [-sum(row) for row in rows]
    for free in combinations(range(DIM), len(rows)):
        matrix = [[row[j] for j in free] for row in rows]
        displacement = rank3.solve(matrix, rhs)
        if displacement is None or min(displacement) < 0:
            continue
        u = [F(1)] * DIM
        for j, step in zip(free, displacement):
            u[j] += step
        denominator = lcm(*(x.denominator for x in u))
        integers = [int(denominator * x) for x in u]
        divisor = gcd(*integers)
        return [x // divisor for x in integers]
    raise ArithmeticError("positive kernel has no vertex")


def small_runner_time(speeds):
    """Use Q37 at six runners and bounded exact breakpoint checks for smaller inputs."""
    count = len(speeds) + 1
    if count == 6:
        return selector.select(speeds).time
    for speed in speeds:
        for index in range(speed):
            for endpoint in (1, count - 1):
                time = F(count * index + endpoint, count * speed)
                if all(1 <= (count * (time * u % 1)) <= count - 1 for u in speeds):
                    return time
    raise ArithmeticError("smaller-runner witness is missing")


def safe_center(rows, dropped):
    r = len(rows)
    if r == 0:
        return [F(1, 2)] * DIM, TAU
    if r == 1:
        a = rows[0]
        radius = F(sum(a) % 2, 2 * sum(map(abs, a)))
        center = [F(1, 2) - radius * ((value > 0) - (value < 0)) for value in a]
        layer = dot(a, center)
        assert layer.denominator == 1 and dot(a, dropped[0]) == 1
        return [x - layer * y for x, y in zip(center, dropped[0])], TAU - radius
    u = primitive_direction(rows)
    assert all(dot(row, u) == 0 for row in rows)
    assert max(u) <= isqrt((DIM - r)**2 * BOUNDS[r])
    reduced = tuple(sorted(set(u)))
    assert len(reduced) <= r + 1
    time = small_runner_time(reduced)
    center = [u_i * time for u_i in u]
    assert all(F(1, r + 2) <= x % 1 <= 1 - F(1, r + 2) for x in center)
    return center, F(1, r + 2) - F(1, N)


def select(speeds):
    """Return a strict witness or an explicitly identified Q38 finite-core survivor."""
    speeds = tuple(speeds)
    if len(speeds) != DIM or any(type(x) is not int or x <= 0 for x in speeds) or len(set(speeds)) != DIM:
        raise ValueError("expected six pairwise distinct positive integers")
    scale = gcd(*speeds)
    v = tuple(x // scale for x in sorted(speeds))
    norm_squared = dot(v, v)
    lifts = q4.complete_basis(v)
    relations = []
    dropped = []
    for r in range(DIM - 1):
        projected, lifts = q4.lll_pairs([q4.proj(u, v) for u in lifts], lifts, F(1))
        orthogonal, _ = q4.gso(projected)
        center, margin = safe_center(relations, dropped)
        z = selector.nearby_lattice_preimage(q4.proj(center, v), projected, lifts, orthogonal)
        relative = [x - y for x, y in zip(center, z)]
        error = q4.proj(relative, v)
        bound = COVER[len(lifts)] * dot(orthogonal[-1], orthogonal[-1])
        assert dot(error, error) <= bound
        time = (dot(relative, v) / norm_squared) % 1
        if all(F(1, N) < (time * x % 1) < 1 - F(1, N) for x in v):
            return Selection(time / scale, f"lattice-rank-{r}", tuple(map(tuple, relations)))
        assert bound >= margin**2
        selector.extend_relations(v, relations, lifts, dropped)
        relation_gso, _ = rank3.gso(relations)
        determinant = F(1)
        for a in relation_gso:
            determinant *= dot(a, a)
        assert determinant.denominator == 1 and determinant <= BOUNDS[r + 1]
    assert norm_squared <= LIMIT
    return Selection(None, "finite-core", tuple(map(tuple, relations)))
