# R003a-Q08-A02 (Opus): reading t directly in the 4-dim quotient lattice L = pi(Z^5), pi = projection along v.
#   safe t exists  <=>  L meets K = pi(Q0), Q0 = [1/6,5/6]^5.   For l = pi(y), y in Z^5:  window {t : y_i + t v_i in [1/6,5/6]}.
#   K contains the ball B(pi(c0), 1/3), c0 = (1/2,...,1/2); diam K <= 2 sqrt5 / 3; width of K along a unit u (u . v = 0) = (2/3)|u|_1.
from fractions import Fraction as F
from math import floor, ceil, gcd, isqrt
def dot(a, b): return sum(x * y for x, y in zip(a, b))
def dist(x): x = x - (x.numerator // x.denominator); return min(x, 1 - x)
def complete_basis(v):
    """integer vectors u2..u5 with (v, u2..u5) a basis of Z^5 (v primitive)"""
    n = len(v); R = [[int(i == j) for j in range(n)] for i in range(n)]; y = list(v)
    while sum(1 for t in y if t) > 1:
        nz = [i for i in range(n) if y[i]]; p = min(nz, key=lambda i: abs(y[i]))
        for i in nz:
            if i != p: q = y[i] // y[p]; y[i] -= q * y[p]; R[i] = [a - q * b for a, b in zip(R[i], R[p])]
    p = next(i for i in range(n) if y[i])
    if p: R[0], R[p] = R[p], R[0]; y[0], y[p] = y[p], y[0]
    if y[0] < 0: R[0] = [-a for a in R[0]]; y[0] = -y[0]
    assert y[0] == 1
    # R . v = e1 (rows act on coordinates); the columns of R^{-1} form a basis with first column v
    M = [[F(x) for x in row] + [F(int(i == j)) for j in range(n)] for i, row in enumerate(R)]
    for col in range(n):
        pv = next(r for r in range(col, n) if M[r][col] != 0); M[col], M[pv] = M[pv], M[col]
        piv = M[col][col]; M[col] = [x / piv for x in M[col]]
        for r in range(n):
            if r != col and M[r][col] != 0: M[r] = [a - M[r][col] * b for a, b in zip(M[r], M[col])]
    Q = [[int(x) for x in row[n:]] for row in M]
    cols = [[Q[i][k] for i in range(n)] for k in range(n)]
    assert cols[0] == list(v)
    return cols[1:]
def proj(x, v):
    vv = dot(v, v); return [F(a) - F(dot(x, v), vv) * b for a, b in zip(x, v)]
def gso(P):
    Bs = []; mu = [[F(0)] * len(P) for _ in P]
    for i, b in enumerate(P):
        w = list(b)
        for j in range(i):
            mu[i][j] = dot(b, Bs[j]) / dot(Bs[j], Bs[j]); w = [x - mu[i][j] * y for x, y in zip(w, Bs[j])]
        Bs.append(w)
    return Bs, mu
def lll_pairs(P, U, delta):
    """LLL on projected vectors P with integer preimages U kept in step (exact)"""
    P = [list(p) for p in P]; U = [list(u) for u in U]; k = 1
    while k < len(P):
        Bs, mu = gso(P)
        for j in range(k - 1, -1, -1):
            q = round(mu[k][j])
            if q:
                P[k] = [a - q * b for a, b in zip(P[k], P[j])]; U[k] = [a - q * b for a, b in zip(U[k], U[j])]; Bs, mu = gso(P)
        if dot(Bs[k], Bs[k]) >= (delta - mu[k][k - 1] ** 2) * dot(Bs[k - 1], Bs[k - 1]): k += 1
        else: P[k], P[k - 1] = P[k - 1], P[k]; U[k], U[k - 1] = U[k - 1], U[k]; k = max(k - 1, 1)
    return P, U
def window(v, y):
    lo = max(((F(1, 6) - a) / b if b > 0 else (F(5, 6) - a) / b) for a, b in zip(y, v))
    hi = min(((F(5, 6) - a) / b if b > 0 else (F(1, 6) - a) / b) for a, b in zip(y, v))
    return lo, hi
def read(v, delta=F(3, 4)):
    """Babai first try; if it misses, report the slice range along the last GS vector (first cut)"""
    U0 = complete_basis(v); P0 = [proj(u, v) for u in U0]
    P, U = lll_pairs(P0, U0, delta); Bs, mu = gso(P)
    c0 = [F(1, 2)] * 5; target = proj(c0, v)
    # Babai nearest plane, tracking integer coefficients
    r = list(target); coef = [0] * 4
    for i in range(3, -1, -1):
        q = round(dot(r, Bs[i]) / dot(Bs[i], Bs[i])); coef[i] = q; r = [a - q * b for a, b in zip(r, P[i])]
    y = [sum(coef[i] * U[i][j] for i in range(4)) for j in range(5)]
    lo, hi = window(v, y)
    info = {"gs2": [dot(b, b) for b in Bs], "babai_err2": dot(r, r), "babai_hit": lo <= hi}
    # first cut: c4 = <x, b4*>/|b4*|^2 for x in K = pi(Q0): exact box LP (b4* is orthogonal to v)
    b4 = Bs[3]; nb = dot(b4, b4)
    fmin = sum(min(F(1, 6) * c, F(5, 6) * c) for c in b4) / nb; fmax = sum(max(F(1, 6) * c, F(5, 6) * c) for c in b4) / nb
    info["slices"] = max(0, floor(fmax) - ceil(fmin) + 1); info["slice_range"] = (fmin, fmax)
    info["bound_slices"] = None
    if lo <= hi:
        t = lo; assert all(dist(t * a) >= F(1, 6) for a in v); return t, y, info, (P, U, Bs)
    return None, y, info, (P, U, Bs)
