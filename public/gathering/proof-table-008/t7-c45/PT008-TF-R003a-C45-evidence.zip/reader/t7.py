"""Exact PT008 C45 reader for six distinct positive relative speeds."""

from dataclasses import dataclass
from fractions import Fraction
from functools import lru_cache
from math import gcd

from q41_layers import centre_layer, layered, to_rank3

NORM_LIMIT = 679_422_901
EQUAL_SPACING = (1, 2, 3, 4, 5, 6)


@dataclass(frozen=True)
class Result:
    time: Fraction
    route: str
    minimum: Fraction


@lru_cache(maxsize=8192)
def phase_mask(q, speed_residue):
    return sum(1 << k for k in range(1, q // 2 + 1)
               if q < 7 * ((k * speed_residue) % q) < 6 * q)


def grid_time(v, q):
    k_mask = (1 << (q // 2 + 1)) - 2
    for speed in v:
        k_mask &= phase_mask(q, speed % q)
    if not k_mask:
        return None
    k = (k_mask & -k_mask).bit_length() - 1
    return Fraction(k, q)


def certified_anchors(v):
    if sum(speed * speed for speed in v) > NORM_LIMIT:
        return ()
    if sum(speed % 7 == 0 for speed in v) > 2:
        return ()
    thirteen = tuple(speed for speed in v if speed % 13 == 0)
    if 13_013 in v and len(thirteen) <= 2:
        q_anchor = next((speed for speed in thirteen if speed != 13_013), None)
        if q_anchor is not None and q_anchor % 637 == 0:
            return (343,) if q_anchor % 169 == 0 else (2197,)
        if q_anchor is not None and q_anchor % 7 == 0:
            return (4459,)
        if all(speed % 91 for speed in v if speed != 13_013):
            return (1274,)
    if len(thirteen) == 2:
        first = next((speed for speed in thirteen
                      if speed % 1001 == 0 and speed % 169 != 0), None)
        second = next((speed for speed in thirteen
                       if speed % 169 == 0 and speed % 1001 != 0), None)
        if first is not None and second is not None:
            b, c = first // 1001, second // 169
            if c % 7 != 0:
                return (1183,)
            if b % 7 != 0 and c % 49 != 0:
                return (4459,)
            return (2197,) if c % 13 != 0 else (343,)
    return ()


def exact_result(v, time, route, strict=True):
    minimum = min(min((speed * time) % 1, (-speed * time) % 1) for speed in v)
    if minimum < Fraction(1, 7) or (strict and minimum == Fraction(1, 7)):
        raise ArithmeticError("unsafe output")
    return Result(time, route, minimum)


def read(speeds):
    speeds = tuple(speeds)
    if (len(speeds) != 6 or any(type(x) is not int or x <= 0 for x in speeds)
            or len(set(speeds)) != 6):
        raise ValueError("expected six distinct positive integers")
    scale = gcd(*speeds)
    v = tuple(sorted(speed // scale for speed in speeds))
    if v == EQUAL_SPACING:
        return exact_result(speeds, Fraction(1, 7 * scale), "equal-spacing", strict=False)

    for q in certified_anchors(v):
        time = grid_time(v, q)
        if time is None:
            raise ArithmeticError(f"C45 certificate: missing point for q={q}")
        return exact_result(speeds, time / scale, f"grid-{q}")

    _, rank_data = to_rank3(v)
    if isinstance(rank_data, tuple):
        label, time = rank_data
        return exact_result(speeds, time / scale, label)
    time, is_strict = rank_data["rounding"]
    if not is_strict:
        center = layered(v, rank_data, only_layer=centre_layer(rank_data))
        time = center["time"]
    if time is None:
        time = layered(v, rank_data, after_center=True)["time"]
    if time is None:
        raise ArithmeticError("C45 coverage: missing strict time outside equal spacing")
    return exact_result(speeds, time / scale, "rank-3")


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("speeds", nargs=6, type=int)
    args = parser.parse_args()
    point = read(args.speeds)
    print(f"time={point.time}  minimum={point.minimum}  route={point.route}")
