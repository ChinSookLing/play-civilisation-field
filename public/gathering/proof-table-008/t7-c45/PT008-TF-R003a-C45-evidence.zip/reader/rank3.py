# R003a-Q09 (Opus): rank-3 relation matrix A, one remaining relation r, 1-dim sections.
#   x in Q0=[1/6,5/6]^5 lies in Z^5 + R v  <=>  <rho,x> in Z for all rho in R = Z^5 ∩ v^perp.
#   With (a1,a2,a3,r) a basis of R:  layer mu = A x in Z^3 ,  section I(mu) = { <r,x> : x in Q0, A x = mu },
#   the layer holds a lattice point  <=>  I(mu) ∩ Z != {} .
from fractions import Fraction as F
from itertools import combinations, product
from math import floor, ceil
import q4
dot=q4.dot
def relation_basis(v):
    """unimodular Rm with Rm v = e1; rows 1..4 = basis of R"""
    n=len(v); Rm=[[int(i==j) for j in range(n)] for i in range(n)]; y=list(v)
    while sum(1 for t in y if t)>1:
        nz=[i for i in range(n) if y[i]]; p=min(nz,key=lambda i:abs(y[i]))
        for i in nz:
            if i!=p: q=y[i]//y[p]; y[i]-=q*y[p]; Rm[i]=[a-q*b for a,b in zip(Rm[i],Rm[p])]
    p=next(i for i in range(n) if y[i])
    if p: Rm[0],Rm[p]=Rm[p],Rm[0]; y[0],y[p]=y[p],y[0]
    if y[0]<0: Rm[0]=[-a for a in Rm[0]]
    return [row for row in Rm[1:]]
def gso(B):
    Bs=[];mu=[[F(0)]*len(B) for _ in B]
    for i,b in enumerate(B):
        w=[F(x) for x in b]
        for j in range(i):
            mu[i][j]=dot(b,Bs[j])/dot(Bs[j],Bs[j]); w=[x-mu[i][j]*y for x,y in zip(w,Bs[j])]
        Bs.append(w)
    return Bs,mu
def lll(B,delta=F(99,100)):
    B=[list(b) for b in B]; k=1
    while k<len(B):
        Bs,mu=gso(B)
        for j in range(k-1,-1,-1):
            q=round(mu[k][j])
            if q: B[k]=[a-q*b for a,b in zip(B[k],B[j])]; Bs,mu=gso(B)
        if dot(Bs[k],Bs[k])>=(delta-mu[k][k-1]**2)*dot(Bs[k-1],Bs[k-1]): k+=1
        else: B[k],B[k-1]=B[k-1],B[k]; k=max(k-1,1)
    return B
def solve(M,b):
    """unique exact solution of M x = b (M: m x c, full column rank required), else None"""
    m=len(M); c=len(M[0]) if M else 0
    if c==0: return [] if all(x==0 for x in b) else None
    T=[[F(x) for x in row]+[F(bb)] for row,bb in zip(M,b)]; r=0; piv=[]
    for col in range(c):
        p=next((i for i in range(r,m) if T[i][col]!=0),None)
        if p is None: return None
        T[r],T[p]=T[p],T[r]; pv=T[r][col]; T[r]=[x/pv for x in T[r]]
        for i in range(m):
            if i!=r and T[i][col]!=0: T[i]=[a-T[i][col]*bq for a,bq in zip(T[i],T[r])]
        piv.append(col); r+=1
    if any(T[i][c]!=0 for i in range(r,m)): return None
    return [T[i][c] for i in range(c)]
LO,HI=F(1,6),F(5,6)
def vertices(M,rhs):
    """all vertices of {x in Q0 : M x = rhs}"""
    n=5; out=set()
    for k in range(0,len(M)+1):
        for Fr in combinations(range(n),k):
            S=[i for i in range(n) if i not in Fr]
            MF=[[row[i] for i in Fr] for row in M]
            for bnd in product((LO,HI),repeat=len(S)):
                rr=[bb-sum(row[i]*x for i,x in zip(S,bnd)) for row,bb in zip(M,rhs)]
                xf=solve(MF,rr) if k else (None if any(t!=0 for t in rr) else [])
                if xf is None: continue
                if all(LO<=t<=HI for t in xf):
                    x=[None]*n
                    for i,t in zip(Fr,xf): x[i]=t
                    for i,t in zip(S,bnd): x[i]=t
                    out.add(tuple(x))
    return out
def section(A,r,mu):
    V=vertices(A,mu)
    if not V: return None
    vals=[dot(r,x) for x in V]; return (min(vals),max(vals))
def cross(a,b): return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def znorm(A,z):
    """norm of z in Z(A)=A[-1,1]^5 (A: 3x5 rank 3)"""
    cols=[[A[i][j] for i in range(3)] for j in range(5)]; best=F(0)
    for a,b in combinations(cols,2):
        u=cross(a,b)
        if any(u): best=max(best,F(abs(dot(u,z)),sum(abs(dot(u,c)) for c in cols)))
    return best
def setup(v,order=(0,1,2,3)):
    Rb=lll(relation_basis(v)); A=[Rb[i] for i in order[:3]]; r=Rb[order[3]]
    G=[[dot(a,b) for b in A] for a in A]
    detG=(G[0][0]*(G[1][1]*G[2][2]-G[1][2]*G[2][1])-G[0][1]*(G[1][0]*G[2][2]-G[1][2]*G[2][0])+G[0][2]*(G[1][0]*G[2][1]-G[1][1]*G[2][0]))
    g2=F(detG,dot(v,v))       # g^2 = det(Lambda)^2/|v|^2 = spacing^2 of the v-lines in W
    return Rb,A,r,g2
def layers(A,r):
    c=[F(sum(a),2) for a in A]; out=[]
    rng=[range(ceil(sum(min(LO*x,HI*x) for x in a)),floor(sum(max(LO*x,HI*x) for x in a))+1) for a in A]
    for mu in product(*rng):
        zn=znorm(A,[m-cc for m,cc in zip(mu,c)])
        if zn>F(1,3): continue
        I=section(A,r,list(mu))
        assert I is not None, (A,mu)      # zonotope test == fiber nonempty
        hit=ceil(I[0])<=floor(I[1])
        out.append({"mu":mu,"sigma":F(1,3)-zn,"I":I,"hit":hit})
    return out
def readout(v,A,r,mu,k):
    """x in Q0 with A x = mu, <r,x> = k  ->  rational t with all ||t v_i|| >= 1/6"""
    M=A+[r]; V=vertices(M,list(mu)+[k]); x=next(iter(V))
    Rm1=relation_basis(v)            # basis of R; express M rows in it, solve integer n with M n = -(mu,k)
    # n := any integer solution of M n = -b : M = T Rb, Rb n = T^{-1}(-b); build via Rm (unimodular) inverse
    n=len(v); Rm=[[F(0)]*n for _ in range(n)]
    full=[list(row) for row in Rm1]; vrow=None
    # unimodular matrix with rows (any w with <w,v>=1 ; Rb rows): find w by solving
    U0=q4.complete_basis(v)          # columns (v,u2..u5) basis of Z^5
    # coordinates: z = a0 v + sum a_j u_j ;  M z depends only on a_j ; solve 4x4 integer system
    Mu=[[dot(row,u) for u in U0] for row in M]
    a=solve(Mu,[-x_ for x_ in list(mu)+[k]]); assert all(t.denominator==1 for t in a)
    nn=[sum(int(a[j])*U0[j][i] for j in range(4)) for i in range(n)]
    w=[xi+ni for xi,ni in zip(x,nn)]   # in R v
    t=F(dot(w,v),dot(v,v)); assert all(wi==t*vi for wi,vi in zip(w,v))
    assert all(q4.dist(t*vi)>=F(1,6) for vi in v)
    return t
