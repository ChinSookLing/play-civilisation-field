# Opus Q41: complete rank-3 reading for seven runners over ALL phase layers.
# Adapted for C45: Q38 modules load from the same directory. C41 reflection is available.
#
# Data at rank 3 (Q38 structure): relations a_1..a_3 (saturated L_3), lifts g_1, g_2 with (v, g_1, g_2) a basis of
# M = V_3 cap Z^6, dropped d_1..d_3 with (v, g_1, g_2, d_1, d_2, d_3) a basis of Z^6 and P = [a_i . d_j] unimodular.
# Strict time t  <=>  exist s in R, b in Z^2, gamma in Z^3 with  y = s v + b_1 g_1 + b_2 g_2 + K(gamma) in B = (1/7,6/7)^6,
#                     K(gamma) = sum gamma_j d_j ;  then t = s mod 1.
# Layer label m = A y = P gamma in Z^3; m_i ranges over the integers in the open interval {a_i . y : y in B}.
# Lines: b_2 = <y - K, b2*>/|b2*|^2 (b2* = second GS vector of the reduced projected basis), an integer in an open interval.
# For fixed (m, b_2) the admissible b_1 form an open interval (30 linear conditions), and for fixed (m, b) the admissible s
# form the open interval (max_i (1/7 - w_i)/v_i, min_i (6/7 - w_i)/v_i).  Closed variant: closed box, closed intervals.
import q4, rank3, selector, selector7
from fractions import Fraction as F
from math import gcd, floor, ceil
dot = q4.dot
LO, HI = F(1, 7), F(6, 7)
def frac(x): return x - (x.numerator // x.denominator)
def strict(t, v): return all(LO < frac(t * x) < HI for x in v)
def closed(t, v): return all(LO <= frac(t * x) <= HI for x in v)
def box_range(c):          # range of c . y over y in B (as endpoints)
    return sum(min(LO * x, HI * x) for x in c), sum(max(LO * x, HI * x) for x in c)
def ints_open(lo, hi): return range(floor(lo) + 1, ceil(hi))
def ints_closed(lo, hi): return range(ceil(lo), floor(hi) + 1)
def to_rank3(speeds):
    g0 = gcd(*speeds); v = tuple(x // g0 for x in sorted(speeds)); nv = dot(v, v)
    lifts = q4.complete_basis(v); relations = []; dropped = []
    for r in range(4):
        projected, lifts = q4.lll_pairs([q4.proj(u, v) for u in lifts], lifts, F(1))
        orthogonal, _ = q4.gso(projected)
        center, margin = selector7.safe_center(relations, dropped)
        z = selector.nearby_lattice_preimage(q4.proj(center, v), projected, lifts, orthogonal)
        rel = [a - b for a, b in zip(center, z)]
        t = (dot(rel, v) / nv) % 1
        if r == 3:
            return v, dict(relations=[list(a) for a in relations], dropped=[list(d) for d in dropped], lifts=lifts,
                           projected=projected, orthogonal=orthogonal, center=center, rounding=(t, strict(t, v)))
        if strict(t, v): return v, ("read at rank %d" % r, t)
        selector.extend_relations(v, relations, lifts, dropped)
def layered(v, R, mode="strict", only_layer=None, after_center=False):
    A, D, (g1, g2) = R["relations"], R["dropped"], R["lifts"]
    b2s = R["orthogonal"][1]; h22 = dot(b2s, b2s)
    Pm = [[dot(a, d) for d in D] for a in A]
    ints = ints_open if mode == "strict" else ints_closed
    lt = (lambda a, b: a < b) if mode == "strict" else (lambda a, b: a <= b)
    ranges = [ints(*box_range(a)) for a in A]
    layers = 0; lines = 0; maxlines = 0
    from itertools import product

    center = centre_layer(R) if after_center else None
    reflection_sum = tuple(sum(a) for a in A)
    for m in product(*ranges):
        if only_layer is not None and m != tuple(only_layer):
            continue
        if after_center:
            reflected = tuple(a - b for a, b in zip(reflection_sum, m))
            if m > reflected or center in (m, reflected):
                continue
        gam = rank3.solve(Pm, list(m)); assert gam is not None and all(x.denominator == 1 for x in gam)
        K = [sum(int(gj) * d[i] for gj, d in zip(gam, D)) for i in range(6)]
        layers += 1
        flo, fhi = box_range(b2s); kk = dot(K, b2s)
        cs = ints((flo - kk) / h22, (fhi - kk) / h22); lines += len(cs); maxlines = max(maxlines, len(cs))
        for c in cs:
            lo, hi = None, None; ok = True
            for i in range(6):
                for j in range(6):
                    if i == j: continue
                    kap = v[j] * g1[i] - v[i] * g1[j]
                    rhs = v[j] * (LO - K[i] - c * g2[i]) - v[i] * (HI - K[j] - c * g2[j])
                    # condition: rhs < b1 * kap  (strict)  or <= (closed)
                    if kap == 0:
                        if not lt(rhs, 0): ok = False
                    elif kap > 0:
                        q = rhs / kap; lo = q if lo is None or q > lo else lo
                    else:
                        q = rhs / kap; hi = q if hi is None or q < hi else hi
            if not ok or lo is None or hi is None: continue
            cand = ints(lo, hi)
            if len(cand) == 0: continue
            b1 = cand[0]
            w = [b1 * x + c * y + k for x, y, k in zip(g1, g2, K)]
            smin = max((LO - wi) / vi for wi, vi in zip(w, v)); smax = min((HI - wi) / vi for wi, vi in zip(w, v))
            assert lt(smin, smax)
            t = ((smin + smax) / 2) % 1
            assert (strict if mode == "strict" else closed)(t, v)
            return dict(time=t, layer=tuple(m), b=(b1, c), layers=layers, lines=lines, maxlines=maxlines)
    return dict(time=None, layers=layers, lines=lines, maxlines=maxlines, layer_count=len(list(product(*ranges))))
def centre_layer(R):
    y0 = [frac(x) for x in R["center"]]
    return tuple(dot(a, y0) for a in R["relations"])
def pairsum(v, mode="strict"):
    for i in range(6):
        for j in range(i, 6):
            S = v[i] + v[j]
            for k in range(1, S):
                r = [(k * x) % S for x in v]
                if mode == "strict" and all(S < 7 * q < 6 * S for q in r): return F(k, S)
                if mode == "closed" and all(S <= 7 * q <= 6 * S for q in r): return F(k, S)
    return None
