# R003a-Q13-A02 (Opus): nearest sub-layer criterion  delta^2 + rho_hat^2 <= eta^2  -- independent checker (six runners, any k)
from fractions import Fraction as F
from itertools import combinations, product
from math import gcd, floor, ceil
import q4, pairs, rank3 as R
dot=q4.dot; N=5; LO,HI=F(1,6),F(5,6); R0=F(1,3)        # inball radius of Q0 around 1/2
def det(M): return pairs.det(M)
def minors_gcd(M):
    k=len(M); g=0
    for cols in combinations(range(N),k):
        g=gcd(g,int(det([[row[c] for c in cols] for row in M])))
    return g
def gram(M): return det([[dot(a,b) for b in M] for a in M]) if M else F(1)
def normals(A):
    """facet normals of the zonotope A[-1,1]^N in R^k : vectors orthogonal to k-1 independent columns"""
    k=len(A); cols=[[A[i][j] for i in range(k)] for j in range(N)]; out=[]
    if k==1: return [[1]]
    for S in combinations(cols,k-1):
        # cofactor vector u_i = (-1)^i det(S without row i)
        u=[(-1)**i*det([[s[r] for r in range(k) if r!=i] for s in S]) for i in range(k)]
        if any(u): out.append(u)
    return out
def znorm(A,d):
    cols=[[A[i][j] for i in range(len(A))] for j in range(N)]; best=F(0)
    for u in normals(A):
        best=max(best,F(abs(dot(u,d)))/sum(abs(dot(u,c)) for c in cols))
    return best
def solve(M,b): return R.solve(M,b)
def feasible_point(A,d,rho):
    """a vertex z of {z in [-rho,rho]^N : A z = d}"""
    k=len(A)
    for Fr in combinations(range(N),k):
        S=[i for i in range(N) if i not in Fr]
        for bnd in product((-rho,rho),repeat=len(S)):
            rr=[dd-sum(row[i]*x for i,x in zip(S,bnd)) for row,dd in zip(A,d)]
            zf=solve([[row[i] for i in Fr] for row in A],rr)
            if zf is not None and all(-rho<=t<=rho for t in zf):
                z=[None]*N
                for i,t in zip(Fr,zf): z[i]=t
                for i,t in zip(S,bnd): z[i]=t
                return z
    raise RuntimeError
def mother_layers(A):
    h=[F(sum(a),2) for a in A]
    rng=[range(ceil(sum(min(LO*x,HI*x) for x in a)),floor(sum(max(LO*x,HI*x) for x in a))+1) for a in A]
    out=[]
    for mu in product(*rng):
        d=[m-hh for m,hh in zip(mu,h)]; rho=znorm(A,d)
        if rho<R0:
            z=feasible_point(A,d,rho); c=[F(1,2)+t for t in z]
            assert all(dot(a,c)==m for a,m in zip(A,mu))
            out.append((mu,c,R0-rho))
    return out
def col_hnf(M):
    """unimodular U with M U = [H | 0], H lower triangular (k x k)"""
    k=len(M); Mm=[list(r) for r in M]; U=[[int(i==j) for j in range(N)] for i in range(N)]
    def colop(j,l,q):
        for r in Mm: r[j]-=q*r[l]
        for r in U: r[j]-=q*r[l]
    def swap(j,l):
        for r in Mm: r[j],r[l]=r[l],r[j]
        for r in U: r[j],r[l]=r[l],r[j]
    for row in range(k):
        while True:
            nz=[j for j in range(row,N) if Mm[row][j]]
            p=min(nz,key=lambda j:abs(Mm[row][j])); swap(row,p)
            if all(Mm[row][j]==0 for j in range(row+1,N)): break
            for j in range(row+1,N):
                if Mm[row][j]: colop(j,row,Mm[row][j]//Mm[row][row])
    return Mm,U
def integer_lift(M,target):
    """integer m with M m = target (exists for every integer target iff M saturated)"""
    H,U=col_hnf(M); k=len(M); w=[]
    for i in range(k):
        s=target[i]-sum(H[i][j]*w[j] for j in range(i))
        if s%H[i][i]: return None
        w.append(s//H[i][i])
    w+= [0]*(N-k)
    return [sum(U[i][j]*w[j] for j in range(N)) for i in range(N)]
def sub_lattice(M,v):
    """basis (projected along v, LLL-reduced) of Gamma' = pi(ker M ∩ Z^N), with integer preimages"""
    K=pairs.int_kernel(M)                      # basis of Lambda' (contains v)
    d=len(K)
    # coordinates of v in K : solve K^T c = v
    c=solve([[K[j][i] for j in range(d)] for i in range(N)],v); c=[int(x) for x in c]
    if d==1: return [],[]
    comp=q4.complete_basis(c)                  # (c, comp...) basis of Z^d
    U=[[sum(cc[j]*K[j][i] for j in range(d)) for i in range(N)] for cc in comp]
    P=[q4.proj(u,v) for u in U]
    P,U=q4.lll_pairs(P,U,F(99,100))
    return P,U
def check(v,A,mu,c,eta,b,j=None):
    M=A+[b]; rec={"b":b}
    rec["saturated"]=minors_gcd(M)==1
    DA,DM=gram(A),gram(M); p2=DM/DA; bc=dot(b,c)
    if j is None: j=floor(bc+F(1,2))
    rec.update(j=j,delta2=(j-bc)**2/p2,eta2=eta*eta,p2=p2,round_bound2=1/(4*p2))
    P,U=sub_lattice(M,v)
    Bs,mu_=q4.gso(P) if P else ([],[])
    rec["rho2"]=sum(dot(x,x) for x in Bs)/4 if Bs else F(0)
    rec["rank"]=len(P)
    rec["criterion"]=rec["delta2"]+rec["rho2"]<=rec["eta2"]
    m0=integer_lift(M,list(mu)+[j]); rec["lift"]=m0 is not None
    if m0 is None: rec["t"]=None; return rec
    # foot point c' in the sub-layer, then Babai in the coset pi(m0)+Gamma'
    p=[b[i]-sum(0 for _ in [0]) for i in range(N)]
    # p = projection of b onto ker A : b - A^T (AA^T)^{-1} A b
    G=[[dot(a,bb) for bb in A] for a in A]; Gi=q4inv(G); Ab=[dot(a,b) for a in A]
    lam=[sum(Gi[i][l]*Ab[l] for l in range(len(A))) for i in range(len(A))]
    p=[b[i]-sum(lam[l]*A[l][i] for l in range(len(A))) for i in range(N)]
    cp=[ci-(bc-j)/p2*pi for ci,pi in zip(c,p)]
    tgt=q4.proj([a-m for a,m in zip(cp,m0)],v); y=list(m0); rr=list(tgt)
    for i in range(len(P)-1,-1,-1):
        q=floor(dot(rr,Bs[i])/dot(Bs[i],Bs[i])+F(1,2)); rr=[a-q*bb for a,bb in zip(rr,P[i])]; y=[a+q*bb for a,bb in zip(y,U[i])]
    rec["babai_err2"]=dot(rr,rr)
    lo,hi=q4.window(v,y); rec["t"]=lo if lo<=hi else None
    if rec["t"] is not None:
        x=[a+rec["t"]*bb for a,bb in zip(y,v)]
        assert all(dot(a,x)==m for a,m in zip(A,mu)) and dot(b,x)==j and all(q4.dist(rec["t"]*a)>=F(1,6) for a in v)
    return rec
def q4inv(M):
    n=len(M); T=[[F(x) for x in row]+[F(int(i==j)) for j in range(n)] for i,row in enumerate(M)]
    for cc in range(n):
        p=next(i for i in range(cc,n) if T[i][cc]!=0); T[cc],T[p]=T[p],T[cc]; pv=T[cc][cc]; T[cc]=[x/pv for x in T[cc]]
        for i in range(n):
            if i!=cc and T[i][cc]!=0: T[i]=[a-T[i][cc]*bb for a,bb in zip(T[i],T[cc])]
    return [row[n:] for row in T]
