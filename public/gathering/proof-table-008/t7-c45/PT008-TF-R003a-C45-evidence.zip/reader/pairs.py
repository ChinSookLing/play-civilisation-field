# same A (rank 3, saturated), same |v|  ->  same candidate layers, same slacks sigma_m, same spacing g ;
# compare which layers hold lattice points for v and for v'.
import random, sys
from fractions import Fraction as F
from math import gcd
import rank3 as R, q4
dot=q4.dot
def det(M):
    M=[[F(x) for x in r] for r in M]; n=len(M); d=F(1)
    for c in range(n):
        p=next((i for i in range(c,n) if M[i][c]!=0),None)
        if p is None: return F(0)
        if p!=c: M[c],M[p]=M[p],M[c]; d=-d
        d*=M[c][c]
        for i in range(c+1,n):
            f=M[i][c]/M[c][c]; M[i]=[a-f*b for a,b in zip(M[i],M[c])]
    return d
def int_kernel(A):
    """basis of {x in Z^n : A x = 0} by unimodular column operations"""
    m=len(A); n=len(A[0]); M=[list(r) for r in A]; U=[[int(i==j) for j in range(n)] for i in range(n)]
    def colop(j,k,q):   # col j -= q col k
        for r in M: r[j]-=q*r[k]
        for r in U: r[j]-=q*r[k]
    def swap(j,k):
        for r in M: r[j],r[k]=r[k],r[j]
        for r in U: r[j],r[k]=r[k],r[j]
    piv=0
    for row in range(m):
        while True:
            nz=[j for j in range(piv,n) if M[row][j]]
            if not nz: break
            k=min(nz,key=lambda j:abs(M[row][j])); swap(piv,k)
            done=True
            for j in range(piv+1,n):
                if M[row][j]: colop(j,piv,M[row][j]//M[row][piv]); done=False
            if all(M[row][j]==0 for j in range(piv+1,n)): break
        if any(M[row][j] for j in range(piv,n)): piv+=1
    return [[U[i][j] for i in range(n)] for j in range(piv,n)]
def prim(v):
    g=0
    for x in v: g=gcd(g,x)
    return g==1
def good(w): return 0 not in w and len({abs(x) for x in w})==5 and prim(w)
def fourth(A,w):
    nv=dot(w,w); Rw=R.lll(R.relation_basis(w))
    for c in Rw:
        if det([[dot(a,b) for b in A+[c]] for a in A+[c]])==nv: return c
    from itertools import product
    for co in product(range(-2,3),repeat=4):
        cc=[sum(ci*row[j] for ci,row in zip(co,Rw)) for j in range(5)]
        if det([[dot(a,b) for b in A+[cc]] for a in A+[cc]])==nv: return cc
    raise RuntimeError
if __name__=="__main__":
    random.seed(int(sys.argv[1])); want=int(sys.argv[2]); found=0; tried=0; same_total=0; agree=0
    while found<want and tried<3000:
        v=[random.randint(-9,9) for _ in range(5)]
        if not good(v): continue
        tried+=1
        Rb,A,r,g2=R.setup(v)
        K=int_kernel(A); assert len(K)==2 and all(dot(a,k)==0 for a in A for k in K)
        # Lambda basis (p,q); v = alpha p + beta q
        p,q=K; nv=dot(v,v); same=[]
        for al in range(-25,26):
            for be in range(-25,26):
                w=[al*a+be*b for a,b in zip(p,q)]
                if dot(w,w)==nv and w!=v and w!=[-x for x in v] and good(w): same.append(w)
        if not same: continue
        L=R.layers(A,r); hv={l["mu"] for l in L if l["hit"]}
        smax=max(l["sigma"] for l in L); top={l["mu"] for l in L if l["sigma"]==smax}
        for w in same:
            same_total+=1
            rw=fourth(A,w); Lw=R.layers(A,rw); hw={l["mu"] for l in Lw if l["hit"]}
            assert {l["mu"]:l["sigma"] for l in L}=={l["mu"]:l["sigma"] for l in Lw}
            if hv==hw: agree+=1; continue
            found+=1
            print("PAIR v",v,"w",w,"|v|^2",nv,"A",A,"r_v",r,"r_w",rw)
            print("   layers",sorted(l["mu"] for l in L))
            print("   sigma",{l["mu"]:str(l["sigma"]) for l in L})
            print("   hits v",sorted(hv),"hits w",sorted(hw),"max-sigma layers",sorted(top),"g^2",g2,flush=True)
            break
    print("tried",tried,"same-norm partners",same_total,"identical hit sets",agree,"differing pairs",found)
