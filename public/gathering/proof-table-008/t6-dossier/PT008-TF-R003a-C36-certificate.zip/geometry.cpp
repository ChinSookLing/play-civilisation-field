#include <algorithm>
#include <array>
#include <cstdint>
#include <cmath>
#include <iostream>
#include <numeric>
#include <vector>
using Vec = std::array<int,5>;
std::vector<Vec> all_a;

bool primitive(const Vec &a) {
    int g=0;
    for(int x:a) g=std::gcd(g,x);
    return g==1;
}

void make_a(Vec &a,int pos,int max) {
    if (pos==5) {
        if (a[1]>0 && primitive(a)) all_a.push_back(a);
        return;
    }
    for(int x=max;x>=0;--x) {a[pos]=x;make_a(a,pos+1,x);}
}

bool possible(const Vec &a,const Vec &b) {
    for (int i=0;i<5;++i) for(int j=i;j<5;++j) {
        for(int s:{-1,1}) {
            if(i==j && s==-1) continue;
            // Pick p,q outside the support. Rank two on these
            // coordinates precludes a nonzero supported combination.
            int p=-1,q=-1;
            for(int u=0;u<5;++u) if(u!=i && u!=j && (a[u]||b[u])) {
                if(p==-1) p=u;
                else if(a[p]*b[u]!=a[u]*b[p]) {q=u;break;}
            }
            if(q!=-1) continue;
            if(p==-1) return false;
            // The complement has rank one. Test its kernel direction.
            const int zi=a[i]*b[p]-b[i]*a[p];
            const int zj=a[j]*b[p]-b[j]*a[p];
            if(i==j ? zi!=0 : (zi!=0 && zj==s*zi)) return false;
        }
    }
    return true;
}


struct Result {
    int64_t count=0, feasible=0, max_bound=0, outside=0;
    Vec witness{};
    int best_num=0,best_den=1, best_D=0;
};

// Track the largest rank-four squared-volume upper bound found so far.
int64_t best3=0, all3=0, valid3=0, outside3=0;

int inner(const Vec &a,const Vec &b) {
    return std::inner_product(a.begin(),a.end(),b.begin(),0);
}

int det3(const Vec &a,const Vec &b,const Vec &c,int i,int j,int k){
    return a[i]*(b[j]*c[k]-b[k]*c[j])-a[j]*(b[i]*c[k]-b[k]*c[i])+a[k]*(b[i]*c[j]-b[j]*c[i]);
}

int sign_domain(const Vec&c) {
    for(int z:c) if(z) return z>0;
    return 0;
}

bool possible3(const Vec &a, const Vec &b, const Vec &c) {
    for(int i=0;i<5;++i) for(int j=i;j<5;++j) for(int s:{-1,1}) {
        if(i==j && s==-1) continue;
        bool nonzero=false;
        for(int omit=0;omit<5 && !nonzero;++omit) {
            int T[4],k=0;
            for(int p=0;p<5;++p) if(p!=omit)T[k++]=p;
            int dd=0;
            for(int q=0;q<4;++q) if(T[q]==i || T[q]==j) {
                int U[3],l=0;
                for(int p=0;p<4;++p) if(q!=p)U[l++]=T[p];
                dd+=(q%2?-1:1)*(T[q]==i?1:s)*det3(a,b,c,U[0],U[1],U[2]);
            }
            nonzero=dd!=0;
        }
        if(!nonzero) return false;
    }
    return true;
}

void check_three(const Vec&a,const Vec&b,const Vec&c,int A,int AB,int D,int D3max,int C2) {
    if(!sign_domain(c)) return;
    int ac=inner(a,c),bc=inner(b,c);
    if(2*std::abs(ac)>A || 2*std::abs(A*bc-AB*ac)>D) return;
    int B2=(D+AB*AB)/A;
    // Gram determinant of the rows a,b,c.
    int E=D*C2-B2*ac*ac+2*AB*ac*bc-A*bc*bc;
    if(E<=0 || E>D3max || E*225<=best3) return;
    int g=0;
    for(int i=0;i<5;++i) for(int j=i+1;j<5;++j) for(int k=j+1;k<5;++k)
        g=std::gcd(g,std::abs(det3(a,b,c,i,j,k)));
    if(g!=1) return;
    ++all3;
    if(!possible3(a,b,c)) return;
    ++valid3;
    // Every zonotope facet normal is among the crosses of independent columns.
    // Store twice the support so the right hand side is cap * radius.
    struct Facet {int x,y,z,cap;};
    std::vector<Facet> normals;
    for(int i=0;i<5;++i) for(int j=i+1;j<5;++j) {
        Facet f{b[i]*c[j]-c[i]*b[j],c[i]*a[j]-a[i]*c[j],a[i]*b[j]-b[i]*a[j],0};
        for(int k=0;k<5;++k) f.cap+=2*std::abs(f.x*a[k]+f.y*b[k]+f.z*c[k]);
        if(f.cap) normals.push_back(f);
    }
    int al=0,bl=0,cl=0,as=0,bs=0,cs=0;
    for(int i=0;i<5;++i) {
        al+=std::abs(a[i]);bl+=std::abs(b[i]);cl+=std::abs(c[i]);
        as+=a[i];bs+=b[i];cs+=c[i];
    }
    // A strict five-runner witness on the two-dimensional subtorus
    // implies a box-centering radius at most 3/10.
    int rn=3,rd=10;
    bool seen=false;
    for(int x=-(3*al/5);x<=3*al/5;++x) if((x-as)%2==0)
    for(int y=-(3*bl/5);y<=3*bl/5;++y) if((y-bs)%2==0)
    for(int z=-(3*cl/5);z<=3*cl/5;++z) if((z-cs)%2==0) {
        int n=0,d=1;
        for(auto f:normals) {
            int u=std::abs(f.x*x+f.y*y+f.z*z);
            if(u*d>n*f.cap) {n=u;d=f.cap;}
            if(n*rd>rn*d)break;
        }
        if(n*rd<=rn*d) {rn=n;rd=d;seen=true;}
    }
    if(!seen) ++outside3;
    int64_t num=3*rd,den=rd-3*rn;
    int64_t upper=E*num*num/(4*den*den);
    if(upper>best3) {
        best3=upper;
        std::cout<<"rank 4 squared bound "<<upper<<" from D3 "<<E<<" radius "<<rn<<"/"<<rd<<" rows ";
        for(auto v:{a,b,c}) {for(int i:v)std::cout<<i<<' ';std::cout<<"/ ";}
        std::cout<<std::endl;
    }
}

void make_c(const Vec&a,const Vec&b,Vec &c,int A,int AB,int D,int D3max,int pos,int used,int max){
    if(pos==5){check_three(a,b,c,A,AB,D,D3max,used);return;}
    int k=std::sqrt(max-used);
    while((k+1)*(k+1)<=max-used)++k;
    while(k*k>max-used)--k;
    for(int i=-k;i<=k;++i){c[pos]=i;make_c(a,b,c,A,AB,D,D3max,pos+1,used+i*i,max);}
}

void check_plane(const Vec &a,const Vec &b,int a2,int b2,Result &res) {
    
    int dot=0,al=0,bl=0, bs=0;
    for(int i=0;i<5;++i) {
        dot+=a[i]*b[i]; al+=a[i]; bl+=std::abs(b[i]); bs+=b[i];
    }
    if(2*std::abs(dot)>a2) return;
    int D=a2*b2-dot*dot;
    // Preserve the first generated row. The rank-two determinant bound
    // depends on its parity and its l1 norm.
    int cap2=0;
    if(al%2==0) cap2=a2*33/4;
    // c3 / (1/3 - 1/(2 al))^2 = 33 al^2 / (2 al - 3)^2
    if(al%2) cap2=33*a2*al*al/((2*al-3)*(2*al-3));
    if(D<=0||D>cap2) return;
    Vec cap{};
    int g=0;
    for(int i=0;i<5;++i) for(int j=i+1;j<5;++j) {
        int d=std::abs(a[i]*b[j]-a[j]*b[i]);
        cap[i]+=d;cap[j]+=d;g=std::gcd(g,d);
    }
    if(g!=1) return;
    ++res.count;
    if(!possible(a,b)) return;
    ++res.feasible;
    int rn=1,rd=4;
    bool seen=false;
    for(int x=-al/2;x<=al/2;++x) if((x-al)%2==0)
    for(int y=-bl/2;y<=bl/2;++y) if((y-bs)%2==0) {
        int n=0,d=1;
        for(int i=0;i<5;++i) if(cap[i]) {
            int u=std::abs(a[i]*y-b[i]*x),z=2*cap[i];
            if(u*d>n*z) {n=u;d=z;}
        }
        if(n*rd<=rn*d) {
            rn=n;rd=d;seen=true;
        }
    }
    if(!seen) ++res.outside;
    int64_t num=3*rd, den=rd-3*rn;
    int64_t upper=(D*num*num)/(2*den*den);
    if(upper*225>best3) {
        Vec c{};
        // Bound the next relation's squared length after reducing it
        // along both existing Gram-Schmidt directions.
        int c_max=(2LL*a2*num*num + (1LL*a2*a2+D)*den*den)/(4LL*a2*den*den);
        make_c(a,b,c,a2,dot,D,upper,0,0,c_max);
    }
    if(upper>res.max_bound) {
        res.max_bound=upper;res.witness=b;res.best_num=rn;res.best_den=rd;res.best_D=D;
    }
}

void make_gauss_b(const Vec &a,Vec &b,int pos,int a2,int b2,int mx,Result &res) {
    if(pos==5) {check_plane(a,b,a2,b2,res);return;}
    int u=std::sqrt(mx-b2);
    while((u+1)*(u+1)<=mx-b2)++u;
    while(u*u>mx-b2)--u;
    // Use symmetries that fix the first row.
    int lo=(pos>0 && a[pos]==a[pos-1])?std::max(-u,b[pos-1]):-u;
    if(a[pos]==0) lo=std::max(0,lo);
    for(int j=lo;j<=u;++j) {b[pos]=j;make_gauss_b(a,b,pos+1,a2,b2+j*j,mx,res);}
}

int main() {
    Vec a0{};make_a(a0,0,3);
    int64_t count=0,valid=0,outside=0,max=0;
    for(const auto&a:all_a){
        int a2=std::inner_product(a.begin(),a.end(),a.begin(),0);
        if(a2<3||a2>13)continue;
        Vec b{};
        Result r;
        int al=std::accumulate(a.begin(),a.end(),0);
        int cap2=al%2 ? 33*a2*al*al/((2*al-3)*(2*al-3)) : 33*a2/4;
        make_gauss_b(a,b,0,a2,0,(4*cap2+a2*a2)/(4*a2),r);
        count+=r.count; valid+=r.feasible; outside+=r.outside;
        if(r.max_bound>max){
            max=r.max_bound;
            std::cout<<"max "<<max<<" D2 "<<r.best_D<<" radius "<<r.best_num<<"/"<<r.best_den<<" a ";
            for(int i:a) std::cout<<i<<' ';
            std::cout<<" b ";
            for(int i:r.witness) std::cout<<i<<' ';
            std::cout<<std::endl;
        }
    }
    std::cout<<"basis cases "<<count<<", possible "<<valid<<", outside bound "<<outside<<", max squared norm "<<225*max<<" max speed "<<(int)std::sqrt(225*max)<<'\n';
    std::cout<<"rank 3 relevant basis cases "<<all3<<", possible "<<valid3<<", outside bound "<<outside3<<", final squared "<<best3<<", final speed "<<(int)std::sqrt(best3)<<'\n';
    return outside!=0 || outside3!=0 || best3!=51046;
}
