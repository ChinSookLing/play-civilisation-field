#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <numeric>
#include <vector>
struct Mask {
    std::array<uint64_t,3> words{};
    Mask operator&(const Mask &b) const {
        return {{words[0]&b.words[0], words[1]&b.words[1], words[2]&b.words[2]}};
    }
    bool any() const {return words[0]||words[1]||words[2];}
};
int64_t choose5(int n) {return n<5 ? 0 : (int64_t)n*(n-1)*(n-2)*(n-3)*(n-4)/120;}
int64_t primitive_count(int B) {
    std::vector<int> mu(B+1);
    mu[1]=1;
    for(int i=1;i<=B;++i) for(int j=2*i;j<=B;j+=i) mu[j]-=mu[i];
    int64_t out=0;
    for(int i=1;i<=B;++i) out+=mu[i]*choose5(B/i);
    return out;
}
using Endpoint = std::pair<int64_t,int64_t>;

std::vector<Endpoint> safety_intervals(const std::array<int,5>&v, int64_t &scale) {
    int64_t multiple=1;
    for(int speed:v) multiple=std::lcm(multiple,static_cast<int64_t>(speed));
    scale=6*multiple;
    std::vector<Endpoint> intervals{{0,scale}};
    for(int speed:v) {
        std::vector<Endpoint> next;
        size_t i=0;
        int j=0;
        while(i<intervals.size() && j<speed){
            int64_t lower=(6*j+1)*(multiple/speed);
            int64_t upper=(6*j+5)*(multiple/speed);
            int64_t left=std::max(intervals[i].first,lower);
            int64_t right=std::min(intervals[i].second,upper);
            if(left<=right) next.emplace_back(left,right);
            if(intervals[i].second<upper) ++i;
            else ++j;
        }
        intervals.swap(next);
    }
    return intervals;
}
int main(int argc,char **argv) {
    const int B=argc>1?atoi(argv[1]):225;
    if(B<5||B>225) return 2;
    std::vector<Mask> hit(B+1);
    std::vector<int> div(B+1);
    for(int x=1;x<=B;++x) div[x]=(x%3==0)|((x%4==0)<<1)|((x%5==0)<<2);
    int index=0;
    for(int q=2;q<=30;++q) for(int k=1;k<=q/2;++k) if(std::gcd(k,q)==1) {
        if(index>=192) return 2;
        for(int x=1;x<=B;++x){
            int a=6*(k*x%q);
            if(a>q && a<5*q) hit[x].words[index/64]|=uint64_t(1)<<(index%64);
        }
        ++index;
    }
    int survivors=0,tight=0;
    for(int a=1;a<=B-4;++a) for(int b=a+1;b<=B-3;++b){
        auto hab=hit[a]&hit[b]; auto dab=div[a]|div[b];
        for(int c=b+1;c<=B-2;++c) {
            auto hc=hab&hit[c]; auto dc=dab|div[c];
            for(int d=c+1;d<=B-1;++d){
                auto hd=hc&hit[d]; auto dd=dc|div[d];
                for(int e=d+1;e<=B;++e){
                    if((dd|div[e])!=7 || (hd&hit[e]).any())continue;
                    if(std::gcd(std::gcd(std::gcd(a,b),std::gcd(c,d)),e)!=1)continue;
                    ++survivors;
                    std::array<int,5> v{a,b,c,d,e};
                    int64_t scale=0;
                    auto intervals=safety_intervals(v,scale);
                    bool ok=std::any_of(intervals.begin(),intervals.end(),[](auto window){
                        return window.first<window.second;
                    });
                    for(int x:v) std::cout<<x<<' ';
                    if(ok){
                        auto window=*std::find_if(intervals.begin(),intervals.end(),[](auto w){
                            return w.first<w.second;
                        });
                        auto midpoint=window.first+window.second;
                        auto denominator=2*scale;
                        auto g=std::gcd(midpoint,denominator);
                        std::cout<<"strict "<<midpoint/g<<'/'<<denominator/g;
                    } else {
                        std::cout<<"zero measure, endpoints";
                        for(auto [left,right]:intervals){
                            auto g=std::gcd(left,scale);
                            std::cout<<' '<<left/g<<'/'<<scale/g;
                        }
                    }
                    std::cout<<'\n';
                    tight+=!ok;
                }
            }
        }
    }
    std::cout<<"B "<<B<<", fraction witnesses "<<index<<", primitive inputs "<<primitive_count(B)<<", survivors "<<survivors<<", tight "<<tight<<'\n';
    return B==225 && (survivors!=16 || tight!=2);
}
